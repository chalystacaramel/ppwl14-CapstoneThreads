const require_chunk = require("./chunk-9hOWP6kD.cjs");
const require_dist_cjs$36 = require("./dist-cjs-BneT29QX.cjs");
const require_dist_cjs$37 = require("./dist-cjs-D8Xvoqzr.cjs");
const require_dist_cjs$38 = require("./dist-cjs-Cv7lwqFB.cjs");
const require_dist_cjs$39 = require("./dist-cjs-BPUMJe9H.cjs");
const require_dist_cjs$40 = require("./dist-cjs-CthQcEjW.cjs");
const require_client = require("./client-l-N-KiY4.cjs");
const require_dist_cjs$41 = require("./dist-cjs-B4Zh07ae.cjs");
const require_dist_cjs$42 = require("./dist-cjs-EhnLoTSm.cjs");
const require_dist_cjs$43 = require("./dist-cjs-sJyDAqtz.cjs");
//#region ../../node_modules/.bun/@aws-sdk+middleware-host-header@3.972.10/node_modules/@aws-sdk/middleware-host-header/dist-cjs/index.js
var require_dist_cjs$18 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	function resolveHostHeaderConfig(input) {
		return input;
	}
	const hostHeaderMiddleware = (options) => (next) => async (args) => {
		if (!protocolHttp.HttpRequest.isInstance(args.request)) return next(args);
		const { request } = args;
		const { handlerProtocol = "" } = options.requestHandler.metadata || {};
		if (handlerProtocol.indexOf("h2") >= 0 && !request.headers[":authority"]) {
			delete request.headers["host"];
			request.headers[":authority"] = request.hostname + (request.port ? ":" + request.port : "");
		} else if (!request.headers["host"]) {
			let host = request.hostname;
			if (request.port != null) host += `:${request.port}`;
			request.headers["host"] = host;
		}
		return next(args);
	};
	const hostHeaderMiddlewareOptions = {
		name: "hostHeaderMiddleware",
		step: "build",
		priority: "low",
		tags: ["HOST"],
		override: true
	};
	const getHostHeaderPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.add(hostHeaderMiddleware(options), hostHeaderMiddlewareOptions);
	} });
	exports.getHostHeaderPlugin = getHostHeaderPlugin;
	exports.hostHeaderMiddleware = hostHeaderMiddleware;
	exports.hostHeaderMiddlewareOptions = hostHeaderMiddlewareOptions;
	exports.resolveHostHeaderConfig = resolveHostHeaderConfig;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+middleware-logger@3.972.10/node_modules/@aws-sdk/middleware-logger/dist-cjs/index.js
var require_dist_cjs$17 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	const loggerMiddleware = () => (next, context) => async (args) => {
		try {
			const response = await next(args);
			const { clientName, commandName, logger, dynamoDbDocumentClientOptions = {} } = context;
			const { overrideInputFilterSensitiveLog, overrideOutputFilterSensitiveLog } = dynamoDbDocumentClientOptions;
			const inputFilterSensitiveLog = overrideInputFilterSensitiveLog ?? context.inputFilterSensitiveLog;
			const outputFilterSensitiveLog = overrideOutputFilterSensitiveLog ?? context.outputFilterSensitiveLog;
			const { $metadata, ...outputWithoutMetadata } = response.output;
			logger?.info?.({
				clientName,
				commandName,
				input: inputFilterSensitiveLog(args.input),
				output: outputFilterSensitiveLog(outputWithoutMetadata),
				metadata: $metadata
			});
			return response;
		} catch (error) {
			const { clientName, commandName, logger, dynamoDbDocumentClientOptions = {} } = context;
			const { overrideInputFilterSensitiveLog } = dynamoDbDocumentClientOptions;
			const inputFilterSensitiveLog = overrideInputFilterSensitiveLog ?? context.inputFilterSensitiveLog;
			logger?.error?.({
				clientName,
				commandName,
				input: inputFilterSensitiveLog(args.input),
				error,
				metadata: error.$metadata
			});
			throw error;
		}
	};
	const loggerMiddlewareOptions = {
		name: "loggerMiddleware",
		tags: ["LOGGER"],
		step: "initialize",
		override: true
	};
	const getLoggerPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.add(loggerMiddleware(), loggerMiddlewareOptions);
	} });
	exports.getLoggerPlugin = getLoggerPlugin;
	exports.loggerMiddleware = loggerMiddleware;
	exports.loggerMiddlewareOptions = loggerMiddlewareOptions;
}));
//#endregion
//#region ../../node_modules/.bun/@aws+lambda-invoke-store@0.2.4/node_modules/@aws/lambda-invoke-store/dist-es/invoke-store.js
var invoke_store_exports = /* @__PURE__ */ require_chunk.__exportAll({
	InvokeStore: () => InvokeStore,
	InvokeStoreBase: () => InvokeStoreBase
});
var PROTECTED_KEYS, NO_GLOBAL_AWS_LAMBDA, InvokeStoreBase, InvokeStoreSingle, InvokeStoreMulti, InvokeStore;
var init_invoke_store = require_chunk.__esmMin((() => {
	PROTECTED_KEYS = {
		REQUEST_ID: Symbol.for("_AWS_LAMBDA_REQUEST_ID"),
		X_RAY_TRACE_ID: Symbol.for("_AWS_LAMBDA_X_RAY_TRACE_ID"),
		TENANT_ID: Symbol.for("_AWS_LAMBDA_TENANT_ID")
	};
	NO_GLOBAL_AWS_LAMBDA = ["true", "1"].includes(process.env?.AWS_LAMBDA_NODEJS_NO_GLOBAL_AWSLAMBDA ?? "");
	if (!NO_GLOBAL_AWS_LAMBDA) globalThis.awslambda = globalThis.awslambda || {};
	InvokeStoreBase = class {
		static PROTECTED_KEYS = PROTECTED_KEYS;
		isProtectedKey(key) {
			return Object.values(PROTECTED_KEYS).includes(key);
		}
		getRequestId() {
			return this.get(PROTECTED_KEYS.REQUEST_ID) ?? "-";
		}
		getXRayTraceId() {
			return this.get(PROTECTED_KEYS.X_RAY_TRACE_ID);
		}
		getTenantId() {
			return this.get(PROTECTED_KEYS.TENANT_ID);
		}
	};
	InvokeStoreSingle = class extends InvokeStoreBase {
		currentContext;
		getContext() {
			return this.currentContext;
		}
		hasContext() {
			return this.currentContext !== void 0;
		}
		get(key) {
			return this.currentContext?.[key];
		}
		set(key, value) {
			if (this.isProtectedKey(key)) throw new Error(`Cannot modify protected Lambda context field: ${String(key)}`);
			this.currentContext = this.currentContext || {};
			this.currentContext[key] = value;
		}
		run(context, fn) {
			this.currentContext = context;
			return fn();
		}
	};
	InvokeStoreMulti = class InvokeStoreMulti extends InvokeStoreBase {
		als;
		static async create() {
			const instance = new InvokeStoreMulti();
			instance.als = new (await (import("node:async_hooks"))).AsyncLocalStorage();
			return instance;
		}
		getContext() {
			return this.als.getStore();
		}
		hasContext() {
			return this.als.getStore() !== void 0;
		}
		get(key) {
			return this.als.getStore()?.[key];
		}
		set(key, value) {
			if (this.isProtectedKey(key)) throw new Error(`Cannot modify protected Lambda context field: ${String(key)}`);
			const store = this.als.getStore();
			if (!store) throw new Error("No context available");
			store[key] = value;
		}
		run(context, fn) {
			return this.als.run(context, fn);
		}
	};
	(function(InvokeStore) {
		let instance = null;
		async function getInstanceAsync(forceInvokeStoreMulti) {
			if (!instance) instance = (async () => {
				const newInstance = forceInvokeStoreMulti === true || "AWS_LAMBDA_MAX_CONCURRENCY" in process.env ? await InvokeStoreMulti.create() : new InvokeStoreSingle();
				if (!NO_GLOBAL_AWS_LAMBDA && globalThis.awslambda?.InvokeStore) return globalThis.awslambda.InvokeStore;
				else if (!NO_GLOBAL_AWS_LAMBDA && globalThis.awslambda) {
					globalThis.awslambda.InvokeStore = newInstance;
					return newInstance;
				} else return newInstance;
			})();
			return instance;
		}
		InvokeStore.getInstanceAsync = getInstanceAsync;
		InvokeStore._testing = process.env.AWS_LAMBDA_BENCHMARK_MODE === "1" ? { reset: () => {
			instance = null;
			if (globalThis.awslambda?.InvokeStore) delete globalThis.awslambda.InvokeStore;
			globalThis.awslambda = { InvokeStore: void 0 };
		} } : void 0;
	})(InvokeStore || (InvokeStore = {}));
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+middleware-recursion-detection@3.972.11/node_modules/@aws-sdk/middleware-recursion-detection/dist-cjs/recursionDetectionMiddleware.js
var require_recursionDetectionMiddleware = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.recursionDetectionMiddleware = void 0;
	const lambda_invoke_store_1 = (init_invoke_store(), require_chunk.__toCommonJS(invoke_store_exports));
	const protocol_http_1 = require_dist_cjs$37.require_dist_cjs();
	const TRACE_ID_HEADER_NAME = "X-Amzn-Trace-Id";
	const ENV_LAMBDA_FUNCTION_NAME = "AWS_LAMBDA_FUNCTION_NAME";
	const ENV_TRACE_ID = "_X_AMZN_TRACE_ID";
	const recursionDetectionMiddleware = () => (next) => async (args) => {
		const { request } = args;
		if (!protocol_http_1.HttpRequest.isInstance(request)) return next(args);
		const traceIdHeader = Object.keys(request.headers ?? {}).find((h) => h.toLowerCase() === TRACE_ID_HEADER_NAME.toLowerCase()) ?? TRACE_ID_HEADER_NAME;
		if (request.headers.hasOwnProperty(traceIdHeader)) return next(args);
		const functionName = process.env[ENV_LAMBDA_FUNCTION_NAME];
		const traceIdFromEnv = process.env[ENV_TRACE_ID];
		const traceId = (await lambda_invoke_store_1.InvokeStore.getInstanceAsync())?.getXRayTraceId() ?? traceIdFromEnv;
		const nonEmptyString = (str) => typeof str === "string" && str.length > 0;
		if (nonEmptyString(functionName) && nonEmptyString(traceId)) request.headers[TRACE_ID_HEADER_NAME] = traceId;
		return next({
			...args,
			request
		});
	};
	exports.recursionDetectionMiddleware = recursionDetectionMiddleware;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+middleware-recursion-detection@3.972.11/node_modules/@aws-sdk/middleware-recursion-detection/dist-cjs/index.js
var require_dist_cjs$16 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var recursionDetectionMiddleware = require_recursionDetectionMiddleware();
	const recursionDetectionMiddlewareOptions = {
		step: "build",
		tags: ["RECURSION_DETECTION"],
		name: "recursionDetectionMiddleware",
		override: true,
		priority: "low"
	};
	const getRecursionDetectionPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.add(recursionDetectionMiddleware.recursionDetectionMiddleware(), recursionDetectionMiddlewareOptions);
	} });
	exports.getRecursionDetectionPlugin = getRecursionDetectionPlugin;
	Object.prototype.hasOwnProperty.call(recursionDetectionMiddleware, "__proto__") && !Object.prototype.hasOwnProperty.call(exports, "__proto__") && Object.defineProperty(exports, "__proto__", {
		enumerable: true,
		value: recursionDetectionMiddleware["__proto__"]
	});
	Object.keys(recursionDetectionMiddleware).forEach(function(k) {
		if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) exports[k] = recursionDetectionMiddleware[k];
	});
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/getSmithyContext.js
var import_dist_cjs$31, getSmithyContext$3;
var init_getSmithyContext = require_chunk.__esmMin((() => {
	import_dist_cjs$31 = require_dist_cjs$36.require_dist_cjs();
	getSmithyContext$3 = (context) => context[import_dist_cjs$31.SMITHY_CONTEXT_KEY] || (context[import_dist_cjs$31.SMITHY_CONTEXT_KEY] = {});
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-auth-scheme/resolveAuthOptions.js
var resolveAuthOptions;
var init_resolveAuthOptions = require_chunk.__esmMin((() => {
	resolveAuthOptions = (candidateAuthOptions, authSchemePreference) => {
		if (!authSchemePreference || authSchemePreference.length === 0) return candidateAuthOptions;
		const preferredAuthOptions = [];
		for (const preferredSchemeName of authSchemePreference) for (const candidateAuthOption of candidateAuthOptions) if (candidateAuthOption.schemeId.split("#")[1] === preferredSchemeName) preferredAuthOptions.push(candidateAuthOption);
		for (const candidateAuthOption of candidateAuthOptions) if (!preferredAuthOptions.find(({ schemeId }) => schemeId === candidateAuthOption.schemeId)) preferredAuthOptions.push(candidateAuthOption);
		return preferredAuthOptions;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-auth-scheme/httpAuthSchemeMiddleware.js
function convertHttpAuthSchemesToMap(httpAuthSchemes) {
	const map = /* @__PURE__ */ new Map();
	for (const scheme of httpAuthSchemes) map.set(scheme.schemeId, scheme);
	return map;
}
var import_dist_cjs$30, httpAuthSchemeMiddleware;
var init_httpAuthSchemeMiddleware = require_chunk.__esmMin((() => {
	import_dist_cjs$30 = require_dist_cjs$38.require_dist_cjs$7();
	init_resolveAuthOptions();
	httpAuthSchemeMiddleware = (config, mwOptions) => (next, context) => async (args) => {
		const resolvedOptions = resolveAuthOptions(config.httpAuthSchemeProvider(await mwOptions.httpAuthSchemeParametersProvider(config, context, args.input)), config.authSchemePreference ? await config.authSchemePreference() : []);
		const authSchemes = convertHttpAuthSchemesToMap(config.httpAuthSchemes);
		const smithyContext = (0, import_dist_cjs$30.getSmithyContext)(context);
		const failureReasons = [];
		for (const option of resolvedOptions) {
			const scheme = authSchemes.get(option.schemeId);
			if (!scheme) {
				failureReasons.push(`HttpAuthScheme \`${option.schemeId}\` was not enabled for this service.`);
				continue;
			}
			const identityProvider = scheme.identityProvider(await mwOptions.identityProviderConfigProvider(config));
			if (!identityProvider) {
				failureReasons.push(`HttpAuthScheme \`${option.schemeId}\` did not have an IdentityProvider configured.`);
				continue;
			}
			const { identityProperties = {}, signingProperties = {} } = option.propertiesExtractor?.(config, context) || {};
			option.identityProperties = Object.assign(option.identityProperties || {}, identityProperties);
			option.signingProperties = Object.assign(option.signingProperties || {}, signingProperties);
			smithyContext.selectedHttpAuthScheme = {
				httpAuthOption: option,
				identity: await identityProvider(option.identityProperties),
				signer: scheme.signer
			};
			break;
		}
		if (!smithyContext.selectedHttpAuthScheme) throw new Error(failureReasons.join("\n"));
		return next(args);
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-auth-scheme/getHttpAuthSchemeEndpointRuleSetPlugin.js
var httpAuthSchemeEndpointRuleSetMiddlewareOptions, getHttpAuthSchemeEndpointRuleSetPlugin;
var init_getHttpAuthSchemeEndpointRuleSetPlugin = require_chunk.__esmMin((() => {
	init_httpAuthSchemeMiddleware();
	httpAuthSchemeEndpointRuleSetMiddlewareOptions = {
		step: "serialize",
		tags: ["HTTP_AUTH_SCHEME"],
		name: "httpAuthSchemeMiddleware",
		override: true,
		relation: "before",
		toMiddleware: "endpointV2Middleware"
	};
	getHttpAuthSchemeEndpointRuleSetPlugin = (config, { httpAuthSchemeParametersProvider, identityProviderConfigProvider }) => ({ applyToStack: (clientStack) => {
		clientStack.addRelativeTo(httpAuthSchemeMiddleware(config, {
			httpAuthSchemeParametersProvider,
			identityProviderConfigProvider
		}), httpAuthSchemeEndpointRuleSetMiddlewareOptions);
	} });
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-auth-scheme/getHttpAuthSchemePlugin.js
var httpAuthSchemeMiddlewareOptions, getHttpAuthSchemePlugin;
var init_getHttpAuthSchemePlugin = require_chunk.__esmMin((() => {
	init_httpAuthSchemeMiddleware();
	httpAuthSchemeMiddlewareOptions = {
		step: "serialize",
		tags: ["HTTP_AUTH_SCHEME"],
		name: "httpAuthSchemeMiddleware",
		override: true,
		relation: "before",
		toMiddleware: "serializerMiddleware"
	};
	getHttpAuthSchemePlugin = (config, { httpAuthSchemeParametersProvider, identityProviderConfigProvider }) => ({ applyToStack: (clientStack) => {
		clientStack.addRelativeTo(httpAuthSchemeMiddleware(config, {
			httpAuthSchemeParametersProvider,
			identityProviderConfigProvider
		}), httpAuthSchemeMiddlewareOptions);
	} });
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-auth-scheme/index.js
var init_middleware_http_auth_scheme = require_chunk.__esmMin((() => {
	init_httpAuthSchemeMiddleware();
	init_getHttpAuthSchemeEndpointRuleSetPlugin();
	init_getHttpAuthSchemePlugin();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-signing/httpSigningMiddleware.js
var import_dist_cjs$28, import_dist_cjs$29, defaultErrorHandler, defaultSuccessHandler, httpSigningMiddleware;
var init_httpSigningMiddleware = require_chunk.__esmMin((() => {
	import_dist_cjs$28 = require_dist_cjs$37.require_dist_cjs();
	import_dist_cjs$29 = require_dist_cjs$38.require_dist_cjs$7();
	defaultErrorHandler = (signingProperties) => (error) => {
		throw error;
	};
	defaultSuccessHandler = (httpResponse, signingProperties) => {};
	httpSigningMiddleware = (config) => (next, context) => async (args) => {
		if (!import_dist_cjs$28.HttpRequest.isInstance(args.request)) return next(args);
		const scheme = (0, import_dist_cjs$29.getSmithyContext)(context).selectedHttpAuthScheme;
		if (!scheme) throw new Error(`No HttpAuthScheme was selected: unable to sign request`);
		const { httpAuthOption: { signingProperties = {} }, identity, signer } = scheme;
		const output = await next({
			...args,
			request: await signer.sign(args.request, identity, signingProperties)
		}).catch((signer.errorHandler || defaultErrorHandler)(signingProperties));
		(signer.successHandler || defaultSuccessHandler)(output.response, signingProperties);
		return output;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-signing/getHttpSigningMiddleware.js
var httpSigningMiddlewareOptions, getHttpSigningPlugin;
var init_getHttpSigningMiddleware = require_chunk.__esmMin((() => {
	init_httpSigningMiddleware();
	httpSigningMiddlewareOptions = {
		step: "finalizeRequest",
		tags: ["HTTP_SIGNING"],
		name: "httpSigningMiddleware",
		aliases: [
			"apiKeyMiddleware",
			"tokenMiddleware",
			"awsAuthMiddleware"
		],
		override: true,
		relation: "after",
		toMiddleware: "retryMiddleware"
	};
	getHttpSigningPlugin = (config) => ({ applyToStack: (clientStack) => {
		clientStack.addRelativeTo(httpSigningMiddleware(config), httpSigningMiddlewareOptions);
	} });
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/middleware-http-signing/index.js
var init_middleware_http_signing = require_chunk.__esmMin((() => {
	init_httpSigningMiddleware();
	init_getHttpSigningMiddleware();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/normalizeProvider.js
var normalizeProvider;
var init_normalizeProvider = require_chunk.__esmMin((() => {
	normalizeProvider = (input) => {
		if (typeof input === "function") return input;
		const promisified = Promise.resolve(input);
		return () => promisified;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/pagination/createPaginator.js
function createPaginator(ClientCtor, CommandCtor, inputTokenName, outputTokenName, pageSizeTokenName) {
	return async function* paginateOperation(config, input, ...additionalArguments) {
		const _input = input;
		let token = config.startingToken ?? _input[inputTokenName];
		let hasNext = true;
		let page;
		while (hasNext) {
			_input[inputTokenName] = token;
			if (pageSizeTokenName) _input[pageSizeTokenName] = _input[pageSizeTokenName] ?? config.pageSize;
			if (config.client instanceof ClientCtor) page = await makePagedClientRequest(CommandCtor, config.client, input, config.withCommand, ...additionalArguments);
			else throw new Error(`Invalid client, expected instance of ${ClientCtor.name}`);
			yield page;
			const prevToken = token;
			token = get(page, outputTokenName);
			hasNext = !!(token && (!config.stopOnSameToken || token !== prevToken));
		}
		return void 0;
	};
}
var makePagedClientRequest, get;
var init_createPaginator = require_chunk.__esmMin((() => {
	makePagedClientRequest = async (CommandCtor, client, input, withCommand = (_) => _, ...args) => {
		let command = new CommandCtor(input);
		command = withCommand(command) ?? command;
		return await client.send(command, ...args);
	};
	get = (fromObject, path) => {
		let cursor = fromObject;
		const pathComponents = path.split(".");
		for (const step of pathComponents) {
			if (!cursor || typeof cursor !== "object") return;
			cursor = cursor[step];
		}
		return cursor;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/request-builder/requestBuilder.js
var init_requestBuilder = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/setFeature.js
function setFeature(context, feature, value) {
	if (!context.__smithy_context) context.__smithy_context = { features: {} };
	else if (!context.__smithy_context.features) context.__smithy_context.features = {};
	context.__smithy_context.features[feature] = value;
}
var init_setFeature = require_chunk.__esmMin((() => {}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/DefaultIdentityProviderConfig.js
var DefaultIdentityProviderConfig;
var init_DefaultIdentityProviderConfig = require_chunk.__esmMin((() => {
	DefaultIdentityProviderConfig = class {
		authSchemes = /* @__PURE__ */ new Map();
		constructor(config) {
			for (const key in config) {
				const value = config[key];
				if (value !== void 0) this.authSchemes.set(key, value);
			}
		}
		getIdentityProvider(schemeId) {
			return this.authSchemes.get(schemeId);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/httpAuthSchemes/httpApiKeyAuth.js
var import_dist_cjs$26, import_dist_cjs$27, HttpApiKeyAuthSigner;
var init_httpApiKeyAuth = require_chunk.__esmMin((() => {
	import_dist_cjs$26 = require_dist_cjs$37.require_dist_cjs();
	import_dist_cjs$27 = require_dist_cjs$36.require_dist_cjs();
	HttpApiKeyAuthSigner = class {
		async sign(httpRequest, identity, signingProperties) {
			if (!signingProperties) throw new Error("request could not be signed with `apiKey` since the `name` and `in` signer properties are missing");
			if (!signingProperties.name) throw new Error("request could not be signed with `apiKey` since the `name` signer property is missing");
			if (!signingProperties.in) throw new Error("request could not be signed with `apiKey` since the `in` signer property is missing");
			if (!identity.apiKey) throw new Error("request could not be signed with `apiKey` since the `apiKey` is not defined");
			const clonedRequest = import_dist_cjs$26.HttpRequest.clone(httpRequest);
			if (signingProperties.in === import_dist_cjs$27.HttpApiKeyAuthLocation.QUERY) clonedRequest.query[signingProperties.name] = identity.apiKey;
			else if (signingProperties.in === import_dist_cjs$27.HttpApiKeyAuthLocation.HEADER) clonedRequest.headers[signingProperties.name] = signingProperties.scheme ? `${signingProperties.scheme} ${identity.apiKey}` : identity.apiKey;
			else throw new Error("request can only be signed with `apiKey` locations `query` or `header`, but found: `" + signingProperties.in + "`");
			return clonedRequest;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/httpAuthSchemes/httpBearerAuth.js
var import_dist_cjs$25, HttpBearerAuthSigner;
var init_httpBearerAuth = require_chunk.__esmMin((() => {
	import_dist_cjs$25 = require_dist_cjs$37.require_dist_cjs();
	HttpBearerAuthSigner = class {
		async sign(httpRequest, identity, signingProperties) {
			const clonedRequest = import_dist_cjs$25.HttpRequest.clone(httpRequest);
			if (!identity.token) throw new Error("request could not be signed with `token` since the `token` is not defined");
			clonedRequest.headers["Authorization"] = `Bearer ${identity.token}`;
			return clonedRequest;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/httpAuthSchemes/noAuth.js
var NoAuthSigner;
var init_noAuth = require_chunk.__esmMin((() => {
	NoAuthSigner = class {
		async sign(httpRequest, identity, signingProperties) {
			return httpRequest;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/httpAuthSchemes/index.js
var init_httpAuthSchemes$1 = require_chunk.__esmMin((() => {
	init_httpApiKeyAuth();
	init_httpBearerAuth();
	init_noAuth();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/memoizeIdentityProvider.js
var createIsIdentityExpiredFunction, EXPIRATION_MS, isIdentityExpired, doesIdentityRequireRefresh, memoizeIdentityProvider;
var init_memoizeIdentityProvider = require_chunk.__esmMin((() => {
	createIsIdentityExpiredFunction = (expirationMs) => function isIdentityExpired(identity) {
		return doesIdentityRequireRefresh(identity) && identity.expiration.getTime() - Date.now() < expirationMs;
	};
	EXPIRATION_MS = 3e5;
	isIdentityExpired = createIsIdentityExpiredFunction(EXPIRATION_MS);
	doesIdentityRequireRefresh = (identity) => identity.expiration !== void 0;
	memoizeIdentityProvider = (provider, isExpired, requiresRefresh) => {
		if (provider === void 0) return;
		const normalizedProvider = typeof provider !== "function" ? async () => Promise.resolve(provider) : provider;
		let resolved;
		let pending;
		let hasResult;
		let isConstant = false;
		const coalesceProvider = async (options) => {
			if (!pending) pending = normalizedProvider(options);
			try {
				resolved = await pending;
				hasResult = true;
				isConstant = false;
			} finally {
				pending = void 0;
			}
			return resolved;
		};
		if (isExpired === void 0) return async (options) => {
			if (!hasResult || options?.forceRefresh) resolved = await coalesceProvider(options);
			return resolved;
		};
		return async (options) => {
			if (!hasResult || options?.forceRefresh) resolved = await coalesceProvider(options);
			if (isConstant) return resolved;
			if (!requiresRefresh(resolved)) {
				isConstant = true;
				return resolved;
			}
			if (isExpired(resolved)) {
				await coalesceProvider(options);
				return resolved;
			}
			return resolved;
		};
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/util-identity-and-auth/index.js
var init_util_identity_and_auth = require_chunk.__esmMin((() => {
	init_DefaultIdentityProviderConfig();
	init_httpAuthSchemes$1();
	init_memoizeIdentityProvider();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/index.js
var dist_es_exports = /* @__PURE__ */ require_chunk.__exportAll({
	DefaultIdentityProviderConfig: () => DefaultIdentityProviderConfig,
	EXPIRATION_MS: () => EXPIRATION_MS,
	HttpApiKeyAuthSigner: () => HttpApiKeyAuthSigner,
	HttpBearerAuthSigner: () => HttpBearerAuthSigner,
	NoAuthSigner: () => NoAuthSigner,
	createIsIdentityExpiredFunction: () => createIsIdentityExpiredFunction,
	createPaginator: () => createPaginator,
	doesIdentityRequireRefresh: () => doesIdentityRequireRefresh,
	getHttpAuthSchemeEndpointRuleSetPlugin: () => getHttpAuthSchemeEndpointRuleSetPlugin,
	getHttpAuthSchemePlugin: () => getHttpAuthSchemePlugin,
	getHttpSigningPlugin: () => getHttpSigningPlugin,
	getSmithyContext: () => getSmithyContext$3,
	httpAuthSchemeEndpointRuleSetMiddlewareOptions: () => httpAuthSchemeEndpointRuleSetMiddlewareOptions,
	httpAuthSchemeMiddleware: () => httpAuthSchemeMiddleware,
	httpAuthSchemeMiddlewareOptions: () => httpAuthSchemeMiddlewareOptions,
	httpSigningMiddleware: () => httpSigningMiddleware,
	httpSigningMiddlewareOptions: () => httpSigningMiddlewareOptions,
	isIdentityExpired: () => isIdentityExpired,
	memoizeIdentityProvider: () => memoizeIdentityProvider,
	normalizeProvider: () => normalizeProvider,
	requestBuilder: () => require_dist_cjs$38.requestBuilder,
	setFeature: () => setFeature
});
var init_dist_es = require_chunk.__esmMin((() => {
	init_getSmithyContext();
	init_middleware_http_auth_scheme();
	init_middleware_http_signing();
	init_normalizeProvider();
	init_createPaginator();
	init_requestBuilder();
	init_setFeature();
	init_util_identity_and_auth();
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+util-endpoints@3.4.2/node_modules/@smithy/util-endpoints/dist-cjs/index.js
var require_dist_cjs$15 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var types = require_dist_cjs$36.require_dist_cjs();
	var BinaryDecisionDiagram = class BinaryDecisionDiagram {
		nodes;
		root;
		conditions;
		results;
		constructor(bdd, root, conditions, results) {
			this.nodes = bdd;
			this.root = root;
			this.conditions = conditions;
			this.results = results;
		}
		static from(bdd, root, conditions, results) {
			return new BinaryDecisionDiagram(bdd, root, conditions, results);
		}
	};
	var EndpointCache = class {
		capacity;
		data = /* @__PURE__ */ new Map();
		parameters = [];
		constructor({ size, params }) {
			this.capacity = size ?? 50;
			if (params) this.parameters = params;
		}
		get(endpointParams, resolver) {
			const key = this.hash(endpointParams);
			if (key === false) return resolver();
			if (!this.data.has(key)) {
				if (this.data.size > this.capacity + 10) {
					const keys = this.data.keys();
					let i = 0;
					while (true) {
						const { value, done } = keys.next();
						this.data.delete(value);
						if (done || ++i > 10) break;
					}
				}
				this.data.set(key, resolver());
			}
			return this.data.get(key);
		}
		size() {
			return this.data.size;
		}
		hash(endpointParams) {
			let buffer = "";
			const { parameters } = this;
			if (parameters.length === 0) return false;
			for (const param of parameters) {
				const val = String(endpointParams[param] ?? "");
				if (val.includes("|;")) return false;
				buffer += val + "|;";
			}
			return buffer;
		}
	};
	var EndpointError = class extends Error {
		constructor(message) {
			super(message);
			this.name = "EndpointError";
		}
	};
	const debugId = "endpoints";
	function toDebugString(input) {
		if (typeof input !== "object" || input == null) return input;
		if ("ref" in input) return `$${toDebugString(input.ref)}`;
		if ("fn" in input) return `${input.fn}(${(input.argv || []).map(toDebugString).join(", ")})`;
		return JSON.stringify(input, null, 2);
	}
	const customEndpointFunctions = {};
	const booleanEquals = (value1, value2) => value1 === value2;
	function coalesce(...args) {
		for (const arg of args) if (arg != null) return arg;
	}
	const getAttrPathList = (path) => {
		const parts = path.split(".");
		const pathList = [];
		for (const part of parts) {
			const squareBracketIndex = part.indexOf("[");
			if (squareBracketIndex !== -1) {
				if (part.indexOf("]") !== part.length - 1) throw new EndpointError(`Path: '${path}' does not end with ']'`);
				const arrayIndex = part.slice(squareBracketIndex + 1, -1);
				if (Number.isNaN(parseInt(arrayIndex))) throw new EndpointError(`Invalid array index: '${arrayIndex}' in path: '${path}'`);
				if (squareBracketIndex !== 0) pathList.push(part.slice(0, squareBracketIndex));
				pathList.push(arrayIndex);
			} else pathList.push(part);
		}
		return pathList;
	};
	const getAttr = (value, path) => getAttrPathList(path).reduce((acc, index) => {
		if (typeof acc !== "object") throw new EndpointError(`Index '${index}' in '${path}' not found in '${JSON.stringify(value)}'`);
		else if (Array.isArray(acc)) {
			const i = parseInt(index);
			return acc[i < 0 ? acc.length + i : i];
		}
		return acc[index];
	}, value);
	const isSet = (value) => value != null;
	const VALID_HOST_LABEL_REGEX = new RegExp(`^(?!.*-$)(?!-)[a-zA-Z0-9-]{1,63}$`);
	const isValidHostLabel = (value, allowSubDomains = false) => {
		if (!allowSubDomains) return VALID_HOST_LABEL_REGEX.test(value);
		const labels = value.split(".");
		for (const label of labels) if (!isValidHostLabel(label)) return false;
		return true;
	};
	function ite(condition, trueValue, falseValue) {
		return condition ? trueValue : falseValue;
	}
	const not = (value) => !value;
	const IP_V4_REGEX = new RegExp(`^(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}$`);
	const isIpAddress = (value) => IP_V4_REGEX.test(value) || value.startsWith("[") && value.endsWith("]");
	const DEFAULT_PORTS = {
		[types.EndpointURLScheme.HTTP]: 80,
		[types.EndpointURLScheme.HTTPS]: 443
	};
	const parseURL = (value) => {
		const whatwgURL = (() => {
			try {
				if (value instanceof URL) return value;
				if (typeof value === "object" && "hostname" in value) {
					const { hostname, port, protocol = "", path = "", query = {} } = value;
					const url = new URL(`${protocol}//${hostname}${port ? `:${port}` : ""}${path}`);
					url.search = Object.entries(query).map(([k, v]) => `${k}=${v}`).join("&");
					return url;
				}
				return new URL(value);
			} catch (error) {
				return null;
			}
		})();
		if (!whatwgURL) {
			console.error(`Unable to parse ${JSON.stringify(value)} as a whatwg URL.`);
			return null;
		}
		const urlString = whatwgURL.href;
		const { host, hostname, pathname, protocol, search } = whatwgURL;
		if (search) return null;
		const scheme = protocol.slice(0, -1);
		if (!Object.values(types.EndpointURLScheme).includes(scheme)) return null;
		const isIp = isIpAddress(hostname);
		return {
			scheme,
			authority: `${host}${urlString.includes(`${host}:${DEFAULT_PORTS[scheme]}`) || typeof value === "string" && value.includes(`${host}:${DEFAULT_PORTS[scheme]}`) ? `:${DEFAULT_PORTS[scheme]}` : ``}`,
			path: pathname,
			normalizedPath: pathname.endsWith("/") ? pathname : `${pathname}/`,
			isIp
		};
	};
	function split(value, delimiter, limit) {
		if (limit === 1) return [value];
		if (value === "") return [""];
		const parts = value.split(delimiter);
		if (limit === 0) return parts;
		return parts.slice(0, limit - 1).concat(parts.slice(1).join(delimiter));
	}
	const stringEquals = (value1, value2) => value1 === value2;
	const substring = (input, start, stop, reverse) => {
		if (input == null || start >= stop || input.length < stop || /[^\u0000-\u007f]/.test(input)) return null;
		if (!reverse) return input.substring(start, stop);
		return input.substring(input.length - stop, input.length - start);
	};
	const uriEncode = (value) => encodeURIComponent(value).replace(/[!*'()]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
	const endpointFunctions = {
		booleanEquals,
		coalesce,
		getAttr,
		isSet,
		isValidHostLabel,
		ite,
		not,
		parseURL,
		split,
		stringEquals,
		substring,
		uriEncode
	};
	const evaluateTemplate = (template, options) => {
		const evaluatedTemplateArr = [];
		const { referenceRecord, endpointParams } = options;
		let currentIndex = 0;
		while (currentIndex < template.length) {
			const openingBraceIndex = template.indexOf("{", currentIndex);
			if (openingBraceIndex === -1) {
				evaluatedTemplateArr.push(template.slice(currentIndex));
				break;
			}
			evaluatedTemplateArr.push(template.slice(currentIndex, openingBraceIndex));
			const closingBraceIndex = template.indexOf("}", openingBraceIndex);
			if (closingBraceIndex === -1) {
				evaluatedTemplateArr.push(template.slice(openingBraceIndex));
				break;
			}
			if (template[openingBraceIndex + 1] === "{" && template[closingBraceIndex + 1] === "}") {
				evaluatedTemplateArr.push(template.slice(openingBraceIndex + 1, closingBraceIndex));
				currentIndex = closingBraceIndex + 2;
			}
			const parameterName = template.substring(openingBraceIndex + 1, closingBraceIndex);
			if (parameterName.includes("#")) {
				const [refName, attrName] = parameterName.split("#");
				evaluatedTemplateArr.push(getAttr(referenceRecord[refName] ?? endpointParams[refName], attrName));
			} else evaluatedTemplateArr.push(referenceRecord[parameterName] ?? endpointParams[parameterName]);
			currentIndex = closingBraceIndex + 1;
		}
		return evaluatedTemplateArr.join("");
	};
	const getReferenceValue = ({ ref }, options) => {
		return options.referenceRecord[ref] ?? options.endpointParams[ref];
	};
	const evaluateExpression = (obj, keyName, options) => {
		if (typeof obj === "string") return evaluateTemplate(obj, options);
		else if (obj["fn"]) return group$2.callFunction(obj, options);
		else if (obj["ref"]) return getReferenceValue(obj, options);
		throw new EndpointError(`'${keyName}': ${String(obj)} is not a string, function or reference.`);
	};
	const callFunction = ({ fn, argv }, options) => {
		const evaluatedArgs = Array(argv.length);
		for (let i = 0; i < evaluatedArgs.length; ++i) {
			const arg = argv[i];
			if (typeof arg === "boolean" || typeof arg === "number") evaluatedArgs[i] = arg;
			else evaluatedArgs[i] = group$2.evaluateExpression(arg, "arg", options);
		}
		const namespaceSeparatorIndex = fn.indexOf(".");
		if (namespaceSeparatorIndex !== -1) {
			const customFunction = customEndpointFunctions[fn.slice(0, namespaceSeparatorIndex)]?.[fn.slice(namespaceSeparatorIndex + 1)];
			if (typeof customFunction === "function") return customFunction(...evaluatedArgs);
		}
		const callable = endpointFunctions[fn];
		if (typeof callable === "function") return callable(...evaluatedArgs);
		throw new Error(`function ${fn} not loaded in endpointFunctions.`);
	};
	const group$2 = {
		evaluateExpression,
		callFunction
	};
	const evaluateCondition = (condition, options) => {
		const { assign } = condition;
		if (assign && assign in options.referenceRecord) throw new EndpointError(`'${assign}' is already defined in Reference Record.`);
		const value = callFunction(condition, options);
		options.logger?.debug?.(`${debugId} evaluateCondition: ${toDebugString(condition)} = ${toDebugString(value)}`);
		const result = value === "" ? true : !!value;
		if (assign != null) return {
			result,
			toAssign: {
				name: assign,
				value
			}
		};
		return { result };
	};
	const getEndpointHeaders = (headers, options) => Object.entries(headers ?? {}).reduce((acc, [headerKey, headerVal]) => {
		acc[headerKey] = headerVal.map((headerValEntry) => {
			const processedExpr = evaluateExpression(headerValEntry, "Header value entry", options);
			if (typeof processedExpr !== "string") throw new EndpointError(`Header '${headerKey}' value '${processedExpr}' is not a string`);
			return processedExpr;
		});
		return acc;
	}, {});
	const getEndpointProperties = (properties, options) => Object.entries(properties).reduce((acc, [propertyKey, propertyVal]) => {
		acc[propertyKey] = group$1.getEndpointProperty(propertyVal, options);
		return acc;
	}, {});
	const getEndpointProperty = (property, options) => {
		if (Array.isArray(property)) return property.map((propertyEntry) => getEndpointProperty(propertyEntry, options));
		switch (typeof property) {
			case "string": return evaluateTemplate(property, options);
			case "object":
				if (property === null) throw new EndpointError(`Unexpected endpoint property: ${property}`);
				return group$1.getEndpointProperties(property, options);
			case "boolean": return property;
			default: throw new EndpointError(`Unexpected endpoint property type: ${typeof property}`);
		}
	};
	const group$1 = {
		getEndpointProperty,
		getEndpointProperties
	};
	const getEndpointUrl = (endpointUrl, options) => {
		const expression = evaluateExpression(endpointUrl, "Endpoint URL", options);
		if (typeof expression === "string") try {
			return new URL(expression);
		} catch (error) {
			console.error(`Failed to construct URL with ${expression}`, error);
			throw error;
		}
		throw new EndpointError(`Endpoint URL must be a string, got ${typeof expression}`);
	};
	const RESULT = 1e8;
	const decideEndpoint = (bdd, options) => {
		const { nodes, root, results, conditions } = bdd;
		let ref = root;
		const referenceRecord = {};
		const closure = {
			referenceRecord,
			endpointParams: options.endpointParams,
			logger: options.logger
		};
		while (ref !== 1 && ref !== -1 && ref < RESULT) {
			const node_i = 3 * (Math.abs(ref) - 1);
			const [condition_i, highRef, lowRef] = [
				nodes[node_i],
				nodes[node_i + 1],
				nodes[node_i + 2]
			];
			const [fn, argv, assign] = conditions[condition_i];
			const evaluation = evaluateCondition({
				fn,
				assign,
				argv
			}, closure);
			if (evaluation.toAssign) {
				const { name, value } = evaluation.toAssign;
				referenceRecord[name] = value;
			}
			ref = ref >= 0 === evaluation.result ? highRef : lowRef;
		}
		if (ref >= RESULT) {
			const result = results[ref - RESULT];
			if (result[0] === -1) {
				const [, errorExpression] = result;
				throw new EndpointError(evaluateExpression(errorExpression, "Error", closure));
			}
			const [url, properties, headers] = result;
			return {
				url: getEndpointUrl(url, closure),
				properties: getEndpointProperties(properties, closure),
				headers: getEndpointHeaders(headers ?? {}, closure)
			};
		}
		throw new EndpointError(`No matching endpoint.`);
	};
	const evaluateConditions = (conditions = [], options) => {
		const conditionsReferenceRecord = {};
		const conditionOptions = {
			...options,
			referenceRecord: { ...options.referenceRecord }
		};
		let didAssign = false;
		for (const condition of conditions) {
			const { result, toAssign } = evaluateCondition(condition, conditionOptions);
			if (!result) return { result };
			if (toAssign) {
				didAssign = true;
				conditionsReferenceRecord[toAssign.name] = toAssign.value;
				conditionOptions.referenceRecord[toAssign.name] = toAssign.value;
				options.logger?.debug?.(`${debugId} assign: ${toAssign.name} := ${toDebugString(toAssign.value)}`);
			}
		}
		if (didAssign) return {
			result: true,
			referenceRecord: conditionsReferenceRecord
		};
		return { result: true };
	};
	const evaluateEndpointRule = (endpointRule, options) => {
		const { conditions, endpoint } = endpointRule;
		const { result, referenceRecord } = evaluateConditions(conditions, options);
		if (!result) return;
		const endpointRuleOptions = referenceRecord ? {
			...options,
			referenceRecord: {
				...options.referenceRecord,
				...referenceRecord
			}
		} : options;
		const { url, properties, headers } = endpoint;
		options.logger?.debug?.(`${debugId} Resolving endpoint from template: ${toDebugString(endpoint)}`);
		const endpointToReturn = { url: getEndpointUrl(url, endpointRuleOptions) };
		if (headers != null) endpointToReturn.headers = getEndpointHeaders(headers, endpointRuleOptions);
		if (properties != null) endpointToReturn.properties = getEndpointProperties(properties, endpointRuleOptions);
		return endpointToReturn;
	};
	const evaluateErrorRule = (errorRule, options) => {
		const { conditions, error } = errorRule;
		const { result, referenceRecord } = evaluateConditions(conditions, options);
		if (!result) return;
		throw new EndpointError(evaluateExpression(error, "Error", referenceRecord ? {
			...options,
			referenceRecord: {
				...options.referenceRecord,
				...referenceRecord
			}
		} : options));
	};
	const evaluateRules = (rules, options) => {
		for (const rule of rules) if (rule.type === "endpoint") {
			const endpointOrUndefined = evaluateEndpointRule(rule, options);
			if (endpointOrUndefined) return endpointOrUndefined;
		} else if (rule.type === "error") evaluateErrorRule(rule, options);
		else if (rule.type === "tree") {
			const endpointOrUndefined = group.evaluateTreeRule(rule, options);
			if (endpointOrUndefined) return endpointOrUndefined;
		} else throw new EndpointError(`Unknown endpoint rule: ${rule}`);
		throw new EndpointError(`Rules evaluation failed`);
	};
	const evaluateTreeRule = (treeRule, options) => {
		const { conditions, rules } = treeRule;
		const { result, referenceRecord } = evaluateConditions(conditions, options);
		if (!result) return;
		const treeRuleOptions = referenceRecord ? {
			...options,
			referenceRecord: {
				...options.referenceRecord,
				...referenceRecord
			}
		} : options;
		return group.evaluateRules(rules, treeRuleOptions);
	};
	const group = {
		evaluateRules,
		evaluateTreeRule
	};
	const resolveEndpoint = (ruleSetObject, options) => {
		const { endpointParams, logger } = options;
		const { parameters, rules } = ruleSetObject;
		options.logger?.debug?.(`${debugId} Initial EndpointParams: ${toDebugString(endpointParams)}`);
		for (const paramKey in parameters) {
			const parameter = parameters[paramKey];
			const endpointParam = endpointParams[paramKey];
			if (endpointParam == null && parameter.default != null) {
				endpointParams[paramKey] = parameter.default;
				continue;
			}
			if (parameter.required && endpointParam == null) throw new EndpointError(`Missing required parameter: '${paramKey}'`);
		}
		const endpoint = evaluateRules(rules, {
			endpointParams,
			logger,
			referenceRecord: {}
		});
		options.logger?.debug?.(`${debugId} Resolved endpoint: ${toDebugString(endpoint)}`);
		return endpoint;
	};
	exports.BinaryDecisionDiagram = BinaryDecisionDiagram;
	exports.EndpointCache = EndpointCache;
	exports.EndpointError = EndpointError;
	exports.customEndpointFunctions = customEndpointFunctions;
	exports.decideEndpoint = decideEndpoint;
	exports.isIpAddress = isIpAddress;
	exports.isValidHostLabel = isValidHostLabel;
	exports.resolveEndpoint = resolveEndpoint;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+util-endpoints@3.996.8/node_modules/@aws-sdk/util-endpoints/dist-cjs/index.js
var require_dist_cjs$14 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var utilEndpoints = require_dist_cjs$15();
	var urlParser = require_dist_cjs$40.require_dist_cjs();
	const isVirtualHostableS3Bucket = (value, allowSubDomains = false) => {
		if (allowSubDomains) {
			for (const label of value.split(".")) if (!isVirtualHostableS3Bucket(label)) return false;
			return true;
		}
		if (!utilEndpoints.isValidHostLabel(value)) return false;
		if (value.length < 3 || value.length > 63) return false;
		if (value !== value.toLowerCase()) return false;
		if (utilEndpoints.isIpAddress(value)) return false;
		return true;
	};
	const ARN_DELIMITER = ":";
	const RESOURCE_DELIMITER = "/";
	const parseArn = (value) => {
		const segments = value.split(ARN_DELIMITER);
		if (segments.length < 6) return null;
		const [arn, partition, service, region, accountId, ...resourcePath] = segments;
		if (arn !== "arn" || partition === "" || service === "" || resourcePath.join(ARN_DELIMITER) === "") return null;
		return {
			partition,
			service,
			region,
			accountId,
			resourceId: resourcePath.map((resource) => resource.split(RESOURCE_DELIMITER)).flat()
		};
	};
	var partitionsInfo = {
		partitions: [
			{
				id: "aws",
				outputs: {
					dnsSuffix: "amazonaws.com",
					dualStackDnsSuffix: "api.aws",
					implicitGlobalRegion: "us-east-1",
					name: "aws",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^(us|eu|ap|sa|ca|me|af|il|mx)\\-\\w+\\-\\d+$",
				regions: {
					"af-south-1": { description: "Africa (Cape Town)" },
					"ap-east-1": { description: "Asia Pacific (Hong Kong)" },
					"ap-east-2": { description: "Asia Pacific (Taipei)" },
					"ap-northeast-1": { description: "Asia Pacific (Tokyo)" },
					"ap-northeast-2": { description: "Asia Pacific (Seoul)" },
					"ap-northeast-3": { description: "Asia Pacific (Osaka)" },
					"ap-south-1": { description: "Asia Pacific (Mumbai)" },
					"ap-south-2": { description: "Asia Pacific (Hyderabad)" },
					"ap-southeast-1": { description: "Asia Pacific (Singapore)" },
					"ap-southeast-2": { description: "Asia Pacific (Sydney)" },
					"ap-southeast-3": { description: "Asia Pacific (Jakarta)" },
					"ap-southeast-4": { description: "Asia Pacific (Melbourne)" },
					"ap-southeast-5": { description: "Asia Pacific (Malaysia)" },
					"ap-southeast-6": { description: "Asia Pacific (New Zealand)" },
					"ap-southeast-7": { description: "Asia Pacific (Thailand)" },
					"aws-global": { description: "aws global region" },
					"ca-central-1": { description: "Canada (Central)" },
					"ca-west-1": { description: "Canada West (Calgary)" },
					"eu-central-1": { description: "Europe (Frankfurt)" },
					"eu-central-2": { description: "Europe (Zurich)" },
					"eu-north-1": { description: "Europe (Stockholm)" },
					"eu-south-1": { description: "Europe (Milan)" },
					"eu-south-2": { description: "Europe (Spain)" },
					"eu-west-1": { description: "Europe (Ireland)" },
					"eu-west-2": { description: "Europe (London)" },
					"eu-west-3": { description: "Europe (Paris)" },
					"il-central-1": { description: "Israel (Tel Aviv)" },
					"me-central-1": { description: "Middle East (UAE)" },
					"me-south-1": { description: "Middle East (Bahrain)" },
					"mx-central-1": { description: "Mexico (Central)" },
					"sa-east-1": { description: "South America (Sao Paulo)" },
					"us-east-1": { description: "US East (N. Virginia)" },
					"us-east-2": { description: "US East (Ohio)" },
					"us-west-1": { description: "US West (N. California)" },
					"us-west-2": { description: "US West (Oregon)" }
				}
			},
			{
				id: "aws-cn",
				outputs: {
					dnsSuffix: "amazonaws.com.cn",
					dualStackDnsSuffix: "api.amazonwebservices.com.cn",
					implicitGlobalRegion: "cn-northwest-1",
					name: "aws-cn",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^cn\\-\\w+\\-\\d+$",
				regions: {
					"aws-cn-global": { description: "aws-cn global region" },
					"cn-north-1": { description: "China (Beijing)" },
					"cn-northwest-1": { description: "China (Ningxia)" }
				}
			},
			{
				id: "aws-eusc",
				outputs: {
					dnsSuffix: "amazonaws.eu",
					dualStackDnsSuffix: "api.amazonwebservices.eu",
					implicitGlobalRegion: "eusc-de-east-1",
					name: "aws-eusc",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^eusc\\-(de)\\-\\w+\\-\\d+$",
				regions: { "eusc-de-east-1": { description: "AWS European Sovereign Cloud (Germany)" } }
			},
			{
				id: "aws-iso",
				outputs: {
					dnsSuffix: "c2s.ic.gov",
					dualStackDnsSuffix: "api.aws.ic.gov",
					implicitGlobalRegion: "us-iso-east-1",
					name: "aws-iso",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^us\\-iso\\-\\w+\\-\\d+$",
				regions: {
					"aws-iso-global": { description: "aws-iso global region" },
					"us-iso-east-1": { description: "US ISO East" },
					"us-iso-west-1": { description: "US ISO WEST" }
				}
			},
			{
				id: "aws-iso-b",
				outputs: {
					dnsSuffix: "sc2s.sgov.gov",
					dualStackDnsSuffix: "api.aws.scloud",
					implicitGlobalRegion: "us-isob-east-1",
					name: "aws-iso-b",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^us\\-isob\\-\\w+\\-\\d+$",
				regions: {
					"aws-iso-b-global": { description: "aws-iso-b global region" },
					"us-isob-east-1": { description: "US ISOB East (Ohio)" },
					"us-isob-west-1": { description: "US ISOB West" }
				}
			},
			{
				id: "aws-iso-e",
				outputs: {
					dnsSuffix: "cloud.adc-e.uk",
					dualStackDnsSuffix: "api.cloud-aws.adc-e.uk",
					implicitGlobalRegion: "eu-isoe-west-1",
					name: "aws-iso-e",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^eu\\-isoe\\-\\w+\\-\\d+$",
				regions: {
					"aws-iso-e-global": { description: "aws-iso-e global region" },
					"eu-isoe-west-1": { description: "EU ISOE West" }
				}
			},
			{
				id: "aws-iso-f",
				outputs: {
					dnsSuffix: "csp.hci.ic.gov",
					dualStackDnsSuffix: "api.aws.hci.ic.gov",
					implicitGlobalRegion: "us-isof-south-1",
					name: "aws-iso-f",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^us\\-isof\\-\\w+\\-\\d+$",
				regions: {
					"aws-iso-f-global": { description: "aws-iso-f global region" },
					"us-isof-east-1": { description: "US ISOF EAST" },
					"us-isof-south-1": { description: "US ISOF SOUTH" }
				}
			},
			{
				id: "aws-us-gov",
				outputs: {
					dnsSuffix: "amazonaws.com",
					dualStackDnsSuffix: "api.aws",
					implicitGlobalRegion: "us-gov-west-1",
					name: "aws-us-gov",
					supportsDualStack: true,
					supportsFIPS: true
				},
				regionRegex: "^us\\-gov\\-\\w+\\-\\d+$",
				regions: {
					"aws-us-gov-global": { description: "aws-us-gov global region" },
					"us-gov-east-1": { description: "AWS GovCloud (US-East)" },
					"us-gov-west-1": { description: "AWS GovCloud (US-West)" }
				}
			}
		],
		version: "1.1"
	};
	let selectedPartitionsInfo = partitionsInfo;
	let selectedUserAgentPrefix = "";
	const partition = (value) => {
		const { partitions } = selectedPartitionsInfo;
		for (const partition of partitions) {
			const { regions, outputs } = partition;
			for (const [region, regionData] of Object.entries(regions)) if (region === value) return {
				...outputs,
				...regionData
			};
		}
		for (const partition of partitions) {
			const { regionRegex, outputs } = partition;
			if (new RegExp(regionRegex).test(value)) return { ...outputs };
		}
		const DEFAULT_PARTITION = partitions.find((partition) => partition.id === "aws");
		if (!DEFAULT_PARTITION) throw new Error("Provided region was not found in the partition array or regex, and default partition with id 'aws' doesn't exist.");
		return { ...DEFAULT_PARTITION.outputs };
	};
	const setPartitionInfo = (partitionsInfo, userAgentPrefix = "") => {
		selectedPartitionsInfo = partitionsInfo;
		selectedUserAgentPrefix = userAgentPrefix;
	};
	const useDefaultPartitionInfo = () => {
		setPartitionInfo(partitionsInfo, "");
	};
	const getUserAgentPrefix = () => selectedUserAgentPrefix;
	const awsEndpointFunctions = {
		isVirtualHostableS3Bucket,
		parseArn,
		partition
	};
	utilEndpoints.customEndpointFunctions.aws = awsEndpointFunctions;
	const resolveDefaultAwsRegionalEndpointsConfig = (input) => {
		if (typeof input.endpointProvider !== "function") throw new Error("@aws-sdk/util-endpoint - endpointProvider and endpoint missing in config for this client.");
		const { endpoint } = input;
		if (endpoint === void 0) input.endpoint = async () => {
			return toEndpointV1(input.endpointProvider({
				Region: typeof input.region === "function" ? await input.region() : input.region,
				UseDualStack: typeof input.useDualstackEndpoint === "function" ? await input.useDualstackEndpoint() : input.useDualstackEndpoint,
				UseFIPS: typeof input.useFipsEndpoint === "function" ? await input.useFipsEndpoint() : input.useFipsEndpoint,
				Endpoint: void 0
			}, { logger: input.logger }));
		};
		return input;
	};
	const toEndpointV1 = (endpoint) => urlParser.parseUrl(endpoint.url);
	exports.EndpointError = utilEndpoints.EndpointError;
	exports.isIpAddress = utilEndpoints.isIpAddress;
	exports.resolveEndpoint = utilEndpoints.resolveEndpoint;
	exports.awsEndpointFunctions = awsEndpointFunctions;
	exports.getUserAgentPrefix = getUserAgentPrefix;
	exports.partition = partition;
	exports.resolveDefaultAwsRegionalEndpointsConfig = resolveDefaultAwsRegionalEndpointsConfig;
	exports.setPartitionInfo = setPartitionInfo;
	exports.toEndpointV1 = toEndpointV1;
	exports.useDefaultPartitionInfo = useDefaultPartitionInfo;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+middleware-user-agent@3.972.38/node_modules/@aws-sdk/middleware-user-agent/dist-cjs/index.js
var require_dist_cjs$13 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var core = (init_dist_es(), require_chunk.__toCommonJS(dist_es_exports));
	var utilEndpoints = require_dist_cjs$14();
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	var client = (require_client.init_client(), require_chunk.__toCommonJS(require_client.client_exports));
	var utilRetry = require_client.require_dist_cjs();
	const DEFAULT_UA_APP_ID = void 0;
	function isValidUserAgentAppId(appId) {
		if (appId === void 0) return true;
		return typeof appId === "string" && appId.length <= 50;
	}
	function resolveUserAgentConfig(input) {
		const normalizedAppIdProvider = core.normalizeProvider(input.userAgentAppId ?? DEFAULT_UA_APP_ID);
		const { customUserAgent } = input;
		return Object.assign(input, {
			customUserAgent: typeof customUserAgent === "string" ? [[customUserAgent]] : customUserAgent,
			userAgentAppId: async () => {
				const appId = await normalizedAppIdProvider();
				if (!isValidUserAgentAppId(appId)) {
					const logger = input.logger?.constructor?.name === "NoOpLogger" || !input.logger ? console : input.logger;
					if (typeof appId !== "string") logger?.warn("userAgentAppId must be a string or undefined.");
					else if (appId.length > 50) logger?.warn("The provided userAgentAppId exceeds the maximum length of 50 characters.");
				}
				return appId;
			}
		});
	}
	const ACCOUNT_ID_ENDPOINT_REGEX = /\d{12}\.ddb/;
	async function checkFeatures(context, config, args) {
		if (args.request?.headers?.["smithy-protocol"] === "rpc-v2-cbor") client.setFeature(context, "PROTOCOL_RPC_V2_CBOR", "M");
		if (typeof config.retryStrategy === "function") {
			const retryStrategy = await config.retryStrategy();
			if (typeof retryStrategy.mode === "string") switch (retryStrategy.mode) {
				case utilRetry.RETRY_MODES.ADAPTIVE:
					client.setFeature(context, "RETRY_MODE_ADAPTIVE", "F");
					break;
				case utilRetry.RETRY_MODES.STANDARD:
					client.setFeature(context, "RETRY_MODE_STANDARD", "E");
					break;
			}
		}
		if (typeof config.accountIdEndpointMode === "function") {
			const endpointV2 = context.endpointV2;
			if (String(endpointV2?.url?.hostname).match(ACCOUNT_ID_ENDPOINT_REGEX)) client.setFeature(context, "ACCOUNT_ID_ENDPOINT", "O");
			switch (await config.accountIdEndpointMode?.()) {
				case "disabled":
					client.setFeature(context, "ACCOUNT_ID_MODE_DISABLED", "Q");
					break;
				case "preferred":
					client.setFeature(context, "ACCOUNT_ID_MODE_PREFERRED", "P");
					break;
				case "required":
					client.setFeature(context, "ACCOUNT_ID_MODE_REQUIRED", "R");
					break;
			}
		}
		const identity = context.__smithy_context?.selectedHttpAuthScheme?.identity;
		if (identity?.$source) {
			const credentials = identity;
			if (credentials.accountId) client.setFeature(context, "RESOLVED_ACCOUNT_ID", "T");
			for (const [key, value] of Object.entries(credentials.$source ?? {})) client.setFeature(context, key, value);
		}
	}
	const USER_AGENT = "user-agent";
	const X_AMZ_USER_AGENT = "x-amz-user-agent";
	const SPACE = " ";
	const UA_NAME_SEPARATOR = "/";
	const UA_NAME_ESCAPE_REGEX = /[^!$%&'*+\-.^_`|~\w]/g;
	const UA_VALUE_ESCAPE_REGEX = /[^!$%&'*+\-.^_`|~\w#]/g;
	const UA_ESCAPE_CHAR = "-";
	const BYTE_LIMIT = 1024;
	function encodeFeatures(features) {
		let buffer = "";
		for (const key in features) {
			const val = features[key];
			if (buffer.length + val.length + 1 <= BYTE_LIMIT) {
				if (buffer.length) buffer += "," + val;
				else buffer += val;
				continue;
			}
			break;
		}
		return buffer;
	}
	const userAgentMiddleware = (options) => (next, context) => async (args) => {
		const { request } = args;
		if (!protocolHttp.HttpRequest.isInstance(request)) return next(args);
		const { headers } = request;
		const userAgent = context?.userAgent?.map(escapeUserAgent) || [];
		const defaultUserAgent = (await options.defaultUserAgentProvider()).map(escapeUserAgent);
		await checkFeatures(context, options, args);
		const awsContext = context;
		defaultUserAgent.push(`m/${encodeFeatures(Object.assign({}, context.__smithy_context?.features, awsContext.__aws_sdk_context?.features))}`);
		const customUserAgent = options?.customUserAgent?.map(escapeUserAgent) || [];
		const appId = await options.userAgentAppId();
		if (appId) defaultUserAgent.push(escapeUserAgent([`app`, `${appId}`]));
		const prefix = utilEndpoints.getUserAgentPrefix();
		const sdkUserAgentValue = (prefix ? [prefix] : []).concat([
			...defaultUserAgent,
			...userAgent,
			...customUserAgent
		]).join(SPACE);
		const normalUAValue = [...defaultUserAgent.filter((section) => section.startsWith("aws-sdk-")), ...customUserAgent].join(SPACE);
		if (options.runtime !== "browser") {
			if (normalUAValue) headers[X_AMZ_USER_AGENT] = headers[X_AMZ_USER_AGENT] ? `${headers[USER_AGENT]} ${normalUAValue}` : normalUAValue;
			headers[USER_AGENT] = sdkUserAgentValue;
		} else headers[X_AMZ_USER_AGENT] = sdkUserAgentValue;
		return next({
			...args,
			request
		});
	};
	const escapeUserAgent = (userAgentPair) => {
		const name = userAgentPair[0].split(UA_NAME_SEPARATOR).map((part) => part.replace(UA_NAME_ESCAPE_REGEX, UA_ESCAPE_CHAR)).join(UA_NAME_SEPARATOR);
		const version = userAgentPair[1]?.replace(UA_VALUE_ESCAPE_REGEX, UA_ESCAPE_CHAR);
		const prefixSeparatorIndex = name.indexOf(UA_NAME_SEPARATOR);
		const prefix = name.substring(0, prefixSeparatorIndex);
		let uaName = name.substring(prefixSeparatorIndex + 1);
		if (prefix === "api") uaName = uaName.toLowerCase();
		return [
			prefix,
			uaName,
			version
		].filter((item) => item && item.length > 0).reduce((acc, item, index) => {
			switch (index) {
				case 0: return item;
				case 1: return `${acc}/${item}`;
				default: return `${acc}#${item}`;
			}
		}, "");
	};
	const getUserAgentMiddlewareOptions = {
		name: "getUserAgentMiddleware",
		step: "build",
		priority: "low",
		tags: ["SET_USER_AGENT", "USER_AGENT"],
		override: true
	};
	const getUserAgentPlugin = (config) => ({ applyToStack: (clientStack) => {
		clientStack.add(userAgentMiddleware(config), getUserAgentMiddlewareOptions);
	} });
	exports.DEFAULT_UA_APP_ID = DEFAULT_UA_APP_ID;
	exports.getUserAgentMiddlewareOptions = getUserAgentMiddlewareOptions;
	exports.getUserAgentPlugin = getUserAgentPlugin;
	exports.resolveUserAgentConfig = resolveUserAgentConfig;
	exports.userAgentMiddleware = userAgentMiddleware;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+util-config-provider@4.2.2/node_modules/@smithy/util-config-provider/dist-cjs/index.js
var require_dist_cjs$12 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	const booleanSelector = (obj, key, type) => {
		if (!(key in obj)) return void 0;
		if (obj[key] === "true") return true;
		if (obj[key] === "false") return false;
		throw new Error(`Cannot load ${type} "${key}". Expected "true" or "false", got ${obj[key]}.`);
	};
	const numberSelector = (obj, key, type) => {
		if (!(key in obj)) return void 0;
		const numberValue = parseInt(obj[key], 10);
		if (Number.isNaN(numberValue)) throw new TypeError(`Cannot load ${type} '${key}'. Expected number, got '${obj[key]}'.`);
		return numberValue;
	};
	exports.SelectorType = void 0;
	(function(SelectorType) {
		SelectorType["ENV"] = "env";
		SelectorType["CONFIG"] = "shared config entry";
	})(exports.SelectorType || (exports.SelectorType = {}));
	exports.booleanSelector = booleanSelector;
	exports.numberSelector = numberSelector;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+config-resolver@4.4.17/node_modules/@smithy/config-resolver/dist-cjs/index.js
var require_dist_cjs$11 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var utilConfigProvider = require_dist_cjs$12();
	var utilMiddleware = require_dist_cjs$38.require_dist_cjs$7();
	var utilEndpoints = require_dist_cjs$15();
	const ENV_USE_DUALSTACK_ENDPOINT = "AWS_USE_DUALSTACK_ENDPOINT";
	const CONFIG_USE_DUALSTACK_ENDPOINT = "use_dualstack_endpoint";
	const DEFAULT_USE_DUALSTACK_ENDPOINT = false;
	const NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => utilConfigProvider.booleanSelector(env, ENV_USE_DUALSTACK_ENDPOINT, utilConfigProvider.SelectorType.ENV),
		configFileSelector: (profile) => utilConfigProvider.booleanSelector(profile, CONFIG_USE_DUALSTACK_ENDPOINT, utilConfigProvider.SelectorType.CONFIG),
		default: false
	};
	const nodeDualstackConfigSelectors = {
		environmentVariableSelector: (env) => utilConfigProvider.booleanSelector(env, ENV_USE_DUALSTACK_ENDPOINT, utilConfigProvider.SelectorType.ENV),
		configFileSelector: (profile) => utilConfigProvider.booleanSelector(profile, CONFIG_USE_DUALSTACK_ENDPOINT, utilConfigProvider.SelectorType.CONFIG),
		default: void 0
	};
	const ENV_USE_FIPS_ENDPOINT = "AWS_USE_FIPS_ENDPOINT";
	const CONFIG_USE_FIPS_ENDPOINT = "use_fips_endpoint";
	const DEFAULT_USE_FIPS_ENDPOINT = false;
	const NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => utilConfigProvider.booleanSelector(env, ENV_USE_FIPS_ENDPOINT, utilConfigProvider.SelectorType.ENV),
		configFileSelector: (profile) => utilConfigProvider.booleanSelector(profile, CONFIG_USE_FIPS_ENDPOINT, utilConfigProvider.SelectorType.CONFIG),
		default: false
	};
	const nodeFipsConfigSelectors = {
		environmentVariableSelector: (env) => utilConfigProvider.booleanSelector(env, ENV_USE_FIPS_ENDPOINT, utilConfigProvider.SelectorType.ENV),
		configFileSelector: (profile) => utilConfigProvider.booleanSelector(profile, CONFIG_USE_FIPS_ENDPOINT, utilConfigProvider.SelectorType.CONFIG),
		default: void 0
	};
	const resolveCustomEndpointsConfig = (input) => {
		const { tls, endpoint, urlParser, useDualstackEndpoint } = input;
		return Object.assign(input, {
			tls: tls ?? true,
			endpoint: utilMiddleware.normalizeProvider(typeof endpoint === "string" ? urlParser(endpoint) : endpoint),
			isCustomEndpoint: true,
			useDualstackEndpoint: utilMiddleware.normalizeProvider(useDualstackEndpoint ?? false)
		});
	};
	const getEndpointFromRegion = async (input) => {
		const { tls = true } = input;
		const region = await input.region();
		if (!(/* @__PURE__ */ new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/)).test(region)) throw new Error("Invalid region in client config");
		const useDualstackEndpoint = await input.useDualstackEndpoint();
		const useFipsEndpoint = await input.useFipsEndpoint();
		const { hostname } = await input.regionInfoProvider(region, {
			useDualstackEndpoint,
			useFipsEndpoint
		}) ?? {};
		if (!hostname) throw new Error("Cannot resolve hostname from client config");
		return input.urlParser(`${tls ? "https:" : "http:"}//${hostname}`);
	};
	const resolveEndpointsConfig = (input) => {
		const useDualstackEndpoint = utilMiddleware.normalizeProvider(input.useDualstackEndpoint ?? false);
		const { endpoint, useFipsEndpoint, urlParser, tls } = input;
		return Object.assign(input, {
			tls: tls ?? true,
			endpoint: endpoint ? utilMiddleware.normalizeProvider(typeof endpoint === "string" ? urlParser(endpoint) : endpoint) : () => getEndpointFromRegion({
				...input,
				useDualstackEndpoint,
				useFipsEndpoint
			}),
			isCustomEndpoint: !!endpoint,
			useDualstackEndpoint
		});
	};
	const REGION_ENV_NAME = "AWS_REGION";
	const REGION_INI_NAME = "region";
	const NODE_REGION_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => env[REGION_ENV_NAME],
		configFileSelector: (profile) => profile[REGION_INI_NAME],
		default: () => {
			throw new Error("Region is missing");
		}
	};
	const NODE_REGION_CONFIG_FILE_OPTIONS = { preferredFile: "credentials" };
	const validRegions = /* @__PURE__ */ new Set();
	const checkRegion = (region, check = utilEndpoints.isValidHostLabel) => {
		if (!validRegions.has(region) && !check(region)) if (region === "*") console.warn(`@smithy/config-resolver WARN - Please use the caller region instead of "*". See "sigv4a" in https://github.com/aws/aws-sdk-js-v3/blob/main/supplemental-docs/CLIENTS.md.`);
		else throw new Error(`Region not accepted: region="${region}" is not a valid hostname component.`);
		else validRegions.add(region);
	};
	const isFipsRegion = (region) => typeof region === "string" && (region.startsWith("fips-") || region.endsWith("-fips"));
	const getRealRegion = (region) => isFipsRegion(region) ? ["fips-aws-global", "aws-fips"].includes(region) ? "us-east-1" : region.replace(/fips-(dkr-|prod-)?|-fips/, "") : region;
	const resolveRegionConfig = (input) => {
		const { region, useFipsEndpoint } = input;
		if (!region) throw new Error("Region is missing");
		return Object.assign(input, {
			region: async () => {
				const realRegion = getRealRegion(typeof region === "function" ? await region() : region);
				checkRegion(realRegion);
				return realRegion;
			},
			useFipsEndpoint: async () => {
				if (isFipsRegion(typeof region === "string" ? region : await region())) return true;
				return typeof useFipsEndpoint !== "function" ? Promise.resolve(!!useFipsEndpoint) : useFipsEndpoint();
			}
		});
	};
	const getHostnameFromVariants = (variants = [], { useFipsEndpoint, useDualstackEndpoint }) => variants.find(({ tags }) => useFipsEndpoint === tags.includes("fips") && useDualstackEndpoint === tags.includes("dualstack"))?.hostname;
	const getResolvedHostname = (resolvedRegion, { regionHostname, partitionHostname }) => regionHostname ? regionHostname : partitionHostname ? partitionHostname.replace("{region}", resolvedRegion) : void 0;
	const getResolvedPartition = (region, { partitionHash }) => Object.keys(partitionHash || {}).find((key) => partitionHash[key].regions.includes(region)) ?? "aws";
	const getResolvedSigningRegion = (hostname, { signingRegion, regionRegex, useFipsEndpoint }) => {
		if (signingRegion) return signingRegion;
		else if (useFipsEndpoint) {
			const regionRegexJs = regionRegex.replace("\\\\", "\\").replace(/^\^/g, "\\.").replace(/\$$/g, "\\.");
			const regionRegexmatchArray = hostname.match(regionRegexJs);
			if (regionRegexmatchArray) return regionRegexmatchArray[0].slice(1, -1);
		}
	};
	const getRegionInfo = (region, { useFipsEndpoint = false, useDualstackEndpoint = false, signingService, regionHash, partitionHash }) => {
		const partition = getResolvedPartition(region, { partitionHash });
		const resolvedRegion = region in regionHash ? region : partitionHash[partition]?.endpoint ?? region;
		const hostnameOptions = {
			useFipsEndpoint,
			useDualstackEndpoint
		};
		const hostname = getResolvedHostname(resolvedRegion, {
			regionHostname: getHostnameFromVariants(regionHash[resolvedRegion]?.variants, hostnameOptions),
			partitionHostname: getHostnameFromVariants(partitionHash[partition]?.variants, hostnameOptions)
		});
		if (hostname === void 0) throw new Error(`Endpoint resolution failed for: [object Object]`);
		const signingRegion = getResolvedSigningRegion(hostname, {
			signingRegion: regionHash[resolvedRegion]?.signingRegion,
			regionRegex: partitionHash[partition].regionRegex,
			useFipsEndpoint
		});
		return {
			partition,
			signingService,
			hostname,
			...signingRegion && { signingRegion },
			...regionHash[resolvedRegion]?.signingService && { signingService: regionHash[resolvedRegion].signingService }
		};
	};
	exports.CONFIG_USE_DUALSTACK_ENDPOINT = CONFIG_USE_DUALSTACK_ENDPOINT;
	exports.CONFIG_USE_FIPS_ENDPOINT = CONFIG_USE_FIPS_ENDPOINT;
	exports.DEFAULT_USE_DUALSTACK_ENDPOINT = DEFAULT_USE_DUALSTACK_ENDPOINT;
	exports.DEFAULT_USE_FIPS_ENDPOINT = DEFAULT_USE_FIPS_ENDPOINT;
	exports.ENV_USE_DUALSTACK_ENDPOINT = ENV_USE_DUALSTACK_ENDPOINT;
	exports.ENV_USE_FIPS_ENDPOINT = ENV_USE_FIPS_ENDPOINT;
	exports.NODE_REGION_CONFIG_FILE_OPTIONS = NODE_REGION_CONFIG_FILE_OPTIONS;
	exports.NODE_REGION_CONFIG_OPTIONS = NODE_REGION_CONFIG_OPTIONS;
	exports.NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS = NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS;
	exports.NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS = NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS;
	exports.REGION_ENV_NAME = REGION_ENV_NAME;
	exports.REGION_INI_NAME = REGION_INI_NAME;
	exports.getRegionInfo = getRegionInfo;
	exports.nodeDualstackConfigSelectors = nodeDualstackConfigSelectors;
	exports.nodeFipsConfigSelectors = nodeFipsConfigSelectors;
	exports.resolveCustomEndpointsConfig = resolveCustomEndpointsConfig;
	exports.resolveEndpointsConfig = resolveEndpointsConfig;
	exports.resolveRegionConfig = resolveRegionConfig;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-content-length@4.2.14/node_modules/@smithy/middleware-content-length/dist-cjs/index.js
var require_dist_cjs$10 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	const CONTENT_LENGTH_HEADER = "content-length";
	function contentLengthMiddleware(bodyLengthChecker) {
		return (next) => async (args) => {
			const request = args.request;
			if (protocolHttp.HttpRequest.isInstance(request)) {
				const { body, headers } = request;
				if (body && Object.keys(headers).map((str) => str.toLowerCase()).indexOf(CONTENT_LENGTH_HEADER) === -1) try {
					const length = bodyLengthChecker(body);
					request.headers = {
						...request.headers,
						[CONTENT_LENGTH_HEADER]: String(length)
					};
				} catch (error) {}
			}
			return next({
				...args,
				request
			});
		};
	}
	const contentLengthMiddlewareOptions = {
		step: "build",
		tags: ["SET_CONTENT_LENGTH", "CONTENT_LENGTH"],
		name: "contentLengthMiddleware",
		override: true
	};
	const getContentLengthPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.add(contentLengthMiddleware(options.bodyLengthChecker), contentLengthMiddlewareOptions);
	} });
	exports.contentLengthMiddleware = contentLengthMiddleware;
	exports.contentLengthMiddlewareOptions = contentLengthMiddlewareOptions;
	exports.getContentLengthPlugin = getContentLengthPlugin;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-endpoint@4.4.32/node_modules/@smithy/middleware-endpoint/dist-cjs/adaptors/getEndpointUrlConfig.js
var require_getEndpointUrlConfig = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.getEndpointUrlConfig = void 0;
	const shared_ini_file_loader_1 = require_dist_cjs$42.require_dist_cjs();
	const ENV_ENDPOINT_URL = "AWS_ENDPOINT_URL";
	const CONFIG_ENDPOINT_URL = "endpoint_url";
	const getEndpointUrlConfig = (serviceId) => ({
		environmentVariableSelector: (env) => {
			const serviceEndpointUrl = env[[ENV_ENDPOINT_URL, ...serviceId.split(" ").map((w) => w.toUpperCase())].join("_")];
			if (serviceEndpointUrl) return serviceEndpointUrl;
			const endpointUrl = env[ENV_ENDPOINT_URL];
			if (endpointUrl) return endpointUrl;
		},
		configFileSelector: (profile, config) => {
			if (config && profile.services) {
				const servicesSection = config[["services", profile.services].join(shared_ini_file_loader_1.CONFIG_PREFIX_SEPARATOR)];
				if (servicesSection) {
					const endpointUrl = servicesSection[[serviceId.split(" ").map((w) => w.toLowerCase()).join("_"), CONFIG_ENDPOINT_URL].join(shared_ini_file_loader_1.CONFIG_PREFIX_SEPARATOR)];
					if (endpointUrl) return endpointUrl;
				}
			}
			const endpointUrl = profile[CONFIG_ENDPOINT_URL];
			if (endpointUrl) return endpointUrl;
		},
		default: void 0
	});
	exports.getEndpointUrlConfig = getEndpointUrlConfig;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-endpoint@4.4.32/node_modules/@smithy/middleware-endpoint/dist-cjs/adaptors/getEndpointFromConfig.js
var require_getEndpointFromConfig = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.getEndpointFromConfig = void 0;
	const node_config_provider_1 = require_dist_cjs$43.require_dist_cjs();
	const getEndpointUrlConfig_1 = require_getEndpointUrlConfig();
	const getEndpointFromConfig = async (serviceId) => (0, node_config_provider_1.loadConfig)((0, getEndpointUrlConfig_1.getEndpointUrlConfig)(serviceId ?? ""))();
	exports.getEndpointFromConfig = getEndpointFromConfig;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-serde@4.2.20/node_modules/@smithy/middleware-serde/dist-cjs/index.js
var require_dist_cjs$9 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	var endpoints = (require_dist_cjs$38.init_endpoints(), require_chunk.__toCommonJS(require_dist_cjs$38.endpoints_exports));
	const deserializerMiddleware = (options, deserializer) => (next, context) => async (args) => {
		const { response } = await next(args);
		try {
			return {
				response,
				output: await deserializer(response, options)
			};
		} catch (error) {
			Object.defineProperty(error, "$response", {
				value: response,
				enumerable: false,
				writable: false,
				configurable: false
			});
			if (!("$metadata" in error)) {
				const hint = `Deserialization error: to see the raw response, inspect the hidden field {error}.$response on this object.`;
				try {
					error.message += "\n  " + hint;
				} catch (e) {
					if (!context.logger || context.logger?.constructor?.name === "NoOpLogger") console.warn(hint);
					else context.logger?.warn?.(hint);
				}
				if (typeof error.$responseBodyText !== "undefined") {
					if (error.$response) error.$response.body = error.$responseBodyText;
				}
				try {
					if (protocolHttp.HttpResponse.isInstance(response)) {
						const { headers = {} } = response;
						const headerEntries = Object.entries(headers);
						error.$metadata = {
							httpStatusCode: response.statusCode,
							requestId: findHeader(/^x-[\w-]+-request-?id$/, headerEntries),
							extendedRequestId: findHeader(/^x-[\w-]+-id-2$/, headerEntries),
							cfId: findHeader(/^x-[\w-]+-cf-id$/, headerEntries)
						};
					}
				} catch (e) {}
			}
			throw error;
		}
	};
	const findHeader = (pattern, headers) => {
		return (headers.find(([k]) => {
			return k.match(pattern);
		}) || [void 0, void 0])[1];
	};
	const serializerMiddleware = (options, serializer) => (next, context) => async (args) => {
		const endpointConfig = options;
		const endpoint = context.endpointV2 ? async () => endpoints.toEndpointV1(context.endpointV2) : endpointConfig.endpoint;
		if (!endpoint) throw new Error("No valid endpoint provider available.");
		const request = await serializer(args.input, {
			...options,
			endpoint
		});
		return next({
			...args,
			request
		});
	};
	const deserializerMiddlewareOption = {
		name: "deserializerMiddleware",
		step: "deserialize",
		tags: ["DESERIALIZER"],
		override: true
	};
	const serializerMiddlewareOption = {
		name: "serializerMiddleware",
		step: "serialize",
		tags: ["SERIALIZER"],
		override: true
	};
	function getSerdePlugin(config, serializer, deserializer) {
		return { applyToStack: (commandStack) => {
			commandStack.add(deserializerMiddleware(config, deserializer), deserializerMiddlewareOption);
			commandStack.add(serializerMiddleware(config, serializer), serializerMiddlewareOption);
		} };
	}
	exports.deserializerMiddleware = deserializerMiddleware;
	exports.deserializerMiddlewareOption = deserializerMiddlewareOption;
	exports.getSerdePlugin = getSerdePlugin;
	exports.serializerMiddleware = serializerMiddleware;
	exports.serializerMiddlewareOption = serializerMiddlewareOption;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-endpoint@4.4.32/node_modules/@smithy/middleware-endpoint/dist-cjs/index.js
var require_dist_cjs$8 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var core = (init_dist_es(), require_chunk.__toCommonJS(dist_es_exports));
	var utilMiddleware = require_dist_cjs$38.require_dist_cjs$7();
	var getEndpointFromConfig = require_getEndpointFromConfig();
	var urlParser = require_dist_cjs$40.require_dist_cjs();
	var middlewareSerde = require_dist_cjs$9();
	const resolveParamsForS3 = async (endpointParams) => {
		const bucket = endpointParams?.Bucket || "";
		if (typeof endpointParams.Bucket === "string") endpointParams.Bucket = bucket.replace(/#/g, encodeURIComponent("#")).replace(/\?/g, encodeURIComponent("?"));
		if (isArnBucketName(bucket)) {
			if (endpointParams.ForcePathStyle === true) throw new Error("Path-style addressing cannot be used with ARN buckets");
		} else if (!isDnsCompatibleBucketName(bucket) || bucket.indexOf(".") !== -1 && !String(endpointParams.Endpoint).startsWith("http:") || bucket.toLowerCase() !== bucket || bucket.length < 3) endpointParams.ForcePathStyle = true;
		if (endpointParams.DisableMultiRegionAccessPoints) {
			endpointParams.disableMultiRegionAccessPoints = true;
			endpointParams.DisableMRAP = true;
		}
		return endpointParams;
	};
	const DOMAIN_PATTERN = /^[a-z0-9][a-z0-9\.\-]{1,61}[a-z0-9]$/;
	const IP_ADDRESS_PATTERN = /(\d+\.){3}\d+/;
	const DOTS_PATTERN = /\.\./;
	const isDnsCompatibleBucketName = (bucketName) => DOMAIN_PATTERN.test(bucketName) && !IP_ADDRESS_PATTERN.test(bucketName) && !DOTS_PATTERN.test(bucketName);
	const isArnBucketName = (bucketName) => {
		const [arn, partition, service, , , bucket] = bucketName.split(":");
		const isArn = arn === "arn" && bucketName.split(":").length >= 6;
		const isValidArn = Boolean(isArn && partition && service && bucket);
		if (isArn && !isValidArn) throw new Error(`Invalid ARN: ${bucketName} was an invalid ARN.`);
		return isValidArn;
	};
	const createConfigValueProvider = (configKey, canonicalEndpointParamKey, config, isClientContextParam = false) => {
		const configProvider = async () => {
			let configValue;
			if (isClientContextParam) configValue = config.clientContextParams?.[configKey] ?? config[configKey] ?? config[canonicalEndpointParamKey];
			else configValue = config[configKey] ?? config[canonicalEndpointParamKey];
			if (typeof configValue === "function") return configValue();
			return configValue;
		};
		if (configKey === "credentialScope" || canonicalEndpointParamKey === "CredentialScope") return async () => {
			const credentials = typeof config.credentials === "function" ? await config.credentials() : config.credentials;
			return credentials?.credentialScope ?? credentials?.CredentialScope;
		};
		if (configKey === "accountId" || canonicalEndpointParamKey === "AccountId") return async () => {
			const credentials = typeof config.credentials === "function" ? await config.credentials() : config.credentials;
			return credentials?.accountId ?? credentials?.AccountId;
		};
		if (configKey === "endpoint" || canonicalEndpointParamKey === "endpoint") return async () => {
			if (config.isCustomEndpoint === false) return;
			const endpoint = await configProvider();
			if (endpoint && typeof endpoint === "object") {
				if ("url" in endpoint) return endpoint.url.href;
				if ("hostname" in endpoint) {
					const { protocol, hostname, port, path } = endpoint;
					return `${protocol}//${hostname}${port ? ":" + port : ""}${path}`;
				}
			}
			return endpoint;
		};
		return configProvider;
	};
	const toEndpointV1 = (endpoint) => {
		if (typeof endpoint === "object") {
			if ("url" in endpoint) {
				const v1Endpoint = urlParser.parseUrl(endpoint.url);
				if (endpoint.headers) {
					v1Endpoint.headers = {};
					for (const [name, values] of Object.entries(endpoint.headers)) v1Endpoint.headers[name.toLowerCase()] = values.join(", ");
				}
				return v1Endpoint;
			}
			return endpoint;
		}
		return urlParser.parseUrl(endpoint);
	};
	const getEndpointFromInstructions = async (commandInput, instructionsSupplier, clientConfig, context) => {
		if (!clientConfig.isCustomEndpoint) {
			let endpointFromConfig;
			if (clientConfig.serviceConfiguredEndpoint) endpointFromConfig = await clientConfig.serviceConfiguredEndpoint();
			else endpointFromConfig = await getEndpointFromConfig.getEndpointFromConfig(clientConfig.serviceId);
			if (endpointFromConfig) {
				clientConfig.endpoint = () => Promise.resolve(toEndpointV1(endpointFromConfig));
				clientConfig.isCustomEndpoint = true;
			}
		}
		const endpointParams = await resolveParams(commandInput, instructionsSupplier, clientConfig);
		if (typeof clientConfig.endpointProvider !== "function") throw new Error("config.endpointProvider is not set.");
		const endpoint = clientConfig.endpointProvider(endpointParams, context);
		if (clientConfig.isCustomEndpoint && clientConfig.endpoint) {
			const customEndpoint = await clientConfig.endpoint();
			if (customEndpoint?.headers) {
				endpoint.headers ??= {};
				for (const [name, value] of Object.entries(customEndpoint.headers)) endpoint.headers[name] = Array.isArray(value) ? value : [value];
			}
		}
		return endpoint;
	};
	const resolveParams = async (commandInput, instructionsSupplier, clientConfig) => {
		const endpointParams = {};
		const instructions = instructionsSupplier?.getEndpointParameterInstructions?.() || {};
		for (const [name, instruction] of Object.entries(instructions)) switch (instruction.type) {
			case "staticContextParams":
				endpointParams[name] = instruction.value;
				break;
			case "contextParams":
				endpointParams[name] = commandInput[instruction.name];
				break;
			case "clientContextParams":
			case "builtInParams":
				endpointParams[name] = await createConfigValueProvider(instruction.name, name, clientConfig, instruction.type !== "builtInParams")();
				break;
			case "operationContextParams":
				endpointParams[name] = instruction.get(commandInput);
				break;
			default: throw new Error("Unrecognized endpoint parameter instruction: " + JSON.stringify(instruction));
		}
		if (Object.keys(instructions).length === 0) Object.assign(endpointParams, clientConfig);
		if (String(clientConfig.serviceId).toLowerCase() === "s3") await resolveParamsForS3(endpointParams);
		return endpointParams;
	};
	const endpointMiddleware = ({ config, instructions }) => {
		return (next, context) => async (args) => {
			if (config.isCustomEndpoint) core.setFeature(context, "ENDPOINT_OVERRIDE", "N");
			const endpoint = await getEndpointFromInstructions(args.input, { getEndpointParameterInstructions() {
				return instructions;
			} }, { ...config }, context);
			context.endpointV2 = endpoint;
			context.authSchemes = endpoint.properties?.authSchemes;
			const authScheme = context.authSchemes?.[0];
			if (authScheme) {
				context["signing_region"] = authScheme.signingRegion;
				context["signing_service"] = authScheme.signingName;
				const httpAuthOption = utilMiddleware.getSmithyContext(context)?.selectedHttpAuthScheme?.httpAuthOption;
				if (httpAuthOption) httpAuthOption.signingProperties = Object.assign(httpAuthOption.signingProperties || {}, {
					signing_region: authScheme.signingRegion,
					signingRegion: authScheme.signingRegion,
					signing_service: authScheme.signingName,
					signingName: authScheme.signingName,
					signingRegionSet: authScheme.signingRegionSet
				}, authScheme.properties);
			}
			return next({ ...args });
		};
	};
	const endpointMiddlewareOptions = {
		step: "serialize",
		tags: [
			"ENDPOINT_PARAMETERS",
			"ENDPOINT_V2",
			"ENDPOINT"
		],
		name: "endpointV2Middleware",
		override: true,
		relation: "before",
		toMiddleware: middlewareSerde.serializerMiddlewareOption.name
	};
	const getEndpointPlugin = (config, instructions) => ({ applyToStack: (clientStack) => {
		clientStack.addRelativeTo(endpointMiddleware({
			config,
			instructions
		}), endpointMiddlewareOptions);
	} });
	const resolveEndpointConfig = (input) => {
		const tls = input.tls ?? true;
		const { endpoint, useDualstackEndpoint, useFipsEndpoint } = input;
		const resolvedConfig = Object.assign(input, {
			endpoint: endpoint != null ? async () => toEndpointV1(await utilMiddleware.normalizeProvider(endpoint)()) : void 0,
			tls,
			isCustomEndpoint: !!endpoint,
			useDualstackEndpoint: utilMiddleware.normalizeProvider(useDualstackEndpoint ?? false),
			useFipsEndpoint: utilMiddleware.normalizeProvider(useFipsEndpoint ?? false)
		});
		let configuredEndpointPromise = void 0;
		resolvedConfig.serviceConfiguredEndpoint = async () => {
			if (input.serviceId && !configuredEndpointPromise) configuredEndpointPromise = getEndpointFromConfig.getEndpointFromConfig(input.serviceId);
			return configuredEndpointPromise;
		};
		return resolvedConfig;
	};
	const resolveEndpointRequiredConfig = (input) => {
		const { endpoint } = input;
		if (endpoint === void 0) input.endpoint = async () => {
			throw new Error("@smithy/middleware-endpoint: (default endpointRuleSet) endpoint is not set - you must configure an endpoint.");
		};
		return input;
	};
	exports.endpointMiddleware = endpointMiddleware;
	exports.endpointMiddlewareOptions = endpointMiddlewareOptions;
	exports.getEndpointFromInstructions = getEndpointFromInstructions;
	exports.getEndpointPlugin = getEndpointPlugin;
	exports.resolveEndpointConfig = resolveEndpointConfig;
	exports.resolveEndpointRequiredConfig = resolveEndpointRequiredConfig;
	exports.resolveParams = resolveParams;
	exports.toEndpointV1 = toEndpointV1;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-retry@4.5.7/node_modules/@smithy/middleware-retry/dist-cjs/isStreamingPayload/isStreamingPayload.js
var require_isStreamingPayload = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isStreamingPayload = void 0;
	const stream_1 = require("stream");
	const isStreamingPayload = (request) => request?.body instanceof stream_1.Readable || typeof ReadableStream !== "undefined" && request?.body instanceof ReadableStream;
	exports.isStreamingPayload = isStreamingPayload;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+middleware-retry@4.5.7/node_modules/@smithy/middleware-retry/dist-cjs/index.js
var require_dist_cjs$7 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var utilRetry = require_client.require_dist_cjs();
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	var serviceErrorClassification = require_client.require_dist_cjs$1();
	var uuid = require_dist_cjs$38.require_dist_cjs$1();
	var utilMiddleware = require_dist_cjs$38.require_dist_cjs$7();
	var smithyClient = require_dist_cjs$38.require_dist_cjs();
	var isStreamingPayload = require_isStreamingPayload();
	var serde = (require_dist_cjs$38.init_serde(), require_chunk.__toCommonJS(require_dist_cjs$38.serde_exports));
	const asSdkError = (error) => {
		if (error instanceof Error) return error;
		if (error instanceof Object) return Object.assign(/* @__PURE__ */ new Error(), error);
		if (typeof error === "string") return new Error(error);
		return /* @__PURE__ */ new Error(`AWS SDK error wrapper for ${error}`);
	};
	const getDefaultRetryQuota = (initialRetryTokens, options) => {
		const MAX_CAPACITY = initialRetryTokens;
		const noRetryIncrement = utilRetry.NO_RETRY_INCREMENT;
		const retryCost = utilRetry.RETRY_COST;
		const timeoutRetryCost = utilRetry.TIMEOUT_RETRY_COST;
		let availableCapacity = initialRetryTokens;
		const getCapacityAmount = (error) => error.name === "TimeoutError" ? timeoutRetryCost : retryCost;
		const hasRetryTokens = (error) => getCapacityAmount(error) <= availableCapacity;
		const retrieveRetryTokens = (error) => {
			if (!hasRetryTokens(error)) throw new Error("No retry token available");
			const capacityAmount = getCapacityAmount(error);
			availableCapacity -= capacityAmount;
			return capacityAmount;
		};
		const releaseRetryTokens = (capacityReleaseAmount) => {
			availableCapacity += capacityReleaseAmount ?? noRetryIncrement;
			availableCapacity = Math.min(availableCapacity, MAX_CAPACITY);
		};
		return Object.freeze({
			hasRetryTokens,
			retrieveRetryTokens,
			releaseRetryTokens
		});
	};
	const defaultDelayDecider = (delayBase, attempts) => Math.floor(Math.min(utilRetry.MAXIMUM_RETRY_DELAY, Math.random() * 2 ** attempts * delayBase));
	const defaultRetryDecider = (error) => {
		if (!error) return false;
		return serviceErrorClassification.isRetryableByTrait(error) || serviceErrorClassification.isClockSkewError(error) || serviceErrorClassification.isThrottlingError(error) || serviceErrorClassification.isTransientError(error);
	};
	var StandardRetryStrategy = class {
		maxAttemptsProvider;
		retryDecider;
		delayDecider;
		retryQuota;
		mode = utilRetry.RETRY_MODES.STANDARD;
		constructor(maxAttemptsProvider, options) {
			this.maxAttemptsProvider = maxAttemptsProvider;
			this.retryDecider = options?.retryDecider ?? defaultRetryDecider;
			this.delayDecider = options?.delayDecider ?? defaultDelayDecider;
			this.retryQuota = options?.retryQuota ?? getDefaultRetryQuota(utilRetry.INITIAL_RETRY_TOKENS);
		}
		shouldRetry(error, attempts, maxAttempts) {
			return attempts < maxAttempts && this.retryDecider(error) && this.retryQuota.hasRetryTokens(error);
		}
		async getMaxAttempts() {
			let maxAttempts;
			try {
				maxAttempts = await this.maxAttemptsProvider();
			} catch (error) {
				maxAttempts = utilRetry.DEFAULT_MAX_ATTEMPTS;
			}
			return maxAttempts;
		}
		async retry(next, args, options) {
			let retryTokenAmount;
			let attempts = 0;
			let totalDelay = 0;
			const maxAttempts = await this.getMaxAttempts();
			const { request } = args;
			if (protocolHttp.HttpRequest.isInstance(request)) request.headers[utilRetry.INVOCATION_ID_HEADER] = uuid.v4();
			while (true) try {
				if (protocolHttp.HttpRequest.isInstance(request)) request.headers[utilRetry.REQUEST_HEADER] = `attempt=${attempts + 1}; max=${maxAttempts}`;
				if (options?.beforeRequest) await options.beforeRequest();
				const { response, output } = await next(args);
				if (options?.afterRequest) options.afterRequest(response);
				this.retryQuota.releaseRetryTokens(retryTokenAmount);
				output.$metadata.attempts = attempts + 1;
				output.$metadata.totalRetryDelay = totalDelay;
				return {
					response,
					output
				};
			} catch (e) {
				const err = asSdkError(e);
				attempts++;
				if (this.shouldRetry(err, attempts, maxAttempts)) {
					retryTokenAmount = this.retryQuota.retrieveRetryTokens(err);
					const delayFromDecider = this.delayDecider(serviceErrorClassification.isThrottlingError(err) ? utilRetry.THROTTLING_RETRY_DELAY_BASE : utilRetry.DEFAULT_RETRY_DELAY_BASE, attempts);
					const delayFromResponse = getDelayFromRetryAfterHeader(err.$response);
					const delay = Math.max(delayFromResponse || 0, delayFromDecider);
					totalDelay += delay;
					await new Promise((resolve) => setTimeout(resolve, delay));
					continue;
				}
				if (!err.$metadata) err.$metadata = {};
				err.$metadata.attempts = attempts;
				err.$metadata.totalRetryDelay = totalDelay;
				throw err;
			}
		}
	};
	const getDelayFromRetryAfterHeader = (response) => {
		if (!protocolHttp.HttpResponse.isInstance(response)) return;
		const retryAfterHeaderName = Object.keys(response.headers).find((key) => key.toLowerCase() === "retry-after");
		if (!retryAfterHeaderName) return;
		const retryAfter = response.headers[retryAfterHeaderName];
		const retryAfterSeconds = Number(retryAfter);
		if (!Number.isNaN(retryAfterSeconds)) return retryAfterSeconds * 1e3;
		return new Date(retryAfter).getTime() - Date.now();
	};
	var AdaptiveRetryStrategy = class extends StandardRetryStrategy {
		rateLimiter;
		constructor(maxAttemptsProvider, options) {
			const { rateLimiter, ...superOptions } = options ?? {};
			super(maxAttemptsProvider, superOptions);
			this.rateLimiter = rateLimiter ?? new utilRetry.DefaultRateLimiter();
			this.mode = utilRetry.RETRY_MODES.ADAPTIVE;
		}
		async retry(next, args) {
			return super.retry(next, args, {
				beforeRequest: async () => {
					return this.rateLimiter.getSendToken();
				},
				afterRequest: (response) => {
					this.rateLimiter.updateClientSendingRate(response);
				}
			});
		}
	};
	const ENV_MAX_ATTEMPTS = "AWS_MAX_ATTEMPTS";
	const CONFIG_MAX_ATTEMPTS = "max_attempts";
	const NODE_MAX_ATTEMPT_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => {
			const value = env[ENV_MAX_ATTEMPTS];
			if (!value) return void 0;
			const maxAttempt = parseInt(value);
			if (Number.isNaN(maxAttempt)) throw new Error(`Environment variable ${ENV_MAX_ATTEMPTS} mast be a number, got "${value}"`);
			return maxAttempt;
		},
		configFileSelector: (profile) => {
			const value = profile[CONFIG_MAX_ATTEMPTS];
			if (!value) return void 0;
			const maxAttempt = parseInt(value);
			if (Number.isNaN(maxAttempt)) throw new Error(`Shared config file entry ${CONFIG_MAX_ATTEMPTS} mast be a number, got "${value}"`);
			return maxAttempt;
		},
		default: utilRetry.DEFAULT_MAX_ATTEMPTS
	};
	const resolveRetryConfig = (input) => {
		const { retryStrategy, retryMode } = input;
		const maxAttempts = utilMiddleware.normalizeProvider(input.maxAttempts ?? utilRetry.DEFAULT_MAX_ATTEMPTS);
		let controller = retryStrategy ? Promise.resolve(retryStrategy) : void 0;
		const getDefault = async () => await utilMiddleware.normalizeProvider(retryMode)() === utilRetry.RETRY_MODES.ADAPTIVE ? new utilRetry.AdaptiveRetryStrategy(maxAttempts) : new utilRetry.StandardRetryStrategy(maxAttempts);
		return Object.assign(input, {
			maxAttempts,
			retryStrategy: () => controller ??= getDefault()
		});
	};
	const ENV_RETRY_MODE = "AWS_RETRY_MODE";
	const CONFIG_RETRY_MODE = "retry_mode";
	const NODE_RETRY_MODE_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => env[ENV_RETRY_MODE],
		configFileSelector: (profile) => profile[CONFIG_RETRY_MODE],
		default: utilRetry.DEFAULT_RETRY_MODE
	};
	const omitRetryHeadersMiddleware = () => (next) => async (args) => {
		const { request } = args;
		if (protocolHttp.HttpRequest.isInstance(request)) {
			delete request.headers[utilRetry.INVOCATION_ID_HEADER];
			delete request.headers[utilRetry.REQUEST_HEADER];
		}
		return next(args);
	};
	const omitRetryHeadersMiddlewareOptions = {
		name: "omitRetryHeadersMiddleware",
		tags: [
			"RETRY",
			"HEADERS",
			"OMIT_RETRY_HEADERS"
		],
		relation: "before",
		toMiddleware: "awsAuthMiddleware",
		override: true
	};
	const getOmitRetryHeadersPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.addRelativeTo(omitRetryHeadersMiddleware(), omitRetryHeadersMiddlewareOptions);
	} });
	function parseRetryAfterHeader(response, logger) {
		if (!protocolHttp.HttpResponse.isInstance(response)) return;
		for (const header of Object.keys(response.headers)) {
			const h = header.toLowerCase();
			if (h === "retry-after") {
				const retryAfter = response.headers[header];
				let retryAfterSeconds = NaN;
				if (retryAfter.endsWith("GMT")) try {
					retryAfterSeconds = (serde.parseRfc7231DateTime(retryAfter).getTime() - Date.now()) / 1e3;
				} catch (e) {
					logger?.trace?.("Failed to parse retry-after header");
					logger?.trace?.(e);
				}
				else if (retryAfter.match(/ GMT, ((\d+)|(\d+\.\d+))$/)) retryAfterSeconds = Number(retryAfter.match(/ GMT, ([\d.]+)$/)?.[1]);
				else if (retryAfter.match(/^((\d+)|(\d+\.\d+))$/)) retryAfterSeconds = Number(retryAfter);
				else if (Date.parse(retryAfter) >= Date.now()) retryAfterSeconds = (Date.parse(retryAfter) - Date.now()) / 1e3;
				if (isNaN(retryAfterSeconds)) return;
				return new Date(Date.now() + retryAfterSeconds * 1e3);
			} else if (h === "x-amz-retry-after") {
				const v = response.headers[header];
				const backoffMilliseconds = Number(v);
				if (isNaN(backoffMilliseconds)) {
					logger?.trace?.(`Failed to parse x-amz-retry-after=${v}`);
					return;
				}
				return new Date(Date.now() + backoffMilliseconds);
			}
		}
	}
	function getRetryAfterHint(response, logger) {
		return parseRetryAfterHeader(response, logger);
	}
	const retryMiddleware = (options) => (next, context) => async (args) => {
		let retryStrategy = await options.retryStrategy();
		const maxAttempts = await options.maxAttempts();
		if (isRetryStrategyV2(retryStrategy)) {
			retryStrategy = retryStrategy;
			let retryToken = await retryStrategy.acquireInitialRetryToken((context["partition_id"] ?? "") + (context.__retryLongPoll ? ":longpoll" : ""));
			let lastError = /* @__PURE__ */ new Error();
			let attempts = 0;
			let totalRetryDelay = 0;
			const { request } = args;
			const isRequest = protocolHttp.HttpRequest.isInstance(request);
			if (isRequest) request.headers[utilRetry.INVOCATION_ID_HEADER] = uuid.v4();
			while (true) try {
				if (isRequest) request.headers[utilRetry.REQUEST_HEADER] = `attempt=${attempts + 1}; max=${maxAttempts}`;
				const { response, output } = await next(args);
				retryStrategy.recordSuccess(retryToken);
				output.$metadata.attempts = attempts + 1;
				output.$metadata.totalRetryDelay = totalRetryDelay;
				return {
					response,
					output
				};
			} catch (e) {
				const retryErrorInfo = getRetryErrorInfo(e, options.logger);
				lastError = asSdkError(e);
				if (isRequest && isStreamingPayload.isStreamingPayload(request)) {
					(context.logger instanceof smithyClient.NoOpLogger ? console : context.logger)?.warn("An error was encountered in a non-retryable streaming request.");
					throw lastError;
				}
				try {
					retryToken = await retryStrategy.refreshRetryTokenForRetry(retryToken, retryErrorInfo);
				} catch (refreshError) {
					if (typeof refreshError.$backoff === "number") await cooldown(refreshError.$backoff);
					if (!lastError.$metadata) lastError.$metadata = {};
					lastError.$metadata.attempts = attempts + 1;
					lastError.$metadata.totalRetryDelay = totalRetryDelay;
					throw lastError;
				}
				attempts = retryToken.getRetryCount();
				const delay = retryToken.getRetryDelay();
				totalRetryDelay += delay;
				await cooldown(delay);
			}
		} else {
			retryStrategy = retryStrategy;
			if (retryStrategy?.mode) context.userAgent = [...context.userAgent || [], ["cfg/retry-mode", retryStrategy.mode]];
			return retryStrategy.retry(next, args);
		}
	};
	const cooldown = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
	const isRetryStrategyV2 = (retryStrategy) => typeof retryStrategy.acquireInitialRetryToken !== "undefined" && typeof retryStrategy.refreshRetryTokenForRetry !== "undefined" && typeof retryStrategy.recordSuccess !== "undefined";
	const getRetryErrorInfo = (error, logger) => {
		const errorInfo = {
			error,
			errorType: getRetryErrorType(error)
		};
		const retryAfterHint = parseRetryAfterHeader(error.$response, logger);
		if (retryAfterHint) errorInfo.retryAfterHint = retryAfterHint;
		return errorInfo;
	};
	const getRetryErrorType = (error) => {
		if (serviceErrorClassification.isThrottlingError(error)) return "THROTTLING";
		if (serviceErrorClassification.isTransientError(error)) return "TRANSIENT";
		if (serviceErrorClassification.isServerError(error)) return "SERVER_ERROR";
		return "CLIENT_ERROR";
	};
	const retryMiddlewareOptions = {
		name: "retryMiddleware",
		tags: ["RETRY"],
		step: "finalizeRequest",
		priority: "high",
		override: true
	};
	const getRetryPlugin = (options) => ({ applyToStack: (clientStack) => {
		clientStack.add(retryMiddleware(options), retryMiddlewareOptions);
	} });
	exports.AdaptiveRetryStrategy = AdaptiveRetryStrategy;
	exports.CONFIG_MAX_ATTEMPTS = CONFIG_MAX_ATTEMPTS;
	exports.CONFIG_RETRY_MODE = CONFIG_RETRY_MODE;
	exports.ENV_MAX_ATTEMPTS = ENV_MAX_ATTEMPTS;
	exports.ENV_RETRY_MODE = ENV_RETRY_MODE;
	exports.NODE_MAX_ATTEMPT_CONFIG_OPTIONS = NODE_MAX_ATTEMPT_CONFIG_OPTIONS;
	exports.NODE_RETRY_MODE_CONFIG_OPTIONS = NODE_RETRY_MODE_CONFIG_OPTIONS;
	exports.StandardRetryStrategy = StandardRetryStrategy;
	exports.defaultDelayDecider = defaultDelayDecider;
	exports.defaultRetryDecider = defaultRetryDecider;
	exports.getOmitRetryHeadersPlugin = getOmitRetryHeadersPlugin;
	exports.getRetryAfterHint = getRetryAfterHint;
	exports.getRetryPlugin = getRetryPlugin;
	exports.omitRetryHeadersMiddleware = omitRetryHeadersMiddleware;
	exports.omitRetryHeadersMiddlewareOptions = omitRetryHeadersMiddlewareOptions;
	exports.resolveRetryConfig = resolveRetryConfig;
	exports.retryMiddleware = retryMiddleware;
	exports.retryMiddlewareOptions = retryMiddlewareOptions;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/getDateHeader.js
var import_dist_cjs$24, getDateHeader;
var init_getDateHeader = require_chunk.__esmMin((() => {
	import_dist_cjs$24 = require_dist_cjs$37.require_dist_cjs();
	getDateHeader = (response) => import_dist_cjs$24.HttpResponse.isInstance(response) ? response.headers?.date ?? response.headers?.Date : void 0;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/getSkewCorrectedDate.js
var getSkewCorrectedDate;
var init_getSkewCorrectedDate = require_chunk.__esmMin((() => {
	getSkewCorrectedDate = (systemClockOffset) => new Date(Date.now() + systemClockOffset);
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/isClockSkewed.js
var isClockSkewed;
var init_isClockSkewed = require_chunk.__esmMin((() => {
	init_getSkewCorrectedDate();
	isClockSkewed = (clockTime, systemClockOffset) => Math.abs(getSkewCorrectedDate(systemClockOffset).getTime() - clockTime) >= 3e5;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/getUpdatedSystemClockOffset.js
var getUpdatedSystemClockOffset;
var init_getUpdatedSystemClockOffset = require_chunk.__esmMin((() => {
	init_isClockSkewed();
	getUpdatedSystemClockOffset = (clockTime, currentSystemClockOffset) => {
		const clockTimeInMs = Date.parse(clockTime);
		if (isClockSkewed(clockTimeInMs, currentSystemClockOffset)) return clockTimeInMs - Date.now();
		return currentSystemClockOffset;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/index.js
var init_utils = require_chunk.__esmMin((() => {
	init_getDateHeader();
	init_getSkewCorrectedDate();
	init_getUpdatedSystemClockOffset();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/AwsSdkSigV4Signer.js
var import_dist_cjs$23, throwSigningPropertyError, validateSigningProperties, AwsSdkSigV4Signer, AWSSDKSigV4Signer;
var init_AwsSdkSigV4Signer = require_chunk.__esmMin((() => {
	import_dist_cjs$23 = require_dist_cjs$37.require_dist_cjs();
	init_utils();
	throwSigningPropertyError = (name, property) => {
		if (!property) throw new Error(`Property \`${name}\` is not resolved for AWS SDK SigV4Auth`);
		return property;
	};
	validateSigningProperties = async (signingProperties) => {
		const context = throwSigningPropertyError("context", signingProperties.context);
		const config = throwSigningPropertyError("config", signingProperties.config);
		const authScheme = context.endpointV2?.properties?.authSchemes?.[0];
		return {
			config,
			signer: await throwSigningPropertyError("signer", config.signer)(authScheme),
			signingRegion: signingProperties?.signingRegion,
			signingRegionSet: signingProperties?.signingRegionSet,
			signingName: signingProperties?.signingName
		};
	};
	AwsSdkSigV4Signer = class {
		async sign(httpRequest, identity, signingProperties) {
			if (!import_dist_cjs$23.HttpRequest.isInstance(httpRequest)) throw new Error("The request is not an instance of `HttpRequest` and cannot be signed");
			const validatedProps = await validateSigningProperties(signingProperties);
			const { config, signer } = validatedProps;
			let { signingRegion, signingName } = validatedProps;
			const handlerExecutionContext = signingProperties.context;
			if (handlerExecutionContext?.authSchemes?.length ?? false) {
				const [first, second] = handlerExecutionContext.authSchemes;
				if (first?.name === "sigv4a" && second?.name === "sigv4") {
					signingRegion = second?.signingRegion ?? signingRegion;
					signingName = second?.signingName ?? signingName;
				}
			}
			return await signer.sign(httpRequest, {
				signingDate: getSkewCorrectedDate(config.systemClockOffset),
				signingRegion,
				signingService: signingName
			});
		}
		errorHandler(signingProperties) {
			return (error) => {
				const serverTime = error.ServerTime ?? getDateHeader(error.$response);
				if (serverTime) {
					const config = throwSigningPropertyError("config", signingProperties.config);
					const initialSystemClockOffset = config.systemClockOffset;
					config.systemClockOffset = getUpdatedSystemClockOffset(serverTime, config.systemClockOffset);
					if (config.systemClockOffset !== initialSystemClockOffset && error.$metadata) error.$metadata.clockSkewCorrected = true;
				}
				throw error;
			};
		}
		successHandler(httpResponse, signingProperties) {
			const dateHeader = getDateHeader(httpResponse);
			if (dateHeader) {
				const config = throwSigningPropertyError("config", signingProperties.config);
				config.systemClockOffset = getUpdatedSystemClockOffset(dateHeader, config.systemClockOffset);
			}
		}
	};
	AWSSDKSigV4Signer = AwsSdkSigV4Signer;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/AwsSdkSigV4ASigner.js
var import_dist_cjs$22, AwsSdkSigV4ASigner;
var init_AwsSdkSigV4ASigner = require_chunk.__esmMin((() => {
	import_dist_cjs$22 = require_dist_cjs$37.require_dist_cjs();
	init_utils();
	init_AwsSdkSigV4Signer();
	AwsSdkSigV4ASigner = class extends AwsSdkSigV4Signer {
		async sign(httpRequest, identity, signingProperties) {
			if (!import_dist_cjs$22.HttpRequest.isInstance(httpRequest)) throw new Error("The request is not an instance of `HttpRequest` and cannot be signed");
			const { config, signer, signingRegion, signingRegionSet, signingName } = await validateSigningProperties(signingProperties);
			const multiRegionOverride = (await config.sigv4aSigningRegionSet?.() ?? signingRegionSet ?? [signingRegion]).join(",");
			return await signer.sign(httpRequest, {
				signingDate: getSkewCorrectedDate(config.systemClockOffset),
				signingRegion: multiRegionOverride,
				signingService: signingName
			});
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/getArrayForCommaSeparatedString.js
var getArrayForCommaSeparatedString;
var init_getArrayForCommaSeparatedString = require_chunk.__esmMin((() => {
	getArrayForCommaSeparatedString = (str) => typeof str === "string" && str.length > 0 ? str.split(",").map((item) => item.trim()) : [];
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/utils/getBearerTokenEnvKey.js
var getBearerTokenEnvKey;
var init_getBearerTokenEnvKey = require_chunk.__esmMin((() => {
	getBearerTokenEnvKey = (signingName) => `AWS_BEARER_TOKEN_${signingName.replace(/[\s-]/g, "_").toUpperCase()}`;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/NODE_AUTH_SCHEME_PREFERENCE_OPTIONS.js
var NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY, NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS;
var init_NODE_AUTH_SCHEME_PREFERENCE_OPTIONS = require_chunk.__esmMin((() => {
	init_getArrayForCommaSeparatedString();
	init_getBearerTokenEnvKey();
	NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY = "AWS_AUTH_SCHEME_PREFERENCE";
	NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY = "auth_scheme_preference";
	NODE_AUTH_SCHEME_PREFERENCE_OPTIONS = {
		environmentVariableSelector: (env, options) => {
			if (options?.signingName) {
				if (getBearerTokenEnvKey(options.signingName) in env) return ["httpBearerAuth"];
			}
			if (!(NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY in env)) return void 0;
			return getArrayForCommaSeparatedString(env[NODE_AUTH_SCHEME_PREFERENCE_ENV_KEY]);
		},
		configFileSelector: (profile) => {
			if (!(NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY in profile)) return void 0;
			return getArrayForCommaSeparatedString(profile[NODE_AUTH_SCHEME_PREFERENCE_CONFIG_KEY]);
		},
		default: []
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/resolveAwsSdkSigV4AConfig.js
var import_dist_cjs$21, resolveAwsSdkSigV4AConfig, NODE_SIGV4A_CONFIG_OPTIONS;
var init_resolveAwsSdkSigV4AConfig = require_chunk.__esmMin((() => {
	init_dist_es();
	import_dist_cjs$21 = require_dist_cjs$41.require_dist_cjs();
	resolveAwsSdkSigV4AConfig = (config) => {
		config.sigv4aSigningRegionSet = normalizeProvider(config.sigv4aSigningRegionSet);
		return config;
	};
	NODE_SIGV4A_CONFIG_OPTIONS = {
		environmentVariableSelector(env) {
			if (env.AWS_SIGV4A_SIGNING_REGION_SET) return env.AWS_SIGV4A_SIGNING_REGION_SET.split(",").map((_) => _.trim());
			throw new import_dist_cjs$21.ProviderError("AWS_SIGV4A_SIGNING_REGION_SET not set in env.", { tryNextLink: true });
		},
		configFileSelector(profile) {
			if (profile.sigv4a_signing_region_set) return (profile.sigv4a_signing_region_set ?? "").split(",").map((_) => _.trim());
			throw new import_dist_cjs$21.ProviderError("sigv4a_signing_region_set not set in profile.", { tryNextLink: true });
		},
		default: void 0
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+signature-v4@5.3.14/node_modules/@smithy/signature-v4/dist-cjs/index.js
var require_dist_cjs$6 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var utilHexEncoding = require_dist_cjs$38.require_dist_cjs$3();
	var utilUtf8 = require_dist_cjs$39.require_dist_cjs();
	var isArrayBuffer = require_dist_cjs$39.require_dist_cjs$2();
	var protocolHttp = require_dist_cjs$37.require_dist_cjs();
	var utilMiddleware = require_dist_cjs$38.require_dist_cjs$7();
	var utilUriEscape = require_dist_cjs$38.require_dist_cjs$5();
	const ALGORITHM_QUERY_PARAM = "X-Amz-Algorithm";
	const CREDENTIAL_QUERY_PARAM = "X-Amz-Credential";
	const AMZ_DATE_QUERY_PARAM = "X-Amz-Date";
	const SIGNED_HEADERS_QUERY_PARAM = "X-Amz-SignedHeaders";
	const EXPIRES_QUERY_PARAM = "X-Amz-Expires";
	const SIGNATURE_QUERY_PARAM = "X-Amz-Signature";
	const TOKEN_QUERY_PARAM = "X-Amz-Security-Token";
	const REGION_SET_PARAM = "X-Amz-Region-Set";
	const AUTH_HEADER = "authorization";
	const AMZ_DATE_HEADER = AMZ_DATE_QUERY_PARAM.toLowerCase();
	const DATE_HEADER = "date";
	const GENERATED_HEADERS = [
		AUTH_HEADER,
		AMZ_DATE_HEADER,
		DATE_HEADER
	];
	const SIGNATURE_HEADER = SIGNATURE_QUERY_PARAM.toLowerCase();
	const SHA256_HEADER = "x-amz-content-sha256";
	const TOKEN_HEADER = TOKEN_QUERY_PARAM.toLowerCase();
	const HOST_HEADER = "host";
	const ALWAYS_UNSIGNABLE_HEADERS = {
		authorization: true,
		"cache-control": true,
		connection: true,
		expect: true,
		from: true,
		"keep-alive": true,
		"max-forwards": true,
		pragma: true,
		referer: true,
		te: true,
		trailer: true,
		"transfer-encoding": true,
		upgrade: true,
		"user-agent": true,
		"x-amzn-trace-id": true
	};
	const PROXY_HEADER_PATTERN = /^proxy-/;
	const SEC_HEADER_PATTERN = /^sec-/;
	const UNSIGNABLE_PATTERNS = [/^proxy-/i, /^sec-/i];
	const ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256";
	const ALGORITHM_IDENTIFIER_V4A = "AWS4-ECDSA-P256-SHA256";
	const EVENT_ALGORITHM_IDENTIFIER = "AWS4-HMAC-SHA256-PAYLOAD";
	const UNSIGNED_PAYLOAD = "UNSIGNED-PAYLOAD";
	const MAX_CACHE_SIZE = 50;
	const KEY_TYPE_IDENTIFIER = "aws4_request";
	const MAX_PRESIGNED_TTL = 3600 * 24 * 7;
	const signingKeyCache = {};
	const cacheQueue = [];
	const createScope = (shortDate, region, service) => `${shortDate}/${region}/${service}/${KEY_TYPE_IDENTIFIER}`;
	const getSigningKey = async (sha256Constructor, credentials, shortDate, region, service) => {
		const credsHash = await hmac(sha256Constructor, credentials.secretAccessKey, credentials.accessKeyId);
		const cacheKey = `${shortDate}:${region}:${service}:${utilHexEncoding.toHex(credsHash)}:${credentials.sessionToken}`;
		if (cacheKey in signingKeyCache) return signingKeyCache[cacheKey];
		cacheQueue.push(cacheKey);
		while (cacheQueue.length > MAX_CACHE_SIZE) delete signingKeyCache[cacheQueue.shift()];
		let key = `AWS4${credentials.secretAccessKey}`;
		for (const signable of [
			shortDate,
			region,
			service,
			KEY_TYPE_IDENTIFIER
		]) key = await hmac(sha256Constructor, key, signable);
		return signingKeyCache[cacheKey] = key;
	};
	const clearCredentialCache = () => {
		cacheQueue.length = 0;
		Object.keys(signingKeyCache).forEach((cacheKey) => {
			delete signingKeyCache[cacheKey];
		});
	};
	const hmac = (ctor, secret, data) => {
		const hash = new ctor(secret);
		hash.update(utilUtf8.toUint8Array(data));
		return hash.digest();
	};
	const getCanonicalHeaders = ({ headers }, unsignableHeaders, signableHeaders) => {
		const canonical = {};
		for (const headerName of Object.keys(headers).sort()) {
			if (headers[headerName] == void 0) continue;
			const canonicalHeaderName = headerName.toLowerCase();
			if (canonicalHeaderName in ALWAYS_UNSIGNABLE_HEADERS || unsignableHeaders?.has(canonicalHeaderName) || PROXY_HEADER_PATTERN.test(canonicalHeaderName) || SEC_HEADER_PATTERN.test(canonicalHeaderName)) {
				if (!signableHeaders || signableHeaders && !signableHeaders.has(canonicalHeaderName)) continue;
			}
			canonical[canonicalHeaderName] = headers[headerName].trim().replace(/\s+/g, " ");
		}
		return canonical;
	};
	const getPayloadHash = async ({ headers, body }, hashConstructor) => {
		for (const headerName of Object.keys(headers)) if (headerName.toLowerCase() === SHA256_HEADER) return headers[headerName];
		if (body == void 0) return "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
		else if (typeof body === "string" || ArrayBuffer.isView(body) || isArrayBuffer.isArrayBuffer(body)) {
			const hashCtor = new hashConstructor();
			hashCtor.update(utilUtf8.toUint8Array(body));
			return utilHexEncoding.toHex(await hashCtor.digest());
		}
		return UNSIGNED_PAYLOAD;
	};
	var HeaderFormatter = class {
		format(headers) {
			const chunks = [];
			for (const headerName of Object.keys(headers)) {
				const bytes = utilUtf8.fromUtf8(headerName);
				chunks.push(Uint8Array.from([bytes.byteLength]), bytes, this.formatHeaderValue(headers[headerName]));
			}
			const out = new Uint8Array(chunks.reduce((carry, bytes) => carry + bytes.byteLength, 0));
			let position = 0;
			for (const chunk of chunks) {
				out.set(chunk, position);
				position += chunk.byteLength;
			}
			return out;
		}
		formatHeaderValue(header) {
			switch (header.type) {
				case "boolean": return Uint8Array.from([header.value ? 0 : 1]);
				case "byte": return Uint8Array.from([2, header.value]);
				case "short":
					const shortView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(3));
					shortView.setUint8(0, 3);
					shortView.setInt16(1, header.value, false);
					return new Uint8Array(shortView.buffer);
				case "integer":
					const intView = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(5));
					intView.setUint8(0, 4);
					intView.setInt32(1, header.value, false);
					return new Uint8Array(intView.buffer);
				case "long":
					const longBytes = new Uint8Array(9);
					longBytes[0] = 5;
					longBytes.set(header.value.bytes, 1);
					return longBytes;
				case "binary":
					const binView = new DataView(new ArrayBuffer(3 + header.value.byteLength));
					binView.setUint8(0, 6);
					binView.setUint16(1, header.value.byteLength, false);
					const binBytes = new Uint8Array(binView.buffer);
					binBytes.set(header.value, 3);
					return binBytes;
				case "string":
					const utf8Bytes = utilUtf8.fromUtf8(header.value);
					const strView = new DataView(new ArrayBuffer(3 + utf8Bytes.byteLength));
					strView.setUint8(0, 7);
					strView.setUint16(1, utf8Bytes.byteLength, false);
					const strBytes = new Uint8Array(strView.buffer);
					strBytes.set(utf8Bytes, 3);
					return strBytes;
				case "timestamp":
					const tsBytes = new Uint8Array(9);
					tsBytes[0] = 8;
					tsBytes.set(Int64.fromNumber(header.value.valueOf()).bytes, 1);
					return tsBytes;
				case "uuid":
					if (!UUID_PATTERN.test(header.value)) throw new Error(`Invalid UUID received: ${header.value}`);
					const uuidBytes = new Uint8Array(17);
					uuidBytes[0] = 9;
					uuidBytes.set(utilHexEncoding.fromHex(header.value.replace(/\-/g, "")), 1);
					return uuidBytes;
			}
		}
	};
	var HEADER_VALUE_TYPE;
	(function(HEADER_VALUE_TYPE) {
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolTrue"] = 0] = "boolTrue";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["boolFalse"] = 1] = "boolFalse";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byte"] = 2] = "byte";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["short"] = 3] = "short";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["integer"] = 4] = "integer";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["long"] = 5] = "long";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["byteArray"] = 6] = "byteArray";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["string"] = 7] = "string";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["timestamp"] = 8] = "timestamp";
		HEADER_VALUE_TYPE[HEADER_VALUE_TYPE["uuid"] = 9] = "uuid";
	})(HEADER_VALUE_TYPE || (HEADER_VALUE_TYPE = {}));
	const UUID_PATTERN = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
	var Int64 = class Int64 {
		bytes;
		constructor(bytes) {
			this.bytes = bytes;
			if (bytes.byteLength !== 8) throw new Error("Int64 buffers must be exactly 8 bytes");
		}
		static fromNumber(number) {
			if (number > 0x8000000000000000 || number < -0x8000000000000000) throw new Error(`${number} is too large (or, if negative, too small) to represent as an Int64`);
			const bytes = new Uint8Array(8);
			for (let i = 7, remaining = Math.abs(Math.round(number)); i > -1 && remaining > 0; i--, remaining /= 256) bytes[i] = remaining;
			if (number < 0) negate(bytes);
			return new Int64(bytes);
		}
		valueOf() {
			const bytes = this.bytes.slice(0);
			const negative = bytes[0] & 128;
			if (negative) negate(bytes);
			return parseInt(utilHexEncoding.toHex(bytes), 16) * (negative ? -1 : 1);
		}
		toString() {
			return String(this.valueOf());
		}
	};
	function negate(bytes) {
		for (let i = 0; i < 8; i++) bytes[i] ^= 255;
		for (let i = 7; i > -1; i--) {
			bytes[i]++;
			if (bytes[i] !== 0) break;
		}
	}
	const hasHeader = (soughtHeader, headers) => {
		soughtHeader = soughtHeader.toLowerCase();
		for (const headerName of Object.keys(headers)) if (soughtHeader === headerName.toLowerCase()) return true;
		return false;
	};
	const moveHeadersToQuery = (request, options = {}) => {
		const { headers, query = {} } = protocolHttp.HttpRequest.clone(request);
		for (const name of Object.keys(headers)) {
			const lname = name.toLowerCase();
			if (lname.slice(0, 6) === "x-amz-" && !options.unhoistableHeaders?.has(lname) || options.hoistableHeaders?.has(lname)) {
				query[name] = headers[name];
				delete headers[name];
			}
		}
		return {
			...request,
			headers,
			query
		};
	};
	const prepareRequest = (request) => {
		request = protocolHttp.HttpRequest.clone(request);
		for (const headerName of Object.keys(request.headers)) if (GENERATED_HEADERS.indexOf(headerName.toLowerCase()) > -1) delete request.headers[headerName];
		return request;
	};
	const getCanonicalQuery = ({ query = {} }) => {
		const keys = [];
		const serialized = {};
		for (const key of Object.keys(query)) {
			if (key.toLowerCase() === SIGNATURE_HEADER) continue;
			const encodedKey = utilUriEscape.escapeUri(key);
			keys.push(encodedKey);
			const value = query[key];
			if (typeof value === "string") serialized[encodedKey] = `${encodedKey}=${utilUriEscape.escapeUri(value)}`;
			else if (Array.isArray(value)) serialized[encodedKey] = value.slice(0).reduce((encoded, value) => encoded.concat([`${encodedKey}=${utilUriEscape.escapeUri(value)}`]), []).sort().join("&");
		}
		return keys.sort().map((key) => serialized[key]).filter((serialized) => serialized).join("&");
	};
	const iso8601 = (time) => toDate(time).toISOString().replace(/\.\d{3}Z$/, "Z");
	const toDate = (time) => {
		if (typeof time === "number") return /* @__PURE__ */ new Date(time * 1e3);
		if (typeof time === "string") {
			if (Number(time)) return /* @__PURE__ */ new Date(Number(time) * 1e3);
			return new Date(time);
		}
		return time;
	};
	var SignatureV4Base = class {
		service;
		regionProvider;
		credentialProvider;
		sha256;
		uriEscapePath;
		applyChecksum;
		constructor({ applyChecksum, credentials, region, service, sha256, uriEscapePath = true }) {
			this.service = service;
			this.sha256 = sha256;
			this.uriEscapePath = uriEscapePath;
			this.applyChecksum = typeof applyChecksum === "boolean" ? applyChecksum : true;
			this.regionProvider = utilMiddleware.normalizeProvider(region);
			this.credentialProvider = utilMiddleware.normalizeProvider(credentials);
		}
		createCanonicalRequest(request, canonicalHeaders, payloadHash) {
			const sortedHeaders = Object.keys(canonicalHeaders).sort();
			return `${request.method}
${this.getCanonicalPath(request)}
${getCanonicalQuery(request)}
${sortedHeaders.map((name) => `${name}:${canonicalHeaders[name]}`).join("\n")}

${sortedHeaders.join(";")}
${payloadHash}`;
		}
		async createStringToSign(longDate, credentialScope, canonicalRequest, algorithmIdentifier) {
			const hash = new this.sha256();
			hash.update(utilUtf8.toUint8Array(canonicalRequest));
			const hashedRequest = await hash.digest();
			return `${algorithmIdentifier}
${longDate}
${credentialScope}
${utilHexEncoding.toHex(hashedRequest)}`;
		}
		getCanonicalPath({ path }) {
			if (this.uriEscapePath) {
				const normalizedPathSegments = [];
				for (const pathSegment of path.split("/")) {
					if (pathSegment?.length === 0) continue;
					if (pathSegment === ".") continue;
					if (pathSegment === "..") normalizedPathSegments.pop();
					else normalizedPathSegments.push(pathSegment);
				}
				const normalizedPath = `${path?.startsWith("/") ? "/" : ""}${normalizedPathSegments.join("/")}${normalizedPathSegments.length > 0 && path?.endsWith("/") ? "/" : ""}`;
				return utilUriEscape.escapeUri(normalizedPath).replace(/%2F/g, "/");
			}
			return path;
		}
		validateResolvedCredentials(credentials) {
			if (typeof credentials !== "object" || typeof credentials.accessKeyId !== "string" || typeof credentials.secretAccessKey !== "string") throw new Error("Resolved credential object is not valid");
		}
		formatDate(now) {
			const longDate = iso8601(now).replace(/[\-:]/g, "");
			return {
				longDate,
				shortDate: longDate.slice(0, 8)
			};
		}
		getCanonicalHeaderList(headers) {
			return Object.keys(headers).sort().join(";");
		}
	};
	var SignatureV4 = class extends SignatureV4Base {
		headerFormatter = new HeaderFormatter();
		constructor({ applyChecksum, credentials, region, service, sha256, uriEscapePath = true }) {
			super({
				applyChecksum,
				credentials,
				region,
				service,
				sha256,
				uriEscapePath
			});
		}
		async presign(originalRequest, options = {}) {
			const { signingDate = /* @__PURE__ */ new Date(), expiresIn = 3600, unsignableHeaders, unhoistableHeaders, signableHeaders, hoistableHeaders, signingRegion, signingService } = options;
			const credentials = await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const { longDate, shortDate } = this.formatDate(signingDate);
			if (expiresIn > MAX_PRESIGNED_TTL) return Promise.reject("Signature version 4 presigned URLs must have an expiration date less than one week in the future");
			const scope = createScope(shortDate, region, signingService ?? this.service);
			const request = moveHeadersToQuery(prepareRequest(originalRequest), {
				unhoistableHeaders,
				hoistableHeaders
			});
			if (credentials.sessionToken) request.query[TOKEN_QUERY_PARAM] = credentials.sessionToken;
			request.query[ALGORITHM_QUERY_PARAM] = ALGORITHM_IDENTIFIER;
			request.query[CREDENTIAL_QUERY_PARAM] = `${credentials.accessKeyId}/${scope}`;
			request.query[AMZ_DATE_QUERY_PARAM] = longDate;
			request.query[EXPIRES_QUERY_PARAM] = expiresIn.toString(10);
			const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
			request.query[SIGNED_HEADERS_QUERY_PARAM] = this.getCanonicalHeaderList(canonicalHeaders);
			request.query[SIGNATURE_QUERY_PARAM] = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, await getPayloadHash(originalRequest, this.sha256)));
			return request;
		}
		async sign(toSign, options) {
			if (typeof toSign === "string") return this.signString(toSign, options);
			else if (toSign.headers && toSign.payload) return this.signEvent(toSign, options);
			else if (toSign.message) return this.signMessage(toSign, options);
			else return this.signRequest(toSign, options);
		}
		async signEvent({ headers, payload }, { signingDate = /* @__PURE__ */ new Date(), priorSignature, signingRegion, signingService, eventStreamCredentials }) {
			const region = signingRegion ?? await this.regionProvider();
			const { shortDate, longDate } = this.formatDate(signingDate);
			const scope = createScope(shortDate, region, signingService ?? this.service);
			const hashedPayload = await getPayloadHash({
				headers: {},
				body: payload
			}, this.sha256);
			const hash = new this.sha256();
			hash.update(headers);
			const stringToSign = [
				EVENT_ALGORITHM_IDENTIFIER,
				longDate,
				scope,
				priorSignature,
				utilHexEncoding.toHex(await hash.digest()),
				hashedPayload
			].join("\n");
			return this.signString(stringToSign, {
				signingDate,
				signingRegion: region,
				signingService,
				eventStreamCredentials
			});
		}
		async signMessage(signableMessage, { signingDate = /* @__PURE__ */ new Date(), signingRegion, signingService, eventStreamCredentials }) {
			return this.signEvent({
				headers: this.headerFormatter.format(signableMessage.message.headers),
				payload: signableMessage.message.body
			}, {
				signingDate,
				signingRegion,
				signingService,
				priorSignature: signableMessage.priorSignature,
				eventStreamCredentials
			}).then((signature) => {
				return {
					message: signableMessage.message,
					signature
				};
			});
		}
		async signString(stringToSign, { signingDate = /* @__PURE__ */ new Date(), signingRegion, signingService, eventStreamCredentials } = {}) {
			const credentials = eventStreamCredentials ?? await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const { shortDate } = this.formatDate(signingDate);
			const hash = new this.sha256(await this.getSigningKey(credentials, region, shortDate, signingService));
			hash.update(utilUtf8.toUint8Array(stringToSign));
			return utilHexEncoding.toHex(await hash.digest());
		}
		async signRequest(requestToSign, { signingDate = /* @__PURE__ */ new Date(), signableHeaders, unsignableHeaders, signingRegion, signingService } = {}) {
			const credentials = await this.credentialProvider();
			this.validateResolvedCredentials(credentials);
			const region = signingRegion ?? await this.regionProvider();
			const request = prepareRequest(requestToSign);
			const { longDate, shortDate } = this.formatDate(signingDate);
			const scope = createScope(shortDate, region, signingService ?? this.service);
			request.headers[AMZ_DATE_HEADER] = longDate;
			if (credentials.sessionToken) request.headers[TOKEN_HEADER] = credentials.sessionToken;
			const payloadHash = await getPayloadHash(request, this.sha256);
			if (!hasHeader(SHA256_HEADER, request.headers) && this.applyChecksum) request.headers[SHA256_HEADER] = payloadHash;
			const canonicalHeaders = getCanonicalHeaders(request, unsignableHeaders, signableHeaders);
			const signature = await this.getSignature(longDate, scope, this.getSigningKey(credentials, region, shortDate, signingService), this.createCanonicalRequest(request, canonicalHeaders, payloadHash));
			request.headers[AUTH_HEADER] = `${ALGORITHM_IDENTIFIER} Credential=${credentials.accessKeyId}/${scope}, SignedHeaders=${this.getCanonicalHeaderList(canonicalHeaders)}, Signature=${signature}`;
			return request;
		}
		async getSignature(longDate, credentialScope, keyPromise, canonicalRequest) {
			const stringToSign = await this.createStringToSign(longDate, credentialScope, canonicalRequest, ALGORITHM_IDENTIFIER);
			const hash = new this.sha256(await keyPromise);
			hash.update(utilUtf8.toUint8Array(stringToSign));
			return utilHexEncoding.toHex(await hash.digest());
		}
		getSigningKey(credentials, region, shortDate, service) {
			return getSigningKey(this.sha256, credentials, shortDate, region, service || this.service);
		}
	};
	const signatureV4aContainer = { SignatureV4a: null };
	exports.ALGORITHM_IDENTIFIER = ALGORITHM_IDENTIFIER;
	exports.ALGORITHM_IDENTIFIER_V4A = ALGORITHM_IDENTIFIER_V4A;
	exports.ALGORITHM_QUERY_PARAM = ALGORITHM_QUERY_PARAM;
	exports.ALWAYS_UNSIGNABLE_HEADERS = ALWAYS_UNSIGNABLE_HEADERS;
	exports.AMZ_DATE_HEADER = AMZ_DATE_HEADER;
	exports.AMZ_DATE_QUERY_PARAM = AMZ_DATE_QUERY_PARAM;
	exports.AUTH_HEADER = AUTH_HEADER;
	exports.CREDENTIAL_QUERY_PARAM = CREDENTIAL_QUERY_PARAM;
	exports.DATE_HEADER = DATE_HEADER;
	exports.EVENT_ALGORITHM_IDENTIFIER = EVENT_ALGORITHM_IDENTIFIER;
	exports.EXPIRES_QUERY_PARAM = EXPIRES_QUERY_PARAM;
	exports.GENERATED_HEADERS = GENERATED_HEADERS;
	exports.HOST_HEADER = HOST_HEADER;
	exports.KEY_TYPE_IDENTIFIER = KEY_TYPE_IDENTIFIER;
	exports.MAX_CACHE_SIZE = MAX_CACHE_SIZE;
	exports.MAX_PRESIGNED_TTL = MAX_PRESIGNED_TTL;
	exports.PROXY_HEADER_PATTERN = PROXY_HEADER_PATTERN;
	exports.REGION_SET_PARAM = REGION_SET_PARAM;
	exports.SEC_HEADER_PATTERN = SEC_HEADER_PATTERN;
	exports.SHA256_HEADER = SHA256_HEADER;
	exports.SIGNATURE_HEADER = SIGNATURE_HEADER;
	exports.SIGNATURE_QUERY_PARAM = SIGNATURE_QUERY_PARAM;
	exports.SIGNED_HEADERS_QUERY_PARAM = SIGNED_HEADERS_QUERY_PARAM;
	exports.SignatureV4 = SignatureV4;
	exports.SignatureV4Base = SignatureV4Base;
	exports.TOKEN_HEADER = TOKEN_HEADER;
	exports.TOKEN_QUERY_PARAM = TOKEN_QUERY_PARAM;
	exports.UNSIGNABLE_PATTERNS = UNSIGNABLE_PATTERNS;
	exports.UNSIGNED_PAYLOAD = UNSIGNED_PAYLOAD;
	exports.clearCredentialCache = clearCredentialCache;
	exports.createScope = createScope;
	exports.getCanonicalHeaders = getCanonicalHeaders;
	exports.getCanonicalQuery = getCanonicalQuery;
	exports.getPayloadHash = getPayloadHash;
	exports.getSigningKey = getSigningKey;
	exports.hasHeader = hasHeader;
	exports.moveHeadersToQuery = moveHeadersToQuery;
	exports.prepareRequest = prepareRequest;
	exports.signatureV4aContainer = signatureV4aContainer;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/resolveAwsSdkSigV4Config.js
function normalizeCredentialProvider(config, { credentials, credentialDefaultProvider }) {
	let credentialsProvider;
	if (credentials) if (!credentials?.memoized) credentialsProvider = memoizeIdentityProvider(credentials, isIdentityExpired, doesIdentityRequireRefresh);
	else credentialsProvider = credentials;
	else if (credentialDefaultProvider) credentialsProvider = normalizeProvider(credentialDefaultProvider(Object.assign({}, config, { parentClientConfig: config })));
	else credentialsProvider = async () => {
		throw new Error("@aws-sdk/core::resolveAwsSdkSigV4Config - `credentials` not provided and no credentialDefaultProvider was configured.");
	};
	credentialsProvider.memoized = true;
	return credentialsProvider;
}
function bindCallerConfig(config, credentialsProvider) {
	if (credentialsProvider.configBound) return credentialsProvider;
	const fn = async (options) => credentialsProvider({
		...options,
		callerClientConfig: config
	});
	fn.memoized = credentialsProvider.memoized;
	fn.configBound = true;
	return fn;
}
var import_dist_cjs$20, resolveAwsSdkSigV4Config, resolveAWSSDKSigV4Config;
var init_resolveAwsSdkSigV4Config = require_chunk.__esmMin((() => {
	require_client.init_client();
	init_dist_es();
	import_dist_cjs$20 = require_dist_cjs$6();
	resolveAwsSdkSigV4Config = (config) => {
		let inputCredentials = config.credentials;
		let isUserSupplied = !!config.credentials;
		let resolvedCredentials = void 0;
		Object.defineProperty(config, "credentials", {
			set(credentials) {
				if (credentials && credentials !== inputCredentials && credentials !== resolvedCredentials) isUserSupplied = true;
				inputCredentials = credentials;
				const boundProvider = bindCallerConfig(config, normalizeCredentialProvider(config, {
					credentials: inputCredentials,
					credentialDefaultProvider: config.credentialDefaultProvider
				}));
				if (isUserSupplied && !boundProvider.attributed) {
					const isCredentialObject = typeof inputCredentials === "object" && inputCredentials !== null;
					resolvedCredentials = async (options) => {
						const attributedCreds = await boundProvider(options);
						if (isCredentialObject && (!attributedCreds.$source || Object.keys(attributedCreds.$source).length === 0)) return require_client.setCredentialFeature(attributedCreds, "CREDENTIALS_CODE", "e");
						return attributedCreds;
					};
					resolvedCredentials.memoized = boundProvider.memoized;
					resolvedCredentials.configBound = boundProvider.configBound;
					resolvedCredentials.attributed = true;
				} else resolvedCredentials = boundProvider;
			},
			get() {
				return resolvedCredentials;
			},
			enumerable: true,
			configurable: true
		});
		config.credentials = inputCredentials;
		const { signingEscapePath = true, systemClockOffset = config.systemClockOffset || 0, sha256 } = config;
		let signer;
		if (config.signer) signer = normalizeProvider(config.signer);
		else if (config.regionInfoProvider) signer = () => normalizeProvider(config.region)().then(async (region) => [await config.regionInfoProvider(region, {
			useFipsEndpoint: await config.useFipsEndpoint(),
			useDualstackEndpoint: await config.useDualstackEndpoint()
		}) || {}, region]).then(([regionInfo, region]) => {
			const { signingRegion, signingService } = regionInfo;
			config.signingRegion = config.signingRegion || signingRegion || region;
			config.signingName = config.signingName || signingService || config.serviceId;
			const params = {
				...config,
				credentials: config.credentials,
				region: config.signingRegion,
				service: config.signingName,
				sha256,
				uriEscapePath: signingEscapePath
			};
			return new (config.signerConstructor || import_dist_cjs$20.SignatureV4)(params);
		});
		else signer = async (authScheme) => {
			authScheme = Object.assign({}, {
				name: "sigv4",
				signingName: config.signingName || config.defaultSigningName,
				signingRegion: await normalizeProvider(config.region)(),
				properties: {}
			}, authScheme);
			const signingRegion = authScheme.signingRegion;
			const signingService = authScheme.signingName;
			config.signingRegion = config.signingRegion || signingRegion;
			config.signingName = config.signingName || signingService || config.serviceId;
			const params = {
				...config,
				credentials: config.credentials,
				region: config.signingRegion,
				service: config.signingName,
				sha256,
				uriEscapePath: signingEscapePath
			};
			return new (config.signerConstructor || import_dist_cjs$20.SignatureV4)(params);
		};
		return Object.assign(config, {
			systemClockOffset,
			signingEscapePath,
			signer
		});
	};
	resolveAWSSDKSigV4Config = resolveAwsSdkSigV4Config;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/aws_sdk/index.js
var init_aws_sdk = require_chunk.__esmMin((() => {
	init_AwsSdkSigV4Signer();
	init_AwsSdkSigV4ASigner();
	init_NODE_AUTH_SCHEME_PREFERENCE_OPTIONS();
	init_resolveAwsSdkSigV4AConfig();
	init_resolveAwsSdkSigV4Config();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/httpAuthSchemes/index.js
var httpAuthSchemes_exports = /* @__PURE__ */ require_chunk.__exportAll({
	AWSSDKSigV4Signer: () => AWSSDKSigV4Signer,
	AwsSdkSigV4ASigner: () => AwsSdkSigV4ASigner,
	AwsSdkSigV4Signer: () => AwsSdkSigV4Signer,
	NODE_AUTH_SCHEME_PREFERENCE_OPTIONS: () => NODE_AUTH_SCHEME_PREFERENCE_OPTIONS,
	NODE_SIGV4A_CONFIG_OPTIONS: () => NODE_SIGV4A_CONFIG_OPTIONS,
	getBearerTokenEnvKey: () => getBearerTokenEnvKey,
	resolveAWSSDKSigV4Config: () => resolveAWSSDKSigV4Config,
	resolveAwsSdkSigV4AConfig: () => resolveAwsSdkSigV4AConfig,
	resolveAwsSdkSigV4Config: () => resolveAwsSdkSigV4Config,
	validateSigningProperties: () => validateSigningProperties
});
var init_httpAuthSchemes = require_chunk.__esmMin((() => {
	init_aws_sdk();
	init_getBearerTokenEnvKey();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+util-user-agent-node@3.973.24/node_modules/@aws-sdk/util-user-agent-node/dist-cjs/index.js
var require_dist_cjs$5 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var node_os = require("node:os");
	var node_process = require("node:process");
	var utilConfigProvider = require_dist_cjs$12();
	var promises = require("node:fs/promises");
	var node_path = require("node:path");
	var middlewareUserAgent = require_dist_cjs$13();
	const getRuntimeUserAgentPair = () => {
		for (const runtime of [
			"deno",
			"bun",
			"llrt"
		]) if (node_process.versions[runtime]) return [`md/${runtime}`, node_process.versions[runtime]];
		return ["md/nodejs", node_process.versions.node];
	};
	const getNodeModulesParentDirs = (dirname) => {
		const cwd = process.cwd();
		if (!dirname) return [cwd];
		const normalizedPath = node_path.normalize(dirname);
		const parts = normalizedPath.split(node_path.sep);
		const nodeModulesIndex = parts.indexOf("node_modules");
		const parentDir = nodeModulesIndex !== -1 ? parts.slice(0, nodeModulesIndex).join(node_path.sep) : normalizedPath;
		if (cwd === parentDir) return [cwd];
		return [parentDir, cwd];
	};
	const SEMVER_REGEX = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\.(?:0|[1-9]\d*|\d*[a-zA-Z-][0-9a-zA-Z-]*))*))?(?:\+[0-9a-zA-Z-]+(?:\.[0-9a-zA-Z-]+)*)?$/;
	const getSanitizedTypeScriptVersion = (version = "") => {
		const match = version.match(SEMVER_REGEX);
		if (!match) return;
		const [major, minor, patch, prerelease] = [
			match[1],
			match[2],
			match[3],
			match[4]
		];
		return prerelease ? `${major}.${minor}.${patch}-${prerelease}` : `${major}.${minor}.${patch}`;
	};
	const ALLOWED_PREFIXES = [
		"^",
		"~",
		">=",
		"<=",
		">",
		"<"
	];
	const ALLOWED_DIST_TAGS = [
		"latest",
		"beta",
		"dev",
		"rc",
		"insiders",
		"next"
	];
	const getSanitizedDevTypeScriptVersion = (version = "") => {
		if (ALLOWED_DIST_TAGS.includes(version)) return version;
		const prefix = ALLOWED_PREFIXES.find((p) => version.startsWith(p)) ?? "";
		const sanitizedTypeScriptVersion = getSanitizedTypeScriptVersion(version.slice(prefix.length));
		if (!sanitizedTypeScriptVersion) return;
		return `${prefix}${sanitizedTypeScriptVersion}`;
	};
	let tscVersion;
	const TS_PACKAGE_JSON = node_path.join("node_modules", "typescript", "package.json");
	const getTypeScriptUserAgentPair = async () => {
		if (tscVersion === null) return;
		else if (typeof tscVersion === "string") return ["md/tsc", tscVersion];
		let isTypeScriptDetectionDisabled = false;
		try {
			isTypeScriptDetectionDisabled = utilConfigProvider.booleanSelector(process.env, "AWS_SDK_JS_TYPESCRIPT_DETECTION_DISABLED", utilConfigProvider.SelectorType.ENV) || false;
		} catch {}
		if (isTypeScriptDetectionDisabled) {
			tscVersion = null;
			return;
		}
		const nodeModulesParentDirs = getNodeModulesParentDirs(typeof __dirname !== "undefined" ? __dirname : void 0);
		let versionFromApp;
		for (const nodeModulesParentDir of nodeModulesParentDirs) try {
			const appPackageJsonPath = node_path.join(nodeModulesParentDir, "package.json");
			const packageJson = await promises.readFile(appPackageJsonPath, "utf-8");
			const { dependencies, devDependencies } = JSON.parse(packageJson);
			const version = devDependencies?.typescript ?? dependencies?.typescript;
			if (typeof version !== "string") continue;
			versionFromApp = version;
			break;
		} catch {}
		if (!versionFromApp) {
			tscVersion = null;
			return;
		}
		let versionFromNodeModules;
		for (const nodeModulesParentDir of nodeModulesParentDirs) try {
			const tsPackageJsonPath = node_path.join(nodeModulesParentDir, TS_PACKAGE_JSON);
			const packageJson = await promises.readFile(tsPackageJsonPath, "utf-8");
			const { version } = JSON.parse(packageJson);
			const sanitizedVersion = getSanitizedTypeScriptVersion(version);
			if (typeof sanitizedVersion !== "string") continue;
			versionFromNodeModules = sanitizedVersion;
			break;
		} catch {}
		if (versionFromNodeModules) {
			tscVersion = versionFromNodeModules;
			return ["md/tsc", tscVersion];
		}
		const sanitizedVersion = getSanitizedDevTypeScriptVersion(versionFromApp);
		if (typeof sanitizedVersion !== "string") {
			tscVersion = null;
			return;
		}
		tscVersion = `dev_${sanitizedVersion}`;
		return ["md/tsc", tscVersion];
	};
	const crtAvailability = { isCrtAvailable: false };
	const isCrtAvailable = () => {
		if (crtAvailability.isCrtAvailable) return ["md/crt-avail"];
		return null;
	};
	const createDefaultUserAgentProvider = ({ serviceId, clientVersion }) => {
		const runtimeUserAgentPair = getRuntimeUserAgentPair();
		return async (config) => {
			const sections = [
				["aws-sdk-js", clientVersion],
				["ua", "2.1"],
				[`os/${node_os.platform()}`, node_os.release()],
				["lang/js"],
				runtimeUserAgentPair
			];
			const typescriptUserAgentPair = await getTypeScriptUserAgentPair();
			if (typescriptUserAgentPair) sections.push(typescriptUserAgentPair);
			const crtAvailable = isCrtAvailable();
			if (crtAvailable) sections.push(crtAvailable);
			if (serviceId) sections.push([`api/${serviceId}`, clientVersion]);
			if (node_process.env.AWS_EXECUTION_ENV) sections.push([`exec-env/${node_process.env.AWS_EXECUTION_ENV}`]);
			const appId = await config?.userAgentAppId?.();
			return appId ? [...sections, [`app/${appId}`]] : [...sections];
		};
	};
	const defaultUserAgent = createDefaultUserAgentProvider;
	const UA_APP_ID_ENV_NAME = "AWS_SDK_UA_APP_ID";
	const UA_APP_ID_INI_NAME = "sdk_ua_app_id";
	const UA_APP_ID_INI_NAME_DEPRECATED = "sdk-ua-app-id";
	exports.NODE_APP_ID_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => env[UA_APP_ID_ENV_NAME],
		configFileSelector: (profile) => profile[UA_APP_ID_INI_NAME] ?? profile[UA_APP_ID_INI_NAME_DEPRECATED],
		default: middlewareUserAgent.DEFAULT_UA_APP_ID
	};
	exports.UA_APP_ID_ENV_NAME = UA_APP_ID_ENV_NAME;
	exports.UA_APP_ID_INI_NAME = UA_APP_ID_INI_NAME;
	exports.createDefaultUserAgentProvider = createDefaultUserAgentProvider;
	exports.crtAvailability = crtAvailability;
	exports.defaultUserAgent = defaultUserAgent;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+hash-node@4.2.14/node_modules/@smithy/hash-node/dist-cjs/index.js
var require_dist_cjs$4 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var utilBufferFrom = require_dist_cjs$39.require_dist_cjs$1();
	var utilUtf8 = require_dist_cjs$39.require_dist_cjs();
	var buffer = require("buffer");
	var crypto = require("crypto");
	var Hash = class {
		algorithmIdentifier;
		secret;
		hash;
		constructor(algorithmIdentifier, secret) {
			this.algorithmIdentifier = algorithmIdentifier;
			this.secret = secret;
			this.reset();
		}
		update(toHash, encoding) {
			this.hash.update(utilUtf8.toUint8Array(castSourceData(toHash, encoding)));
		}
		digest() {
			return Promise.resolve(this.hash.digest());
		}
		reset() {
			this.hash = this.secret ? crypto.createHmac(this.algorithmIdentifier, castSourceData(this.secret)) : crypto.createHash(this.algorithmIdentifier);
		}
	};
	function castSourceData(toCast, encoding) {
		if (buffer.Buffer.isBuffer(toCast)) return toCast;
		if (typeof toCast === "string") return utilBufferFrom.fromString(toCast, encoding);
		if (ArrayBuffer.isView(toCast)) return utilBufferFrom.fromArrayBuffer(toCast.buffer, toCast.byteOffset, toCast.byteLength);
		return utilBufferFrom.fromArrayBuffer(toCast);
	}
	exports.Hash = Hash;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+util-body-length-node@4.2.3/node_modules/@smithy/util-body-length-node/dist-cjs/index.js
var require_dist_cjs$3 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var node_fs = require("node:fs");
	const calculateBodyLength = (body) => {
		if (!body) return 0;
		if (typeof body === "string") return Buffer.byteLength(body);
		else if (typeof body.byteLength === "number") return body.byteLength;
		else if (typeof body.size === "number") return body.size;
		else if (typeof body.start === "number" && typeof body.end === "number") return body.end + 1 - body.start;
		else if (body instanceof node_fs.ReadStream) {
			if (body.path != null) return node_fs.lstatSync(body.path).size;
			else if (typeof body.fd === "number") return node_fs.fstatSync(body.fd).size;
		}
		throw new Error(`Body Length computation failed for ${body}`);
	};
	exports.calculateBodyLength = calculateBodyLength;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+util-defaults-mode-node@4.2.54/node_modules/@smithy/util-defaults-mode-node/dist-cjs/index.js
var require_dist_cjs$2 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var configResolver = require_dist_cjs$11();
	var nodeConfigProvider = require_dist_cjs$43.require_dist_cjs();
	var propertyProvider = require_dist_cjs$41.require_dist_cjs();
	const AWS_EXECUTION_ENV = "AWS_EXECUTION_ENV";
	const AWS_REGION_ENV = "AWS_REGION";
	const AWS_DEFAULT_REGION_ENV = "AWS_DEFAULT_REGION";
	const ENV_IMDS_DISABLED = "AWS_EC2_METADATA_DISABLED";
	const DEFAULTS_MODE_OPTIONS = [
		"in-region",
		"cross-region",
		"mobile",
		"standard",
		"legacy"
	];
	const IMDS_REGION_PATH = "/latest/meta-data/placement/region";
	const AWS_DEFAULTS_MODE_ENV = "AWS_DEFAULTS_MODE";
	const AWS_DEFAULTS_MODE_CONFIG = "defaults_mode";
	const NODE_DEFAULTS_MODE_CONFIG_OPTIONS = {
		environmentVariableSelector: (env) => {
			return env[AWS_DEFAULTS_MODE_ENV];
		},
		configFileSelector: (profile) => {
			return profile[AWS_DEFAULTS_MODE_CONFIG];
		},
		default: "legacy"
	};
	const resolveDefaultsModeConfig = ({ region = nodeConfigProvider.loadConfig(configResolver.NODE_REGION_CONFIG_OPTIONS), defaultsMode = nodeConfigProvider.loadConfig(NODE_DEFAULTS_MODE_CONFIG_OPTIONS) } = {}) => propertyProvider.memoize(async () => {
		const mode = typeof defaultsMode === "function" ? await defaultsMode() : defaultsMode;
		switch (mode?.toLowerCase()) {
			case "auto": return resolveNodeDefaultsModeAuto(region);
			case "in-region":
			case "cross-region":
			case "mobile":
			case "standard":
			case "legacy": return Promise.resolve(mode?.toLocaleLowerCase());
			case void 0: return Promise.resolve("legacy");
			default: throw new Error(`Invalid parameter for "defaultsMode", expect ${DEFAULTS_MODE_OPTIONS.join(", ")}, got ${mode}`);
		}
	});
	const resolveNodeDefaultsModeAuto = async (clientRegion) => {
		if (clientRegion) {
			const resolvedRegion = typeof clientRegion === "function" ? await clientRegion() : clientRegion;
			const inferredRegion = await inferPhysicalRegion();
			if (!inferredRegion) return "standard";
			if (resolvedRegion === inferredRegion) return "in-region";
			else return "cross-region";
		}
		return "standard";
	};
	const inferPhysicalRegion = async () => {
		if (process.env[AWS_EXECUTION_ENV] && (process.env[AWS_REGION_ENV] || process.env[AWS_DEFAULT_REGION_ENV])) return process.env[AWS_REGION_ENV] ?? process.env[AWS_DEFAULT_REGION_ENV];
		if (!process.env[ENV_IMDS_DISABLED]) try {
			const { getInstanceMetadataEndpoint, httpRequest } = await Promise.resolve().then(() => /* @__PURE__ */ require_chunk.__toESM(require("./dist-cjs-BJYtsQtW.cjs").default));
			return (await httpRequest({
				...await getInstanceMetadataEndpoint(),
				path: IMDS_REGION_PATH
			})).toString();
		} catch (e) {}
	};
	exports.resolveDefaultsModeConfig = resolveDefaultsModeConfig;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/cbor-types.js
function alloc(size) {
	return typeof Buffer !== "undefined" ? Buffer.alloc(size) : new Uint8Array(size);
}
function tag(data) {
	data[tagSymbol] = true;
	return data;
}
var tagSymbol;
var init_cbor_types = require_chunk.__esmMin((() => {
	tagSymbol = Symbol("@smithy/core/cbor::tagSymbol");
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/cbor-decode.js
function setPayload(bytes) {
	payload = bytes;
	dataView$1 = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
}
function decode(at, to) {
	if (at >= to) throw new Error("unexpected end of (decode) payload.");
	const major = (payload[at] & 224) >> 5;
	const minor = payload[at] & 31;
	switch (major) {
		case 0:
		case 1:
		case 6:
			let unsignedInt;
			let offset;
			if (minor < 24) {
				unsignedInt = minor;
				offset = 1;
			} else switch (minor) {
				case 24:
				case 25:
				case 26:
				case 27:
					const countLength = minorValueToArgumentLength[minor];
					const countOffset = countLength + 1;
					offset = countOffset;
					if (to - at < countOffset) throw new Error(`countLength ${countLength} greater than remaining buf len.`);
					const countIndex = at + 1;
					if (countLength === 1) unsignedInt = payload[countIndex];
					else if (countLength === 2) unsignedInt = dataView$1.getUint16(countIndex);
					else if (countLength === 4) unsignedInt = dataView$1.getUint32(countIndex);
					else unsignedInt = dataView$1.getBigUint64(countIndex);
					break;
				default: throw new Error(`unexpected minor value ${minor}.`);
			}
			if (major === 0) {
				_offset = offset;
				return castBigInt(unsignedInt);
			} else if (major === 1) {
				let negativeInt;
				if (typeof unsignedInt === "bigint") negativeInt = BigInt(-1) - unsignedInt;
				else negativeInt = -1 - unsignedInt;
				_offset = offset;
				return castBigInt(negativeInt);
			} else if (minor === 2 || minor === 3) {
				const length = decodeCount(at + offset, to);
				let b = BigInt(0);
				const start = at + offset + _offset;
				for (let i = start; i < start + length; ++i) b = b << BigInt(8) | BigInt(payload[i]);
				_offset = offset + _offset + length;
				return minor === 3 ? -b - BigInt(1) : b;
			} else if (minor === 4) {
				const [exponent, mantissa] = decode(at + offset, to);
				const normalizer = mantissa < 0 ? -1 : 1;
				const mantissaStr = "0".repeat(Math.abs(exponent) + 1) + String(BigInt(normalizer) * BigInt(mantissa));
				let numericString;
				const sign = mantissa < 0 ? "-" : "";
				numericString = exponent === 0 ? mantissaStr : mantissaStr.slice(0, mantissaStr.length + exponent) + "." + mantissaStr.slice(exponent);
				numericString = numericString.replace(/^0+/g, "");
				if (numericString === "") numericString = "0";
				if (numericString[0] === ".") numericString = "0" + numericString;
				numericString = sign + numericString;
				_offset = offset + _offset;
				return require_dist_cjs$38.nv(numericString);
			} else {
				const value = decode(at + offset, to);
				_offset = offset + _offset;
				return tag({
					tag: castBigInt(unsignedInt),
					value
				});
			}
		case 3:
		case 5:
		case 4:
		case 2: if (minor === 31) switch (major) {
			case 3: return decodeUtf8StringIndefinite(at, to);
			case 5: return decodeMapIndefinite(at, to);
			case 4: return decodeListIndefinite(at, to);
			case 2: return decodeUnstructuredByteStringIndefinite(at, to);
		}
		else switch (major) {
			case 3: return decodeUtf8String(at, to);
			case 5: return decodeMap(at, to);
			case 4: return decodeList(at, to);
			case 2: return decodeUnstructuredByteString(at, to);
		}
		default: return decodeSpecial(at, to);
	}
}
function bytesToUtf8(bytes, at, to) {
	if (USE_BUFFER$1 && bytes.constructor?.name === "Buffer") return bytes.toString("utf-8", at, to);
	if (textDecoder) return textDecoder.decode(bytes.subarray(at, to));
	return (0, import_dist_cjs$19.toUtf8)(bytes.subarray(at, to));
}
function demote(bigInteger) {
	const num = Number(bigInteger);
	if (num < Number.MIN_SAFE_INTEGER || Number.MAX_SAFE_INTEGER < num) console.warn(/* @__PURE__ */ new Error(`@smithy/core/cbor - truncating BigInt(${bigInteger}) to ${num} with loss of precision.`));
	return num;
}
function bytesToFloat16(a, b) {
	const sign = a >> 7;
	const exponent = (a & 124) >> 2;
	const fraction = (a & 3) << 8 | b;
	const scalar = sign === 0 ? 1 : -1;
	let exponentComponent;
	let summation;
	if (exponent === 0) if (fraction === 0) return 0;
	else {
		exponentComponent = Math.pow(2, -14);
		summation = 0;
	}
	else if (exponent === 31) if (fraction === 0) return scalar * Infinity;
	else return NaN;
	else {
		exponentComponent = Math.pow(2, exponent - 15);
		summation = 1;
	}
	summation += fraction / 1024;
	return scalar * (exponentComponent * summation);
}
function decodeCount(at, to) {
	const minor = payload[at] & 31;
	if (minor < 24) {
		_offset = 1;
		return minor;
	}
	if (minor === 24 || minor === 25 || minor === 26 || minor === 27) {
		const countLength = minorValueToArgumentLength[minor];
		_offset = countLength + 1;
		if (to - at < _offset) throw new Error(`countLength ${countLength} greater than remaining buf len.`);
		const countIndex = at + 1;
		if (countLength === 1) return payload[countIndex];
		else if (countLength === 2) return dataView$1.getUint16(countIndex);
		else if (countLength === 4) return dataView$1.getUint32(countIndex);
		return demote(dataView$1.getBigUint64(countIndex));
	}
	throw new Error(`unexpected minor value ${minor}.`);
}
function decodeUtf8String(at, to) {
	const length = decodeCount(at, to);
	const offset = _offset;
	at += offset;
	if (to - at < length) throw new Error(`string len ${length} greater than remaining buf len.`);
	const value = bytesToUtf8(payload, at, at + length);
	_offset = offset + length;
	return value;
}
function decodeUtf8StringIndefinite(at, to) {
	at += 1;
	const vector = [];
	for (const base = at; at < to;) {
		if (payload[at] === 255) {
			const data = alloc(vector.length);
			data.set(vector, 0);
			_offset = at - base + 2;
			return bytesToUtf8(data, 0, data.length);
		}
		const major = (payload[at] & 224) >> 5;
		const minor = payload[at] & 31;
		if (major !== 3) throw new Error(`unexpected major type ${major} in indefinite string.`);
		if (minor === 31) throw new Error("nested indefinite string.");
		const bytes = decodeUnstructuredByteString(at, to);
		at += _offset;
		for (let i = 0; i < bytes.length; ++i) vector.push(bytes[i]);
	}
	throw new Error("expected break marker.");
}
function decodeUnstructuredByteString(at, to) {
	const length = decodeCount(at, to);
	const offset = _offset;
	at += offset;
	if (to - at < length) throw new Error(`unstructured byte string len ${length} greater than remaining buf len.`);
	const value = payload.subarray(at, at + length);
	_offset = offset + length;
	return value;
}
function decodeUnstructuredByteStringIndefinite(at, to) {
	at += 1;
	const vector = [];
	for (const base = at; at < to;) {
		if (payload[at] === 255) {
			const data = alloc(vector.length);
			data.set(vector, 0);
			_offset = at - base + 2;
			return data;
		}
		const major = (payload[at] & 224) >> 5;
		const minor = payload[at] & 31;
		if (major !== 2) throw new Error(`unexpected major type ${major} in indefinite string.`);
		if (minor === 31) throw new Error("nested indefinite string.");
		const bytes = decodeUnstructuredByteString(at, to);
		at += _offset;
		for (let i = 0; i < bytes.length; ++i) vector.push(bytes[i]);
	}
	throw new Error("expected break marker.");
}
function decodeList(at, to) {
	const listDataLength = decodeCount(at, to);
	const offset = _offset;
	at += offset;
	const base = at;
	const list = Array(listDataLength);
	for (let i = 0; i < listDataLength; ++i) {
		const item = decode(at, to);
		const itemOffset = _offset;
		list[i] = item;
		at += itemOffset;
	}
	_offset = offset + (at - base);
	return list;
}
function decodeListIndefinite(at, to) {
	at += 1;
	const list = [];
	for (const base = at; at < to;) {
		if (payload[at] === 255) {
			_offset = at - base + 2;
			return list;
		}
		const item = decode(at, to);
		at += _offset;
		list.push(item);
	}
	throw new Error("expected break marker.");
}
function decodeMap(at, to) {
	const mapDataLength = decodeCount(at, to);
	const offset = _offset;
	at += offset;
	const base = at;
	const map = {};
	for (let i = 0; i < mapDataLength; ++i) {
		if (at >= to) throw new Error("unexpected end of map payload.");
		const major = (payload[at] & 224) >> 5;
		if (major !== 3) throw new Error(`unexpected major type ${major} for map key at index ${at}.`);
		const key = decode(at, to);
		at += _offset;
		const value = decode(at, to);
		at += _offset;
		map[key] = value;
	}
	_offset = offset + (at - base);
	return map;
}
function decodeMapIndefinite(at, to) {
	at += 1;
	const base = at;
	const map = {};
	for (; at < to;) {
		if (at >= to) throw new Error("unexpected end of map payload.");
		if (payload[at] === 255) {
			_offset = at - base + 2;
			return map;
		}
		const major = (payload[at] & 224) >> 5;
		if (major !== 3) throw new Error(`unexpected major type ${major} for map key.`);
		const key = decode(at, to);
		at += _offset;
		const value = decode(at, to);
		at += _offset;
		map[key] = value;
	}
	throw new Error("expected break marker.");
}
function decodeSpecial(at, to) {
	const minor = payload[at] & 31;
	switch (minor) {
		case 21:
		case 20:
			_offset = 1;
			return minor === 21;
		case 22:
			_offset = 1;
			return null;
		case 23:
			_offset = 1;
			return null;
		case 25:
			if (to - at < 3) throw new Error("incomplete float16 at end of buf.");
			_offset = 3;
			return bytesToFloat16(payload[at + 1], payload[at + 2]);
		case 26:
			if (to - at < 5) throw new Error("incomplete float32 at end of buf.");
			_offset = 5;
			return dataView$1.getFloat32(at + 1);
		case 27:
			if (to - at < 9) throw new Error("incomplete float64 at end of buf.");
			_offset = 9;
			return dataView$1.getFloat64(at + 1);
		default: throw new Error(`unexpected minor value ${minor}.`);
	}
}
function castBigInt(bigInt) {
	if (typeof bigInt === "number") return bigInt;
	const num = Number(bigInt);
	if (Number.MIN_SAFE_INTEGER <= num && num <= Number.MAX_SAFE_INTEGER) return num;
	return bigInt;
}
var import_dist_cjs$19, USE_TEXT_DECODER, USE_BUFFER$1, payload, dataView$1, textDecoder, _offset, minorValueToArgumentLength;
var init_cbor_decode = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_serde();
	import_dist_cjs$19 = require_dist_cjs$39.require_dist_cjs();
	init_cbor_types();
	USE_TEXT_DECODER = typeof TextDecoder !== "undefined";
	USE_BUFFER$1 = typeof Buffer !== "undefined";
	payload = alloc(0);
	dataView$1 = new DataView(payload.buffer, payload.byteOffset, payload.byteLength);
	textDecoder = USE_TEXT_DECODER ? new TextDecoder() : null;
	_offset = 0;
	minorValueToArgumentLength = {
		[24]: 1,
		[25]: 2,
		[26]: 4,
		[27]: 8
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/cbor-encode.js
function ensureSpace(bytes) {
	if (data.byteLength - cursor < bytes) if (cursor < 16e6) resize(Math.max(data.byteLength * 4, data.byteLength + bytes));
	else resize(data.byteLength + bytes + 16e6);
}
function toUint8Array() {
	const out = alloc(cursor);
	out.set(data.subarray(0, cursor), 0);
	cursor = 0;
	return out;
}
function resize(size) {
	const old = data;
	data = alloc(size);
	if (old) if (old.copy) old.copy(data, 0, 0, old.byteLength);
	else data.set(old, 0);
	dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
}
function encodeHeader(major, value) {
	if (value < 24) data[cursor++] = major << 5 | value;
	else if (value < 256) {
		data[cursor++] = major << 5 | 24;
		data[cursor++] = value;
	} else if (value < 65536) {
		data[cursor++] = major << 5 | 25;
		dataView.setUint16(cursor, value);
		cursor += 2;
	} else if (value < 2 ** 32) {
		data[cursor++] = major << 5 | 26;
		dataView.setUint32(cursor, value);
		cursor += 4;
	} else {
		data[cursor++] = major << 5 | 27;
		dataView.setBigUint64(cursor, typeof value === "bigint" ? value : BigInt(value));
		cursor += 8;
	}
}
function encode(_input) {
	const encodeStack = [_input];
	while (encodeStack.length) {
		const input = encodeStack.pop();
		ensureSpace(typeof input === "string" ? input.length * 4 : 64);
		if (typeof input === "string") {
			if (USE_BUFFER) {
				encodeHeader(3, Buffer.byteLength(input));
				cursor += data.write(input, cursor);
			} else {
				const bytes = (0, import_dist_cjs$18.fromUtf8)(input);
				encodeHeader(3, bytes.byteLength);
				data.set(bytes, cursor);
				cursor += bytes.byteLength;
			}
			continue;
		} else if (typeof input === "number") {
			if (Number.isInteger(input)) {
				const nonNegative = input >= 0;
				const major = nonNegative ? 0 : 1;
				const value = nonNegative ? input : -input - 1;
				if (value < 24) data[cursor++] = major << 5 | value;
				else if (value < 256) {
					data[cursor++] = major << 5 | 24;
					data[cursor++] = value;
				} else if (value < 65536) {
					data[cursor++] = major << 5 | 25;
					data[cursor++] = value >> 8;
					data[cursor++] = value;
				} else if (value < 4294967296) {
					data[cursor++] = major << 5 | 26;
					dataView.setUint32(cursor, value);
					cursor += 4;
				} else {
					data[cursor++] = major << 5 | 27;
					dataView.setBigUint64(cursor, BigInt(value));
					cursor += 8;
				}
				continue;
			}
			data[cursor++] = 251;
			dataView.setFloat64(cursor, input);
			cursor += 8;
			continue;
		} else if (typeof input === "bigint") {
			const nonNegative = input >= 0;
			const major = nonNegative ? 0 : 1;
			const value = nonNegative ? input : -input - BigInt(1);
			const n = Number(value);
			if (n < 24) data[cursor++] = major << 5 | n;
			else if (n < 256) {
				data[cursor++] = major << 5 | 24;
				data[cursor++] = n;
			} else if (n < 65536) {
				data[cursor++] = major << 5 | 25;
				data[cursor++] = n >> 8;
				data[cursor++] = n & 255;
			} else if (n < 4294967296) {
				data[cursor++] = major << 5 | 26;
				dataView.setUint32(cursor, n);
				cursor += 4;
			} else if (value < BigInt("18446744073709551616")) {
				data[cursor++] = major << 5 | 27;
				dataView.setBigUint64(cursor, value);
				cursor += 8;
			} else {
				const binaryBigInt = value.toString(2);
				const bigIntBytes = new Uint8Array(Math.ceil(binaryBigInt.length / 8));
				let b = value;
				let i = 0;
				while (bigIntBytes.byteLength - ++i >= 0) {
					bigIntBytes[bigIntBytes.byteLength - i] = Number(b & BigInt(255));
					b >>= BigInt(8);
				}
				ensureSpace(bigIntBytes.byteLength * 2);
				data[cursor++] = nonNegative ? 194 : 195;
				if (USE_BUFFER) encodeHeader(2, Buffer.byteLength(bigIntBytes));
				else encodeHeader(2, bigIntBytes.byteLength);
				data.set(bigIntBytes, cursor);
				cursor += bigIntBytes.byteLength;
			}
			continue;
		} else if (input === null) {
			data[cursor++] = 246;
			continue;
		} else if (typeof input === "boolean") {
			data[cursor++] = 224 | (input ? 21 : 20);
			continue;
		} else if (typeof input === "undefined") throw new Error("@smithy/core/cbor: client may not serialize undefined value.");
		else if (Array.isArray(input)) {
			for (let i = input.length - 1; i >= 0; --i) encodeStack.push(input[i]);
			encodeHeader(4, input.length);
			continue;
		} else if (typeof input.byteLength === "number") {
			ensureSpace(input.length * 2);
			encodeHeader(2, input.length);
			data.set(input, cursor);
			cursor += input.byteLength;
			continue;
		} else if (typeof input === "object") {
			if (input instanceof require_dist_cjs$38.NumericValue) {
				const decimalIndex = input.string.indexOf(".");
				const exponent = decimalIndex === -1 ? 0 : decimalIndex - input.string.length + 1;
				const mantissa = BigInt(input.string.replace(".", ""));
				data[cursor++] = 196;
				encodeStack.push(mantissa);
				encodeStack.push(exponent);
				encodeHeader(4, 2);
				continue;
			}
			if (input[tagSymbol]) if ("tag" in input && "value" in input) {
				encodeStack.push(input.value);
				encodeHeader(6, input.tag);
				continue;
			} else throw new Error("tag encountered with missing fields, need 'tag' and 'value', found: " + JSON.stringify(input));
			const keys = Object.keys(input);
			for (let i = keys.length - 1; i >= 0; --i) {
				const key = keys[i];
				encodeStack.push(input[key]);
				encodeStack.push(key);
			}
			encodeHeader(5, keys.length);
			continue;
		}
		throw new Error(`data type ${input?.constructor?.name ?? typeof input} not compatible for encoding.`);
	}
}
var import_dist_cjs$18, USE_BUFFER, data, dataView, cursor;
var init_cbor_encode = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_serde();
	import_dist_cjs$18 = require_dist_cjs$39.require_dist_cjs();
	init_cbor_types();
	USE_BUFFER = typeof Buffer !== "undefined";
	data = alloc(2048);
	dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
	cursor = 0;
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/cbor.js
var cbor;
var init_cbor$1 = require_chunk.__esmMin((() => {
	init_cbor_decode();
	init_cbor_encode();
	cbor = {
		deserialize(payload) {
			setPayload(payload);
			return decode(0, payload.length);
		},
		serialize(input) {
			try {
				encode(input);
				return toUint8Array();
			} catch (e) {
				toUint8Array();
				throw e;
			}
		},
		resizeEncodingBuffer(size) {
			resize(size);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/parseCborBody.js
var dateToTag, loadSmithyRpcV2CborErrorCode;
var init_parseCborBody = require_chunk.__esmMin((() => {
	init_cbor_types();
	dateToTag = (date) => {
		return tag({
			tag: 1,
			value: date.getTime() / 1e3
		});
	};
	loadSmithyRpcV2CborErrorCode = (output, data) => {
		const sanitizeErrorCode = (rawValue) => {
			let cleanValue = rawValue;
			if (typeof cleanValue === "number") cleanValue = cleanValue.toString();
			if (cleanValue.indexOf(",") >= 0) cleanValue = cleanValue.split(",")[0];
			if (cleanValue.indexOf(":") >= 0) cleanValue = cleanValue.split(":")[0];
			if (cleanValue.indexOf("#") >= 0) cleanValue = cleanValue.split("#")[1];
			return cleanValue;
		};
		if (data["__type"] !== void 0) return sanitizeErrorCode(data["__type"]);
		let codeKey;
		for (const key in data) if (key.toLowerCase() === "code") {
			codeKey = key;
			break;
		}
		if (codeKey && data[codeKey] !== void 0) return sanitizeErrorCode(data[codeKey]);
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/CborCodec.js
var import_dist_cjs$17, CborCodec, CborShapeSerializer, CborShapeDeserializer;
var init_CborCodec = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	require_dist_cjs$38.init_serde();
	import_dist_cjs$17 = require_dist_cjs$38.require_dist_cjs$6();
	init_cbor$1();
	init_parseCborBody();
	CborCodec = class extends require_dist_cjs$38.SerdeContext {
		createSerializer() {
			const serializer = new CborShapeSerializer();
			serializer.setSerdeContext(this.serdeContext);
			return serializer;
		}
		createDeserializer() {
			const deserializer = new CborShapeDeserializer();
			deserializer.setSerdeContext(this.serdeContext);
			return deserializer;
		}
	};
	CborShapeSerializer = class extends require_dist_cjs$38.SerdeContext {
		value;
		write(schema, value) {
			this.value = this.serialize(schema, value);
		}
		serialize(schema, source) {
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			if (source == null) {
				if (ns.isIdempotencyToken()) return (0, require_dist_cjs$38.import_dist_cjs.v4)();
				return source;
			}
			if (ns.isBlobSchema()) {
				if (typeof source === "string") return (this.serdeContext?.base64Decoder ?? import_dist_cjs$17.fromBase64)(source);
				return source;
			}
			if (ns.isTimestampSchema()) {
				if (typeof source === "number" || typeof source === "bigint") return dateToTag(/* @__PURE__ */ new Date(Number(source) / 1e3 | 0));
				return dateToTag(source);
			}
			if (typeof source === "function" || typeof source === "object") {
				const sourceObject = source;
				if (ns.isListSchema() && Array.isArray(sourceObject)) {
					const sparse = !!ns.getMergedTraits().sparse;
					const newArray = [];
					let i = 0;
					for (const item of sourceObject) {
						const value = this.serialize(ns.getValueSchema(), item);
						if (value != null || sparse) newArray[i++] = value;
					}
					return newArray;
				}
				if (sourceObject instanceof Date) return dateToTag(sourceObject);
				const newObject = {};
				if (ns.isMapSchema()) {
					const sparse = !!ns.getMergedTraits().sparse;
					for (const key in sourceObject) {
						const value = this.serialize(ns.getValueSchema(), sourceObject[key]);
						if (value != null || sparse) newObject[key] = value;
					}
				} else if (ns.isStructSchema()) {
					for (const [key, memberSchema] of ns.structIterator()) {
						const value = this.serialize(memberSchema, sourceObject[key]);
						if (value != null) newObject[key] = value;
					}
					if (ns.isUnionSchema() && Array.isArray(sourceObject.$unknown)) {
						const [k, v] = sourceObject.$unknown;
						newObject[k] = v;
					} else if (typeof sourceObject.__type === "string") {
						for (const k in sourceObject) if (!(k in newObject)) newObject[k] = this.serialize(15, sourceObject[k]);
					}
				} else if (ns.isDocumentSchema()) for (const key in sourceObject) newObject[key] = this.serialize(ns.getValueSchema(), sourceObject[key]);
				else if (ns.isBigDecimalSchema()) return sourceObject;
				return newObject;
			}
			return source;
		}
		flush() {
			const buffer = cbor.serialize(this.value);
			this.value = void 0;
			return buffer;
		}
	};
	CborShapeDeserializer = class extends require_dist_cjs$38.SerdeContext {
		read(schema, bytes) {
			const data = cbor.deserialize(bytes);
			return this.readValue(schema, data);
		}
		readValue(_schema, value) {
			const ns = require_dist_cjs$38.NormalizedSchema.of(_schema);
			if (ns.isTimestampSchema()) {
				if (typeof value === "number") return require_dist_cjs$38._parseEpochTimestamp(value);
				if (typeof value === "object") {
					if (value.tag === 1 && "value" in value) return require_dist_cjs$38._parseEpochTimestamp(value.value);
				}
			}
			if (ns.isBlobSchema()) {
				if (typeof value === "string") return (this.serdeContext?.base64Decoder ?? import_dist_cjs$17.fromBase64)(value);
				return value;
			}
			if (typeof value === "undefined" || typeof value === "boolean" || typeof value === "number" || typeof value === "string" || typeof value === "bigint" || typeof value === "symbol") return value;
			else if (typeof value === "object") {
				if (value === null) return null;
				if ("byteLength" in value) return value;
				if (value instanceof Date) return value;
				if (ns.isDocumentSchema()) return value;
				if (ns.isListSchema()) {
					const newArray = [];
					const memberSchema = ns.getValueSchema();
					for (const item of value) {
						const itemValue = this.readValue(memberSchema, item);
						newArray.push(itemValue);
					}
					return newArray;
				}
				const newObject = {};
				if (ns.isMapSchema()) {
					const targetSchema = ns.getValueSchema();
					for (const key in value) newObject[key] = this.readValue(targetSchema, value[key]);
				} else if (ns.isStructSchema()) {
					const isUnion = ns.isUnionSchema();
					let keys;
					if (isUnion) {
						keys = /* @__PURE__ */ new Set();
						for (const k in value) if (k !== "__type") keys.add(k);
					}
					for (const [key, memberSchema] of ns.structIterator()) {
						if (isUnion) keys.delete(key);
						if (value[key] != null) newObject[key] = this.readValue(memberSchema, value[key]);
					}
					if (isUnion && keys?.size === 1) {
						let newObjectEmpty = true;
						for (const _ in newObject) {
							newObjectEmpty = false;
							break;
						}
						if (newObjectEmpty) {
							const k = keys.values().next().value;
							newObject.$unknown = [k, value[k]];
						}
					} else if (typeof value.__type === "string") {
						for (const k in value) if (!(k in newObject)) newObject[k] = value[k];
					}
				} else if (value instanceof require_dist_cjs$38.NumericValue) return value;
				return newObject;
			} else return value;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/SmithyRpcV2CborProtocol.js
var import_dist_cjs$16, SmithyRpcV2CborProtocol;
var init_SmithyRpcV2CborProtocol = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	import_dist_cjs$16 = require_dist_cjs$38.require_dist_cjs$7();
	init_CborCodec();
	init_parseCborBody();
	SmithyRpcV2CborProtocol = class extends require_dist_cjs$38.RpcProtocol {
		codec = new CborCodec();
		serializer = this.codec.createSerializer();
		deserializer = this.codec.createDeserializer();
		constructor({ defaultNamespace, errorTypeRegistries }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
		}
		getShapeId() {
			return "smithy.protocols#rpcv2Cbor";
		}
		getPayloadCodec() {
			return this.codec;
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			Object.assign(request.headers, {
				"content-type": this.getDefaultContentType(),
				"smithy-protocol": "rpc-v2-cbor",
				accept: this.getDefaultContentType()
			});
			if (require_dist_cjs$38.deref(operationSchema.input) === "unit") {
				delete request.body;
				delete request.headers["content-type"];
			} else {
				if (!request.body) {
					this.serializer.write(15, {});
					request.body = this.serializer.flush();
				}
				try {
					request.headers["content-length"] = String(request.body.byteLength);
				} catch (e) {}
			}
			const { service, operation } = (0, import_dist_cjs$16.getSmithyContext)(context);
			const path = `/service/${service}/operation/${operation}`;
			if (request.path.endsWith("/")) request.path += path.slice(1);
			else request.path += path;
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			return super.deserializeResponse(operationSchema, context, response);
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorName = loadSmithyRpcV2CborErrorCode(response, dataObject) ?? "Unknown";
			const errorMetadata = {
				$metadata: metadata,
				$fault: response.statusCode <= 500 ? "client" : "server"
			};
			let namespace = this.options.defaultNamespace;
			if (errorName.includes("#")) [namespace] = errorName.split("#");
			const registry = this.compositeErrorRegistry;
			const nsRegistry = require_dist_cjs$38.TypeRegistry.for(namespace);
			registry.copyFrom(nsRegistry);
			let errorSchema;
			try {
				errorSchema = registry.getSchema(errorName);
			} catch (e) {
				if (dataObject.Message) dataObject.message = dataObject.Message;
				const syntheticRegistry = require_dist_cjs$38.TypeRegistry.for("smithy.ts.sdk.synthetic." + namespace);
				registry.copyFrom(syntheticRegistry);
				const baseExceptionSchema = registry.getBaseException();
				if (baseExceptionSchema) {
					const ErrorCtor = registry.getErrorCtor(baseExceptionSchema);
					throw Object.assign(new ErrorCtor({ name: errorName }), errorMetadata, dataObject);
				}
				throw Object.assign(new Error(errorName), errorMetadata, dataObject);
			}
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const ErrorCtor = registry.getErrorCtor(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "Unknown";
			const exception = new ErrorCtor(message);
			const output = {};
			for (const [name, member] of ns.structIterator()) output[name] = this.deserializer.readValue(member, dataObject[name]);
			throw Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output);
		}
		getDefaultContentType() {
			return "application/cbor";
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@smithy+core@3.23.17/node_modules/@smithy/core/dist-es/submodules/cbor/index.js
var init_cbor = require_chunk.__esmMin((() => {
	init_parseCborBody();
	init_SmithyRpcV2CborProtocol();
	init_CborCodec();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/ProtocolLib.js
var import_dist_cjs$15, ProtocolLib;
var init_ProtocolLib = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_schema();
	import_dist_cjs$15 = require_dist_cjs$38.require_dist_cjs();
	ProtocolLib = class {
		queryCompat;
		errorRegistry;
		constructor(queryCompat = false) {
			this.queryCompat = queryCompat;
		}
		resolveRestContentType(defaultContentType, inputSchema) {
			const members = inputSchema.getMemberSchemas();
			const httpPayloadMember = Object.values(members).find((m) => {
				return !!m.getMergedTraits().httpPayload;
			});
			if (httpPayloadMember) {
				const mediaType = httpPayloadMember.getMergedTraits().mediaType;
				if (mediaType) return mediaType;
				else if (httpPayloadMember.isStringSchema()) return "text/plain";
				else if (httpPayloadMember.isBlobSchema()) return "application/octet-stream";
				else return defaultContentType;
			} else if (!inputSchema.isUnitSchema()) {
				if (Object.values(members).find((m) => {
					const { httpQuery, httpQueryParams, httpHeader, httpLabel, httpPrefixHeaders } = m.getMergedTraits();
					return !httpQuery && !httpQueryParams && !httpHeader && !httpLabel && httpPrefixHeaders === void 0;
				})) return defaultContentType;
			}
		}
		async getErrorSchemaOrThrowBaseException(errorIdentifier, defaultNamespace, response, dataObject, metadata, getErrorSchema) {
			let errorName = errorIdentifier;
			if (errorIdentifier.includes("#")) [, errorName] = errorIdentifier.split("#");
			const errorMetadata = {
				$metadata: metadata,
				$fault: response.statusCode < 500 ? "client" : "server"
			};
			if (!this.errorRegistry) throw new Error("@aws-sdk/core/protocols - error handler not initialized.");
			try {
				return {
					errorSchema: getErrorSchema?.(this.errorRegistry, errorName) ?? this.errorRegistry.getSchema(errorIdentifier),
					errorMetadata
				};
			} catch (e) {
				dataObject.message = dataObject.message ?? dataObject.Message ?? "UnknownError";
				const synthetic = this.errorRegistry;
				const baseExceptionSchema = synthetic.getBaseException();
				if (baseExceptionSchema) {
					const ErrorCtor = synthetic.getErrorCtor(baseExceptionSchema) ?? Error;
					throw this.decorateServiceException(Object.assign(new ErrorCtor({ name: errorName }), errorMetadata), dataObject);
				}
				const d = dataObject;
				const message = d?.message ?? d?.Message ?? d?.Error?.Message ?? d?.Error?.message;
				throw this.decorateServiceException(Object.assign(new Error(message), { name: errorName }, errorMetadata), dataObject);
			}
		}
		compose(composite, errorIdentifier, defaultNamespace) {
			let namespace = defaultNamespace;
			if (errorIdentifier.includes("#")) [namespace] = errorIdentifier.split("#");
			const staticRegistry = require_dist_cjs$38.TypeRegistry.for(namespace);
			const defaultSyntheticRegistry = require_dist_cjs$38.TypeRegistry.for("smithy.ts.sdk.synthetic." + defaultNamespace);
			composite.copyFrom(staticRegistry);
			composite.copyFrom(defaultSyntheticRegistry);
			this.errorRegistry = composite;
		}
		decorateServiceException(exception, additions = {}) {
			if (this.queryCompat) {
				const msg = exception.Message ?? additions.Message;
				const error = (0, import_dist_cjs$15.decorateServiceException)(exception, additions);
				if (msg) error.message = msg;
				const errorObj = error.Error ?? {};
				errorObj.Type = error.Error?.Type;
				errorObj.Code = error.Error?.Code;
				errorObj.Message = error.Error?.message ?? error.Error?.Message ?? msg;
				error.Error = errorObj;
				const reqId = error.$metadata.requestId;
				if (reqId) error.RequestId = reqId;
				return error;
			}
			return (0, import_dist_cjs$15.decorateServiceException)(exception, additions);
		}
		setQueryCompatError(output, response) {
			const queryErrorHeader = response.headers?.["x-amzn-query-error"];
			if (output !== void 0 && queryErrorHeader != null) {
				const [Code, Type] = queryErrorHeader.split(";");
				const keys = Object.keys(output);
				const Error = {
					Code,
					Type
				};
				output.Code = Code;
				output.Type = Type;
				for (let i = 0; i < keys.length; i++) {
					const k = keys[i];
					Error[k === "message" ? "Message" : k] = output[k];
				}
				delete Error.__type;
				output.Error = Error;
			}
		}
		queryCompatOutput(queryCompatErrorData, errorData) {
			if (queryCompatErrorData.Error) errorData.Error = queryCompatErrorData.Error;
			if (queryCompatErrorData.Type) errorData.Type = queryCompatErrorData.Type;
			if (queryCompatErrorData.Code) errorData.Code = queryCompatErrorData.Code;
		}
		findQueryCompatibleError(registry, errorName) {
			try {
				return registry.getSchema(errorName);
			} catch (e) {
				return registry.find((schema) => require_dist_cjs$38.NormalizedSchema.of(schema).getMergedTraits().awsQueryError?.[0] === errorName);
			}
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/cbor/AwsSmithyRpcV2CborProtocol.js
var AwsSmithyRpcV2CborProtocol;
var init_AwsSmithyRpcV2CborProtocol = require_chunk.__esmMin((() => {
	init_cbor();
	require_dist_cjs$38.init_schema();
	init_ProtocolLib();
	AwsSmithyRpcV2CborProtocol = class extends SmithyRpcV2CborProtocol {
		awsQueryCompatible;
		mixin;
		constructor({ defaultNamespace, errorTypeRegistries, awsQueryCompatible }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			this.awsQueryCompatible = !!awsQueryCompatible;
			this.mixin = new ProtocolLib(this.awsQueryCompatible);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (this.awsQueryCompatible) request.headers["x-amzn-query-mode"] = "true";
			return request;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			if (this.awsQueryCompatible) this.mixin.setQueryCompatError(dataObject, response);
			const errorName = (() => {
				const compatHeader = response.headers["x-amzn-query-error"];
				if (compatHeader && this.awsQueryCompatible) return compatHeader.split(";")[0];
				return loadSmithyRpcV2CborErrorCode(response, dataObject) ?? "Unknown";
			})();
			this.mixin.compose(this.compositeErrorRegistry, errorName, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorName, this.options.defaultNamespace, response, dataObject, metadata, this.awsQueryCompatible ? this.mixin.findQueryCompatibleError : void 0);
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)(message);
			const output = {};
			for (const [name, member] of ns.structIterator()) if (dataObject[name] != null) output[name] = this.deserializer.readValue(member, dataObject[name]);
			if (this.awsQueryCompatible) this.mixin.queryCompatOutput(dataObject, output);
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/coercing-serializers.js
var _toStr, _toBool, _toNum;
var init_coercing_serializers = require_chunk.__esmMin((() => {
	_toStr = (val) => {
		if (val == null) return val;
		if (typeof val === "number" || typeof val === "bigint") {
			const warning = /* @__PURE__ */ new Error(`Received number ${val} where a string was expected.`);
			warning.name = "Warning";
			console.warn(warning);
			return String(val);
		}
		if (typeof val === "boolean") {
			const warning = /* @__PURE__ */ new Error(`Received boolean ${val} where a string was expected.`);
			warning.name = "Warning";
			console.warn(warning);
			return String(val);
		}
		return val;
	};
	_toBool = (val) => {
		if (val == null) return val;
		if (typeof val === "number") {}
		if (typeof val === "string") {
			const lowercase = val.toLowerCase();
			if (val !== "" && lowercase !== "false" && lowercase !== "true") {
				const warning = /* @__PURE__ */ new Error(`Received string "${val}" where a boolean was expected.`);
				warning.name = "Warning";
				console.warn(warning);
			}
			return val !== "" && lowercase !== "false";
		}
		return val;
	};
	_toNum = (val) => {
		if (val == null) return val;
		if (typeof val === "boolean") {}
		if (typeof val === "string") {
			const num = Number(val);
			if (num.toString() !== val) {
				const warning = /* @__PURE__ */ new Error(`Received string "${val}" where a number was expected.`);
				warning.name = "Warning";
				console.warn(warning);
				return val;
			}
			return num;
		}
		return val;
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/ConfigurableSerdeContext.js
var SerdeContextConfig;
var init_ConfigurableSerdeContext = require_chunk.__esmMin((() => {
	SerdeContextConfig = class {
		serdeContext;
		setSerdeContext(serdeContext) {
			this.serdeContext = serdeContext;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/UnionSerde.js
var UnionSerde;
var init_UnionSerde = require_chunk.__esmMin((() => {
	UnionSerde = class {
		from;
		to;
		keys;
		constructor(from, to) {
			this.from = from;
			this.to = to;
			const keys = Object.keys(this.from);
			const set = new Set(keys);
			set.delete("__type");
			this.keys = set;
		}
		mark(key) {
			this.keys.delete(key);
		}
		hasUnknown() {
			return this.keys.size === 1 && Object.keys(this.to).length === 0;
		}
		writeUnknown() {
			if (this.hasUnknown()) {
				const k = this.keys.values().next().value;
				const v = this.from[k];
				this.to.$unknown = [k, v];
			}
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/jsonReviver.js
function jsonReviver(key, value, context) {
	if (context?.source) {
		const numericString = context.source;
		if (typeof value === "number") {
			if (value > Number.MAX_SAFE_INTEGER || value < Number.MIN_SAFE_INTEGER || numericString !== String(value)) if (numericString.includes(".")) return new require_dist_cjs$38.NumericValue(numericString, "bigDecimal");
			else return BigInt(numericString);
		}
	}
	return value;
}
var init_jsonReviver = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_serde();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/common.js
var import_dist_cjs$13, import_dist_cjs$14, collectBodyString;
var init_common = require_chunk.__esmMin((() => {
	import_dist_cjs$13 = require_dist_cjs$38.require_dist_cjs();
	import_dist_cjs$14 = require_dist_cjs$39.require_dist_cjs();
	collectBodyString = (streamBody, context) => (0, import_dist_cjs$13.collectBody)(streamBody, context).then((body) => (context?.utf8Encoder ?? import_dist_cjs$14.toUtf8)(body));
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/parseJsonBody.js
var parseJsonBody, parseJsonErrorBody, findKey, sanitizeErrorCode, loadRestJsonErrorCode;
var init_parseJsonBody = require_chunk.__esmMin((() => {
	init_common();
	parseJsonBody = (streamBody, context) => collectBodyString(streamBody, context).then((encoded) => {
		if (encoded.length) try {
			return JSON.parse(encoded);
		} catch (e) {
			if (e?.name === "SyntaxError") Object.defineProperty(e, "$responseBodyText", { value: encoded });
			throw e;
		}
		return {};
	});
	parseJsonErrorBody = async (errorBody, context) => {
		const value = await parseJsonBody(errorBody, context);
		value.message = value.message ?? value.Message;
		return value;
	};
	findKey = (object, key) => Object.keys(object).find((k) => k.toLowerCase() === key.toLowerCase());
	sanitizeErrorCode = (rawValue) => {
		let cleanValue = rawValue;
		if (typeof cleanValue === "number") cleanValue = cleanValue.toString();
		if (cleanValue.indexOf(",") >= 0) cleanValue = cleanValue.split(",")[0];
		if (cleanValue.indexOf(":") >= 0) cleanValue = cleanValue.split(":")[0];
		if (cleanValue.indexOf("#") >= 0) cleanValue = cleanValue.split("#")[1];
		return cleanValue;
	};
	loadRestJsonErrorCode = (output, data) => {
		const headerKey = findKey(output.headers, "x-amzn-errortype");
		if (headerKey !== void 0) return sanitizeErrorCode(output.headers[headerKey]);
		if (data && typeof data === "object") {
			const codeKey = findKey(data, "code");
			if (codeKey && data[codeKey] !== void 0) return sanitizeErrorCode(data[codeKey]);
			if (data["__type"] !== void 0) return sanitizeErrorCode(data["__type"]);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/JsonShapeDeserializer.js
var import_dist_cjs$12, JsonShapeDeserializer;
var init_JsonShapeDeserializer = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	require_dist_cjs$38.init_serde();
	import_dist_cjs$12 = require_dist_cjs$38.require_dist_cjs$6();
	init_ConfigurableSerdeContext();
	init_UnionSerde();
	init_jsonReviver();
	init_parseJsonBody();
	JsonShapeDeserializer = class extends SerdeContextConfig {
		settings;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		async read(schema, data) {
			return this._read(schema, typeof data === "string" ? JSON.parse(data, jsonReviver) : await parseJsonBody(data, this.serdeContext));
		}
		readObject(schema, data) {
			return this._read(schema, data);
		}
		_read(schema, value) {
			const isObject = value !== null && typeof value === "object";
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			if (isObject) {
				if (ns.isStructSchema()) {
					const record = value;
					const union = ns.isUnionSchema();
					const out = {};
					let nameMap = void 0;
					const { jsonName } = this.settings;
					if (jsonName) nameMap = {};
					let unionSerde;
					if (union) unionSerde = new UnionSerde(record, out);
					for (const [memberName, memberSchema] of ns.structIterator()) {
						let fromKey = memberName;
						if (jsonName) {
							fromKey = memberSchema.getMergedTraits().jsonName ?? fromKey;
							nameMap[fromKey] = memberName;
						}
						if (union) unionSerde.mark(fromKey);
						if (record[fromKey] != null) out[memberName] = this._read(memberSchema, record[fromKey]);
					}
					if (union) unionSerde.writeUnknown();
					else if (typeof record.__type === "string") for (const k in record) {
						const v = record[k];
						const t = jsonName ? nameMap[k] ?? k : k;
						if (!(t in out)) out[t] = v;
					}
					return out;
				}
				if (Array.isArray(value) && ns.isListSchema()) {
					const listMember = ns.getValueSchema();
					const out = [];
					for (const item of value) out.push(this._read(listMember, item));
					return out;
				}
				if (ns.isMapSchema()) {
					const mapMember = ns.getValueSchema();
					const out = {};
					for (const _k in value) out[_k] = this._read(mapMember, value[_k]);
					return out;
				}
			}
			if (ns.isBlobSchema() && typeof value === "string") return (0, import_dist_cjs$12.fromBase64)(value);
			const mediaType = ns.getMergedTraits().mediaType;
			if (ns.isStringSchema() && typeof value === "string" && mediaType) {
				if (mediaType === "application/json" || mediaType.endsWith("+json")) return require_dist_cjs$38.LazyJsonString.from(value);
				return value;
			}
			if (ns.isTimestampSchema() && value != null) switch (require_dist_cjs$38.determineTimestampFormat(ns, this.settings)) {
				case 5: return require_dist_cjs$38.parseRfc3339DateTimeWithOffset(value);
				case 6: return require_dist_cjs$38.parseRfc7231DateTime(value);
				case 7: return require_dist_cjs$38.parseEpochTimestamp(value);
				default:
					console.warn("Missing timestamp format, parsing value with Date constructor:", value);
					return new Date(value);
			}
			if (ns.isBigIntegerSchema() && (typeof value === "number" || typeof value === "string")) return BigInt(value);
			if (ns.isBigDecimalSchema() && value != void 0) {
				if (value instanceof require_dist_cjs$38.NumericValue) return value;
				const untyped = value;
				if (untyped.type === "bigDecimal" && "string" in untyped) return new require_dist_cjs$38.NumericValue(untyped.string, untyped.type);
				return new require_dist_cjs$38.NumericValue(String(value), "bigDecimal");
			}
			if (ns.isNumericSchema() && typeof value === "string") {
				switch (value) {
					case "Infinity": return Infinity;
					case "-Infinity": return -Infinity;
					case "NaN": return NaN;
				}
				return value;
			}
			if (ns.isDocumentSchema()) if (isObject) {
				const out = Array.isArray(value) ? [] : {};
				for (const k in value) {
					const v = value[k];
					if (v instanceof require_dist_cjs$38.NumericValue) out[k] = v;
					else out[k] = this._read(ns, v);
				}
				return out;
			} else return structuredClone(value);
			return value;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/jsonReplacer.js
var NUMERIC_CONTROL_CHAR, JsonReplacer;
var init_jsonReplacer = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_serde();
	NUMERIC_CONTROL_CHAR = String.fromCharCode(925);
	JsonReplacer = class {
		values = /* @__PURE__ */ new Map();
		counter = 0;
		stage = 0;
		createReplacer() {
			if (this.stage === 1) throw new Error("@aws-sdk/core/protocols - JsonReplacer already created.");
			if (this.stage === 2) throw new Error("@aws-sdk/core/protocols - JsonReplacer exhausted.");
			this.stage = 1;
			return (key, value) => {
				if (value instanceof require_dist_cjs$38.NumericValue) {
					const v = `${NUMERIC_CONTROL_CHAR + "nv" + this.counter++}_` + value.string;
					this.values.set(`"${v}"`, value.string);
					return v;
				}
				if (typeof value === "bigint") {
					const s = value.toString();
					const v = `${NUMERIC_CONTROL_CHAR + "b" + this.counter++}_` + s;
					this.values.set(`"${v}"`, s);
					return v;
				}
				return value;
			};
		}
		replaceInJson(json) {
			if (this.stage === 0) throw new Error("@aws-sdk/core/protocols - JsonReplacer not created yet.");
			if (this.stage === 2) throw new Error("@aws-sdk/core/protocols - JsonReplacer exhausted.");
			this.stage = 2;
			if (this.counter === 0) return json;
			for (const [key, value] of this.values) json = json.replace(key, value);
			return json;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/JsonShapeSerializer.js
var import_dist_cjs$11, JsonShapeSerializer;
var init_JsonShapeSerializer = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	require_dist_cjs$38.init_serde();
	import_dist_cjs$11 = require_dist_cjs$38.require_dist_cjs$6();
	init_ConfigurableSerdeContext();
	init_jsonReplacer();
	JsonShapeSerializer = class extends SerdeContextConfig {
		settings;
		buffer;
		useReplacer = false;
		rootSchema;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		write(schema, value) {
			this.rootSchema = require_dist_cjs$38.NormalizedSchema.of(schema);
			this.buffer = this._write(this.rootSchema, value);
		}
		flush() {
			const { rootSchema, useReplacer } = this;
			this.rootSchema = void 0;
			this.useReplacer = false;
			if (rootSchema?.isStructSchema() || rootSchema?.isDocumentSchema()) {
				if (!useReplacer) return JSON.stringify(this.buffer);
				const replacer = new JsonReplacer();
				return replacer.replaceInJson(JSON.stringify(this.buffer, replacer.createReplacer(), 0));
			}
			return this.buffer;
		}
		writeDiscriminatedDocument(schema, value) {
			this.write(schema, value);
			if (typeof this.buffer === "object") this.buffer.__type = require_dist_cjs$38.NormalizedSchema.of(schema).getName(true);
		}
		_write(schema, value, container) {
			const isObject = value !== null && typeof value === "object";
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			if (isObject) {
				if (ns.isStructSchema()) {
					const record = value;
					const out = {};
					const { jsonName } = this.settings;
					let nameMap = void 0;
					if (jsonName) nameMap = {};
					let outCount = 0;
					for (const [memberName, memberSchema] of ns.structIterator()) {
						const serializableValue = this._write(memberSchema, record[memberName], ns);
						if (serializableValue !== void 0) {
							let targetKey = memberName;
							if (jsonName) {
								targetKey = memberSchema.getMergedTraits().jsonName ?? memberName;
								nameMap[memberName] = targetKey;
							}
							out[targetKey] = serializableValue;
							outCount++;
						}
					}
					if (ns.isUnionSchema() && outCount === 0) {
						const { $unknown } = record;
						if (Array.isArray($unknown)) {
							const [k, v] = $unknown;
							out[k] = this._write(15, v);
						}
					} else if (typeof record.__type === "string") for (const k in record) {
						const v = record[k];
						const targetKey = jsonName ? nameMap[k] ?? k : k;
						if (!(targetKey in out)) out[targetKey] = this._write(15, v);
					}
					return out;
				}
				if (Array.isArray(value) && ns.isListSchema()) {
					const listMember = ns.getValueSchema();
					const out = [];
					const sparse = !!ns.getMergedTraits().sparse;
					for (const item of value) if (sparse || item != null) out.push(this._write(listMember, item));
					return out;
				}
				if (ns.isMapSchema()) {
					const mapMember = ns.getValueSchema();
					const out = {};
					const sparse = !!ns.getMergedTraits().sparse;
					for (const _k in value) {
						const _v = value[_k];
						if (sparse || _v != null) out[_k] = this._write(mapMember, _v);
					}
					return out;
				}
				if (value instanceof Uint8Array && (ns.isBlobSchema() || ns.isDocumentSchema())) {
					if (ns === this.rootSchema) return value;
					return (this.serdeContext?.base64Encoder ?? import_dist_cjs$11.toBase64)(value);
				}
				if (value instanceof Date && (ns.isTimestampSchema() || ns.isDocumentSchema())) switch (require_dist_cjs$38.determineTimestampFormat(ns, this.settings)) {
					case 5: return value.toISOString().replace(".000Z", "Z");
					case 6: return require_dist_cjs$38.dateToUtcString(value);
					case 7: return value.getTime() / 1e3;
					default:
						console.warn("Missing timestamp format, using epoch seconds", value);
						return value.getTime() / 1e3;
				}
				if (value instanceof require_dist_cjs$38.NumericValue) this.useReplacer = true;
			}
			if (value === null && container?.isStructSchema()) return;
			if (ns.isStringSchema()) {
				if (typeof value === "undefined" && ns.isIdempotencyToken()) return (0, require_dist_cjs$38.import_dist_cjs.v4)();
				const mediaType = ns.getMergedTraits().mediaType;
				if (value != null && mediaType) {
					if (mediaType === "application/json" || mediaType.endsWith("+json")) return require_dist_cjs$38.LazyJsonString.from(value);
				}
				return value;
			}
			if (typeof value === "number" && ns.isNumericSchema()) {
				if (Math.abs(value) === Infinity || isNaN(value)) return String(value);
				return value;
			}
			if (typeof value === "string" && ns.isBlobSchema()) {
				if (ns === this.rootSchema) return value;
				return (this.serdeContext?.base64Encoder ?? import_dist_cjs$11.toBase64)(value);
			}
			if (typeof value === "bigint") this.useReplacer = true;
			if (ns.isDocumentSchema()) if (isObject) {
				const out = Array.isArray(value) ? [] : {};
				for (const k in value) {
					const v = value[k];
					if (v instanceof require_dist_cjs$38.NumericValue) {
						this.useReplacer = true;
						out[k] = v;
					} else out[k] = this._write(ns, v);
				}
				return out;
			} else return structuredClone(value);
			return value;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/JsonCodec.js
var JsonCodec;
var init_JsonCodec = require_chunk.__esmMin((() => {
	init_ConfigurableSerdeContext();
	init_JsonShapeDeserializer();
	init_JsonShapeSerializer();
	JsonCodec = class extends SerdeContextConfig {
		settings;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		createSerializer() {
			const serializer = new JsonShapeSerializer(this.settings);
			serializer.setSerdeContext(this.serdeContext);
			return serializer;
		}
		createDeserializer() {
			const deserializer = new JsonShapeDeserializer(this.settings);
			deserializer.setSerdeContext(this.serdeContext);
			return deserializer;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/AwsJsonRpcProtocol.js
var AwsJsonRpcProtocol;
var init_AwsJsonRpcProtocol = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	init_ProtocolLib();
	init_JsonCodec();
	init_parseJsonBody();
	AwsJsonRpcProtocol = class extends require_dist_cjs$38.RpcProtocol {
		serializer;
		deserializer;
		serviceTarget;
		codec;
		mixin;
		awsQueryCompatible;
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			this.serviceTarget = serviceTarget;
			this.codec = jsonCodec ?? new JsonCodec({
				timestampFormat: {
					useTrait: true,
					default: 7
				},
				jsonName: false
			});
			this.serializer = this.codec.createSerializer();
			this.deserializer = this.codec.createDeserializer();
			this.awsQueryCompatible = !!awsQueryCompatible;
			this.mixin = new ProtocolLib(this.awsQueryCompatible);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (!request.path.endsWith("/")) request.path += "/";
			request.headers["content-type"] = `application/x-amz-json-${this.getJsonRpcVersion()}`;
			request.headers["x-amz-target"] = `${this.serviceTarget}.${operationSchema.name}`;
			if (this.awsQueryCompatible) request.headers["x-amzn-query-mode"] = "true";
			if (require_dist_cjs$38.deref(operationSchema.input) === "unit" || !request.body) request.body = "{}";
			return request;
		}
		getPayloadCodec() {
			return this.codec;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			if (this.awsQueryCompatible) this.mixin.setQueryCompatError(dataObject, response);
			const errorIdentifier = loadRestJsonErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata, this.awsQueryCompatible ? this.mixin.findQueryCompatibleError : void 0);
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)(message);
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) if (dataObject[name] != null) output[name] = errorDeserializer.readObject(member, dataObject[name]);
			if (this.awsQueryCompatible) this.mixin.queryCompatOutput(dataObject, output);
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/AwsJson1_0Protocol.js
var AwsJson1_0Protocol;
var init_AwsJson1_0Protocol = require_chunk.__esmMin((() => {
	init_AwsJsonRpcProtocol();
	AwsJson1_0Protocol = class extends AwsJsonRpcProtocol {
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries,
				serviceTarget,
				awsQueryCompatible,
				jsonCodec
			});
		}
		getShapeId() {
			return "aws.protocols#awsJson1_0";
		}
		getJsonRpcVersion() {
			return "1.0";
		}
		getDefaultContentType() {
			return "application/x-amz-json-1.0";
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/AwsJson1_1Protocol.js
var AwsJson1_1Protocol;
var init_AwsJson1_1Protocol = require_chunk.__esmMin((() => {
	init_AwsJsonRpcProtocol();
	AwsJson1_1Protocol = class extends AwsJsonRpcProtocol {
		constructor({ defaultNamespace, errorTypeRegistries, serviceTarget, awsQueryCompatible, jsonCodec }) {
			super({
				defaultNamespace,
				errorTypeRegistries,
				serviceTarget,
				awsQueryCompatible,
				jsonCodec
			});
		}
		getShapeId() {
			return "aws.protocols#awsJson1_1";
		}
		getJsonRpcVersion() {
			return "1.1";
		}
		getDefaultContentType() {
			return "application/x-amz-json-1.1";
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/AwsRestJsonProtocol.js
var AwsRestJsonProtocol;
var init_AwsRestJsonProtocol = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	init_ProtocolLib();
	init_JsonCodec();
	init_parseJsonBody();
	AwsRestJsonProtocol = class extends require_dist_cjs$38.HttpBindingProtocol {
		serializer;
		deserializer;
		codec;
		mixin = new ProtocolLib();
		constructor({ defaultNamespace, errorTypeRegistries }) {
			super({
				defaultNamespace,
				errorTypeRegistries
			});
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 7
				},
				httpBindings: true,
				jsonName: true
			};
			this.codec = new JsonCodec(settings);
			this.serializer = new require_dist_cjs$38.HttpInterceptingShapeSerializer(this.codec.createSerializer(), settings);
			this.deserializer = new require_dist_cjs$38.HttpInterceptingShapeDeserializer(this.codec.createDeserializer(), settings);
		}
		getShapeId() {
			return "aws.protocols#restJson1";
		}
		getPayloadCodec() {
			return this.codec;
		}
		setSerdeContext(serdeContext) {
			this.codec.setSerdeContext(serdeContext);
			super.setSerdeContext(serdeContext);
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			const inputSchema = require_dist_cjs$38.NormalizedSchema.of(operationSchema.input);
			if (!request.headers["content-type"]) {
				const contentType = this.mixin.resolveRestContentType(this.getDefaultContentType(), inputSchema);
				if (contentType) request.headers["content-type"] = contentType;
			}
			if (request.body == null && request.headers["content-type"] === this.getDefaultContentType()) request.body = "{}";
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			const output = await super.deserializeResponse(operationSchema, context, response);
			const outputSchema = require_dist_cjs$38.NormalizedSchema.of(operationSchema.output);
			for (const [name, member] of outputSchema.structIterator()) if (member.getMemberTraits().httpPayload && !(name in output)) output[name] = null;
			return output;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = loadRestJsonErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata);
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const message = dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)(message);
			await this.deserializeHttpMessage(errorSchema, context, response, dataObject);
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().jsonName ?? name;
				output[name] = errorDeserializer.readObject(member, dataObject[target]);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		getDefaultContentType() {
			return "application/json";
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/json/awsExpectUnion.js
var import_dist_cjs$10, awsExpectUnion;
var init_awsExpectUnion = require_chunk.__esmMin((() => {
	import_dist_cjs$10 = require_dist_cjs$38.require_dist_cjs();
	awsExpectUnion = (value) => {
		if (value == null) return;
		if (typeof value === "object" && "__type" in value) delete value.__type;
		return (0, import_dist_cjs$10.expectUnion)(value);
	};
}));
//#endregion
//#region ../../node_modules/.bun/fast-xml-parser@5.7.2/node_modules/fast-xml-parser/lib/fxp.cjs
var require_fxp = /* @__PURE__ */ require_chunk.__commonJSMin(((exports, module) => {
	(() => {
		"use strict";
		var t = {
			d: (e, n) => {
				for (var i in n) t.o(n, i) && !t.o(e, i) && Object.defineProperty(e, i, {
					enumerable: !0,
					get: n[i]
				});
			},
			o: (t, e) => Object.prototype.hasOwnProperty.call(t, e),
			r: (t) => {
				"undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(t, "__esModule", { value: !0 });
			}
		}, e = {};
		t.r(e), t.d(e, {
			XMLBuilder: () => Bt,
			XMLParser: () => Tt,
			XMLValidator: () => Ut
		});
		const i = /* @__PURE__ */ new RegExp("^[:A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$");
		function s(t, e) {
			const n = [];
			let i = e.exec(t);
			for (; i;) {
				const s = [];
				s.startIndex = e.lastIndex - i[0].length;
				const r = i.length;
				for (let t = 0; t < r; t++) s.push(i[t]);
				n.push(s), i = e.exec(t);
			}
			return n;
		}
		const r = function(t) {
			return !(null == i.exec(t));
		}, o = [
			"hasOwnProperty",
			"toString",
			"valueOf",
			"__defineGetter__",
			"__defineSetter__",
			"__lookupGetter__",
			"__lookupSetter__"
		], a = [
			"__proto__",
			"constructor",
			"prototype"
		], h = {
			allowBooleanAttributes: !1,
			unpairedTags: []
		};
		function l(t, e) {
			e = Object.assign({}, h, e);
			const n = [];
			let i = !1, s = !1;
			"﻿" === t[0] && (t = t.substr(1));
			for (let r = 0; r < t.length; r++) if ("<" === t[r] && "?" === t[r + 1]) {
				if (r += 2, r = p(t, r), r.err) return r;
			} else {
				if ("<" !== t[r]) {
					if (u(t[r])) continue;
					return b("InvalidChar", "char '" + t[r] + "' is not expected.", w(t, r));
				}
				{
					let o = r;
					if (r++, "!" === t[r]) {
						r = c(t, r);
						continue;
					}
					{
						let a = !1;
						"/" === t[r] && (a = !0, r++);
						let h = "";
						for (; r < t.length && ">" !== t[r] && " " !== t[r] && "	" !== t[r] && "\n" !== t[r] && "\r" !== t[r]; r++) h += t[r];
						if (h = h.trim(), "/" === h[h.length - 1] && (h = h.substring(0, h.length - 1), r--), !E(h)) {
							let e;
							return e = 0 === h.trim().length ? "Invalid space after '<'." : "Tag '" + h + "' is an invalid name.", b("InvalidTag", e, w(t, r));
						}
						const l = g(t, r);
						if (!1 === l) return b("InvalidAttr", "Attributes for '" + h + "' have open quote.", w(t, r));
						let d = l.value;
						if (r = l.index, "/" === d[d.length - 1]) {
							const n = r - d.length;
							d = d.substring(0, d.length - 1);
							const s = x(d, e);
							if (!0 !== s) return b(s.err.code, s.err.msg, w(t, n + s.err.line));
							i = !0;
						} else if (a) {
							if (!l.tagClosed) return b("InvalidTag", "Closing tag '" + h + "' doesn't have proper closing.", w(t, r));
							if (d.trim().length > 0) return b("InvalidTag", "Closing tag '" + h + "' can't have attributes or invalid starting.", w(t, o));
							if (0 === n.length) return b("InvalidTag", "Closing tag '" + h + "' has not been opened.", w(t, o));
							{
								const e = n.pop();
								if (h !== e.tagName) {
									let n = w(t, e.tagStartPos);
									return b("InvalidTag", "Expected closing tag '" + e.tagName + "' (opened in line " + n.line + ", col " + n.col + ") instead of closing tag '" + h + "'.", w(t, o));
								}
								0 == n.length && (s = !0);
							}
						} else {
							const a = x(d, e);
							if (!0 !== a) return b(a.err.code, a.err.msg, w(t, r - d.length + a.err.line));
							if (!0 === s) return b("InvalidXml", "Multiple possible root nodes found.", w(t, r));
							-1 !== e.unpairedTags.indexOf(h) || n.push({
								tagName: h,
								tagStartPos: o
							}), i = !0;
						}
						for (r++; r < t.length; r++) if ("<" === t[r]) {
							if ("!" === t[r + 1]) {
								r++, r = c(t, r);
								continue;
							}
							if ("?" !== t[r + 1]) break;
							if (r = p(t, ++r), r.err) return r;
						} else if ("&" === t[r]) {
							const e = N(t, r);
							if (-1 == e) return b("InvalidChar", "char '&' is not expected.", w(t, r));
							r = e;
						} else if (!0 === s && !u(t[r])) return b("InvalidXml", "Extra text at the end", w(t, r));
						"<" === t[r] && r--;
					}
				}
			}
			return i ? 1 == n.length ? b("InvalidTag", "Unclosed tag '" + n[0].tagName + "'.", w(t, n[0].tagStartPos)) : !(n.length > 0) || b("InvalidXml", "Invalid '" + JSON.stringify(n.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", {
				line: 1,
				col: 1
			}) : b("InvalidXml", "Start tag expected.", 1);
		}
		function u(t) {
			return " " === t || "	" === t || "\n" === t || "\r" === t;
		}
		function p(t, e) {
			const n = e;
			for (; e < t.length; e++) if ("?" == t[e] || " " == t[e]) {
				const i = t.substr(n, e - n);
				if (e > 5 && "xml" === i) return b("InvalidXml", "XML declaration allowed only at the start of the document.", w(t, e));
				if ("?" == t[e] && ">" == t[e + 1]) {
					e++;
					break;
				}
				continue;
			}
			return e;
		}
		function c(t, e) {
			if (t.length > e + 5 && "-" === t[e + 1] && "-" === t[e + 2]) {
				for (e += 3; e < t.length; e++) if ("-" === t[e] && "-" === t[e + 1] && ">" === t[e + 2]) {
					e += 2;
					break;
				}
			} else if (t.length > e + 8 && "D" === t[e + 1] && "O" === t[e + 2] && "C" === t[e + 3] && "T" === t[e + 4] && "Y" === t[e + 5] && "P" === t[e + 6] && "E" === t[e + 7]) {
				let n = 1;
				for (e += 8; e < t.length; e++) if ("<" === t[e]) n++;
				else if (">" === t[e] && (n--, 0 === n)) break;
			} else if (t.length > e + 9 && "[" === t[e + 1] && "C" === t[e + 2] && "D" === t[e + 3] && "A" === t[e + 4] && "T" === t[e + 5] && "A" === t[e + 6] && "[" === t[e + 7]) {
				for (e += 8; e < t.length; e++) if ("]" === t[e] && "]" === t[e + 1] && ">" === t[e + 2]) {
					e += 2;
					break;
				}
			}
			return e;
		}
		const d = "\"", f = "'";
		function g(t, e) {
			let n = "", i = "", s = !1;
			for (; e < t.length; e++) {
				if (t[e] === d || t[e] === f) "" === i ? i = t[e] : i !== t[e] || (i = "");
				else if (">" === t[e] && "" === i) {
					s = !0;
					break;
				}
				n += t[e];
			}
			return "" === i && {
				value: n,
				index: e,
				tagClosed: s
			};
		}
		const m = /* @__PURE__ */ new RegExp("(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['\"])(([\\s\\S])*?)\\5)?", "g");
		function x(t, e) {
			const n = s(t, m), i = {};
			for (let t = 0; t < n.length; t++) {
				if (0 === n[t][1].length) return b("InvalidAttr", "Attribute '" + n[t][2] + "' has no space in starting.", v(n[t]));
				if (void 0 !== n[t][3] && void 0 === n[t][4]) return b("InvalidAttr", "Attribute '" + n[t][2] + "' is without value.", v(n[t]));
				if (void 0 === n[t][3] && !e.allowBooleanAttributes) return b("InvalidAttr", "boolean attribute '" + n[t][2] + "' is not allowed.", v(n[t]));
				const s = n[t][2];
				if (!y(s)) return b("InvalidAttr", "Attribute '" + s + "' is an invalid name.", v(n[t]));
				if (Object.prototype.hasOwnProperty.call(i, s)) return b("InvalidAttr", "Attribute '" + s + "' is repeated.", v(n[t]));
				i[s] = 1;
			}
			return !0;
		}
		function N(t, e) {
			if (";" === t[++e]) return -1;
			if ("#" === t[e]) return function(t, e) {
				let n = /\d/;
				for ("x" === t[e] && (e++, n = /[\da-fA-F]/); e < t.length; e++) {
					if (";" === t[e]) return e;
					if (!t[e].match(n)) break;
				}
				return -1;
			}(t, ++e);
			let n = 0;
			for (; e < t.length; e++, n++) if (!(t[e].match(/\w/) && n < 20)) {
				if (";" === t[e]) break;
				return -1;
			}
			return e;
		}
		function b(t, e, n) {
			return { err: {
				code: t,
				msg: e,
				line: n.line || n,
				col: n.col
			} };
		}
		function y(t) {
			return r(t);
		}
		function E(t) {
			return r(t);
		}
		function w(t, e) {
			const n = t.substring(0, e).split(/\r?\n/);
			return {
				line: n.length,
				col: n[n.length - 1].length + 1
			};
		}
		function v(t) {
			return t.startIndex + t[1].length;
		}
		const S = (t) => o.includes(t) ? "__" + t : t, _ = {
			preserveOrder: !1,
			attributeNamePrefix: "@_",
			attributesGroupName: !1,
			textNodeName: "#text",
			ignoreAttributes: !0,
			removeNSPrefix: !1,
			allowBooleanAttributes: !1,
			parseTagValue: !0,
			parseAttributeValue: !1,
			trimValues: !0,
			cdataPropName: !1,
			numberParseOptions: {
				hex: !0,
				leadingZeros: !0,
				eNotation: !0
			},
			tagValueProcessor: function(t, e) {
				return e;
			},
			attributeValueProcessor: function(t, e) {
				return e;
			},
			stopNodes: [],
			alwaysCreateTextNode: !1,
			isArray: () => !1,
			commentPropName: !1,
			unpairedTags: [],
			processEntities: !0,
			htmlEntities: !1,
			entityDecoder: null,
			ignoreDeclaration: !1,
			ignorePiTags: !1,
			transformTagName: !1,
			transformAttributeName: !1,
			updateTag: function(t, e, n) {
				return t;
			},
			captureMetaData: !1,
			maxNestedTags: 100,
			strictReservedNames: !0,
			jPath: !0,
			onDangerousProperty: S
		};
		function A(t, e) {
			if ("string" != typeof t) return;
			const n = t.toLowerCase();
			if (o.some((t) => n === t.toLowerCase())) throw new Error(`[SECURITY] Invalid ${e}: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`);
			if (a.some((t) => n === t.toLowerCase())) throw new Error(`[SECURITY] Invalid ${e}: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`);
		}
		function T(t, e) {
			return "boolean" == typeof t ? {
				enabled: t,
				maxEntitySize: 1e4,
				maxExpansionDepth: 1e4,
				maxTotalExpansions: Infinity,
				maxExpandedLength: 1e5,
				maxEntityCount: 1e3,
				allowedTags: null,
				tagFilter: null,
				appliesTo: "all"
			} : "object" == typeof t && null !== t ? {
				enabled: !1 !== t.enabled,
				maxEntitySize: Math.max(1, t.maxEntitySize ?? 1e4),
				maxExpansionDepth: Math.max(1, t.maxExpansionDepth ?? 1e4),
				maxTotalExpansions: Math.max(1, t.maxTotalExpansions ?? Infinity),
				maxExpandedLength: Math.max(1, t.maxExpandedLength ?? 1e5),
				maxEntityCount: Math.max(1, t.maxEntityCount ?? 1e3),
				allowedTags: t.allowedTags ?? null,
				tagFilter: t.tagFilter ?? null,
				appliesTo: t.appliesTo ?? "all"
			} : T(!0);
		}
		const C = function(t) {
			const e = Object.assign({}, _, t), n = [
				{
					value: e.attributeNamePrefix,
					name: "attributeNamePrefix"
				},
				{
					value: e.attributesGroupName,
					name: "attributesGroupName"
				},
				{
					value: e.textNodeName,
					name: "textNodeName"
				},
				{
					value: e.cdataPropName,
					name: "cdataPropName"
				},
				{
					value: e.commentPropName,
					name: "commentPropName"
				}
			];
			for (const { value: t, name: e } of n) t && A(t, e);
			return null === e.onDangerousProperty && (e.onDangerousProperty = S), e.processEntities = T(e.processEntities, e.htmlEntities), e.unpairedTagsSet = new Set(e.unpairedTags), e.stopNodes && Array.isArray(e.stopNodes) && (e.stopNodes = e.stopNodes.map((t) => "string" == typeof t && t.startsWith("*.") ? ".." + t.substring(2) : t)), e;
		};
		let P;
		P = "function" != typeof Symbol ? "@@xmlMetadata" : Symbol("XML Node Metadata");
		class O {
			constructor(t) {
				this.tagname = t, this.child = [], this[":@"] = Object.create(null);
			}
			add(t, e) {
				"__proto__" === t && (t = "#__proto__"), this.child.push({ [t]: e });
			}
			addChild(t, e) {
				"__proto__" === t.tagname && (t.tagname = "#__proto__"), t[":@"] && Object.keys(t[":@"]).length > 0 ? this.child.push({
					[t.tagname]: t.child,
					":@": t[":@"]
				}) : this.child.push({ [t.tagname]: t.child }), void 0 !== e && (this.child[this.child.length - 1][P] = { startIndex: e });
			}
			static getMetaDataSymbol() {
				return P;
			}
		}
		class $ {
			constructor(t) {
				this.suppressValidationErr = !t, this.options = t;
			}
			readDocType(t, e) {
				const n = Object.create(null);
				let i = 0;
				if ("O" !== t[e + 3] || "C" !== t[e + 4] || "T" !== t[e + 5] || "Y" !== t[e + 6] || "P" !== t[e + 7] || "E" !== t[e + 8]) throw new Error("Invalid Tag instead of DOCTYPE");
				{
					e += 9;
					let s = 1, r = !1, o = !1, a = "";
					for (; e < t.length; e++) if ("<" !== t[e] || o) if (">" === t[e]) {
						if (o ? "-" === t[e - 1] && "-" === t[e - 2] && (o = !1, s--) : s--, 0 === s) break;
					} else "[" === t[e] ? r = !0 : a += t[e];
					else {
						if (r && D(t, "!ENTITY", e)) {
							let s, r;
							if (e += 7, [s, r, e] = this.readEntityExp(t, e + 1, this.suppressValidationErr), -1 === r.indexOf("&")) {
								if (!1 !== this.options.enabled && null != this.options.maxEntityCount && i >= this.options.maxEntityCount) throw new Error(`Entity count (${i + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`);
								n[s] = r, i++;
							}
						} else if (r && D(t, "!ELEMENT", e)) {
							e += 8;
							const { index: n } = this.readElementExp(t, e + 1);
							e = n;
						} else if (r && D(t, "!ATTLIST", e)) e += 8;
						else if (r && D(t, "!NOTATION", e)) {
							e += 9;
							const { index: n } = this.readNotationExp(t, e + 1, this.suppressValidationErr);
							e = n;
						} else {
							if (!D(t, "!--", e)) throw new Error("Invalid DOCTYPE");
							o = !0;
						}
						s++, a = "";
					}
					if (0 !== s) throw new Error("Unclosed DOCTYPE");
				}
				return {
					entities: n,
					i: e
				};
			}
			readEntityExp(t, e) {
				const n = e = I(t, e);
				for (; e < t.length && !/\s/.test(t[e]) && "\"" !== t[e] && "'" !== t[e];) e++;
				let i = t.substring(n, e);
				if (M(i), e = I(t, e), !this.suppressValidationErr) {
					if ("SYSTEM" === t.substring(e, e + 6).toUpperCase()) throw new Error("External entities are not supported");
					if ("%" === t[e]) throw new Error("Parameter entities are not supported");
				}
				let s = "";
				if ([e, s] = this.readIdentifierVal(t, e, "entity"), !1 !== this.options.enabled && null != this.options.maxEntitySize && s.length > this.options.maxEntitySize) throw new Error(`Entity "${i}" size (${s.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`);
				return [
					i,
					s,
					--e
				];
			}
			readNotationExp(t, e) {
				const n = e = I(t, e);
				for (; e < t.length && !/\s/.test(t[e]);) e++;
				let i = t.substring(n, e);
				!this.suppressValidationErr && M(i), e = I(t, e);
				const s = t.substring(e, e + 6).toUpperCase();
				if (!this.suppressValidationErr && "SYSTEM" !== s && "PUBLIC" !== s) throw new Error(`Expected SYSTEM or PUBLIC, found "${s}"`);
				e += s.length, e = I(t, e);
				let r = null, o = null;
				if ("PUBLIC" === s) [e, r] = this.readIdentifierVal(t, e, "publicIdentifier"), "\"" !== t[e = I(t, e)] && "'" !== t[e] || ([e, o] = this.readIdentifierVal(t, e, "systemIdentifier"));
				else if ("SYSTEM" === s && ([e, o] = this.readIdentifierVal(t, e, "systemIdentifier"), !this.suppressValidationErr && !o)) throw new Error("Missing mandatory system identifier for SYSTEM notation");
				return {
					notationName: i,
					publicIdentifier: r,
					systemIdentifier: o,
					index: --e
				};
			}
			readIdentifierVal(t, e, n) {
				let i = "";
				const s = t[e];
				if ("\"" !== s && "'" !== s) throw new Error(`Expected quoted string, found "${s}"`);
				const r = ++e;
				for (; e < t.length && t[e] !== s;) e++;
				if (i = t.substring(r, e), t[e] !== s) throw new Error(`Unterminated ${n} value`);
				return [++e, i];
			}
			readElementExp(t, e) {
				const n = e = I(t, e);
				for (; e < t.length && !/\s/.test(t[e]);) e++;
				let i = t.substring(n, e);
				if (!this.suppressValidationErr && !r(i)) throw new Error(`Invalid element name: "${i}"`);
				let s = "";
				if ("E" === t[e = I(t, e)] && D(t, "MPTY", e)) e += 4;
				else if ("A" === t[e] && D(t, "NY", e)) e += 2;
				else if ("(" === t[e]) {
					const n = ++e;
					for (; e < t.length && ")" !== t[e];) e++;
					if (s = t.substring(n, e), ")" !== t[e]) throw new Error("Unterminated content model");
				} else if (!this.suppressValidationErr) throw new Error(`Invalid Element Expression, found "${t[e]}"`);
				return {
					elementName: i,
					contentModel: s.trim(),
					index: e
				};
			}
			readAttlistExp(t, e) {
				let n = e = I(t, e);
				for (; e < t.length && !/\s/.test(t[e]);) e++;
				let i = t.substring(n, e);
				for (M(i), n = e = I(t, e); e < t.length && !/\s/.test(t[e]);) e++;
				let s = t.substring(n, e);
				if (!M(s)) throw new Error(`Invalid attribute name: "${s}"`);
				e = I(t, e);
				let r = "";
				if ("NOTATION" === t.substring(e, e + 8).toUpperCase()) {
					if (r = "NOTATION", "(" !== t[e = I(t, e += 8)]) throw new Error(`Expected '(', found "${t[e]}"`);
					e++;
					let n = [];
					for (; e < t.length && ")" !== t[e];) {
						const i = e;
						for (; e < t.length && "|" !== t[e] && ")" !== t[e];) e++;
						let s = t.substring(i, e);
						if (s = s.trim(), !M(s)) throw new Error(`Invalid notation name: "${s}"`);
						n.push(s), "|" === t[e] && (e++, e = I(t, e));
					}
					if (")" !== t[e]) throw new Error("Unterminated list of notations");
					e++, r += " (" + n.join("|") + ")";
				} else {
					const n = e;
					for (; e < t.length && !/\s/.test(t[e]);) e++;
					r += t.substring(n, e);
					if (!this.suppressValidationErr && ![
						"CDATA",
						"ID",
						"IDREF",
						"IDREFS",
						"ENTITY",
						"ENTITIES",
						"NMTOKEN",
						"NMTOKENS"
					].includes(r.toUpperCase())) throw new Error(`Invalid attribute type: "${r}"`);
				}
				e = I(t, e);
				let o = "";
				return "#REQUIRED" === t.substring(e, e + 8).toUpperCase() ? (o = "#REQUIRED", e += 8) : "#IMPLIED" === t.substring(e, e + 7).toUpperCase() ? (o = "#IMPLIED", e += 7) : [e, o] = this.readIdentifierVal(t, e, "ATTLIST"), {
					elementName: i,
					attributeName: s,
					attributeType: r,
					defaultValue: o,
					index: e
				};
			}
		}
		const I = (t, e) => {
			for (; e < t.length && /\s/.test(t[e]);) e++;
			return e;
		};
		function D(t, e, n) {
			for (let i = 0; i < e.length; i++) if (e[i] !== t[n + i + 1]) return !1;
			return !0;
		}
		function M(t) {
			if (r(t)) return t;
			throw new Error(`Invalid entity name ${t}`);
		}
		const j = /^[-+]?0x[a-fA-F0-9]+$/, V = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/, L = {
			hex: !0,
			leadingZeros: !0,
			decimalPoint: ".",
			eNotation: !0,
			infinity: "original"
		};
		const k = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
		class F {
			constructor(t) {
				this._matcher = t;
			}
			get separator() {
				return this._matcher.separator;
			}
			getCurrentTag() {
				const t = this._matcher.path;
				return t.length > 0 ? t[t.length - 1].tag : void 0;
			}
			getCurrentNamespace() {
				const t = this._matcher.path;
				return t.length > 0 ? t[t.length - 1].namespace : void 0;
			}
			getAttrValue(t) {
				const e = this._matcher.path;
				if (0 !== e.length) return e[e.length - 1].values?.[t];
			}
			hasAttr(t) {
				const e = this._matcher.path;
				if (0 === e.length) return !1;
				const n = e[e.length - 1];
				return void 0 !== n.values && t in n.values;
			}
			getPosition() {
				const t = this._matcher.path;
				return 0 === t.length ? -1 : t[t.length - 1].position ?? 0;
			}
			getCounter() {
				const t = this._matcher.path;
				return 0 === t.length ? -1 : t[t.length - 1].counter ?? 0;
			}
			getIndex() {
				return this.getPosition();
			}
			getDepth() {
				return this._matcher.path.length;
			}
			toString(t, e = !0) {
				return this._matcher.toString(t, e);
			}
			toArray() {
				return this._matcher.path.map((t) => t.tag);
			}
			matches(t) {
				return this._matcher.matches(t);
			}
			matchesAny(t) {
				return t.matchesAny(this._matcher);
			}
		}
		class R {
			constructor(t = {}) {
				this.separator = t.separator || ".", this.path = [], this.siblingStacks = [], this._pathStringCache = null, this._view = new F(this);
			}
			push(t, e = null, n = null) {
				this._pathStringCache = null, this.path.length > 0 && (this.path[this.path.length - 1].values = void 0);
				const i = this.path.length;
				this.siblingStacks[i] || (this.siblingStacks[i] = /* @__PURE__ */ new Map());
				const s = this.siblingStacks[i], r = n ? `${n}:${t}` : t, o = s.get(r) || 0;
				let a = 0;
				for (const t of s.values()) a += t;
				s.set(r, o + 1);
				const h = {
					tag: t,
					position: a,
					counter: o
				};
				null != n && (h.namespace = n), null != e && (h.values = e), this.path.push(h);
			}
			pop() {
				if (0 === this.path.length) return;
				this._pathStringCache = null;
				const t = this.path.pop();
				return this.siblingStacks.length > this.path.length + 1 && (this.siblingStacks.length = this.path.length + 1), t;
			}
			updateCurrent(t) {
				if (this.path.length > 0) {
					const e = this.path[this.path.length - 1];
					null != t && (e.values = t);
				}
			}
			getCurrentTag() {
				return this.path.length > 0 ? this.path[this.path.length - 1].tag : void 0;
			}
			getCurrentNamespace() {
				return this.path.length > 0 ? this.path[this.path.length - 1].namespace : void 0;
			}
			getAttrValue(t) {
				if (0 !== this.path.length) return this.path[this.path.length - 1].values?.[t];
			}
			hasAttr(t) {
				if (0 === this.path.length) return !1;
				const e = this.path[this.path.length - 1];
				return void 0 !== e.values && t in e.values;
			}
			getPosition() {
				return 0 === this.path.length ? -1 : this.path[this.path.length - 1].position ?? 0;
			}
			getCounter() {
				return 0 === this.path.length ? -1 : this.path[this.path.length - 1].counter ?? 0;
			}
			getIndex() {
				return this.getPosition();
			}
			getDepth() {
				return this.path.length;
			}
			toString(t, e = !0) {
				const n = t || this.separator;
				if (n === this.separator && !0 === e) {
					if (null !== this._pathStringCache) return this._pathStringCache;
					const t = this.path.map((t) => t.namespace ? `${t.namespace}:${t.tag}` : t.tag).join(n);
					return this._pathStringCache = t, t;
				}
				return this.path.map((t) => e && t.namespace ? `${t.namespace}:${t.tag}` : t.tag).join(n);
			}
			toArray() {
				return this.path.map((t) => t.tag);
			}
			reset() {
				this._pathStringCache = null, this.path = [], this.siblingStacks = [];
			}
			matches(t) {
				const e = t.segments;
				return 0 !== e.length && (t.hasDeepWildcard() ? this._matchWithDeepWildcard(e) : this._matchSimple(e));
			}
			_matchSimple(t) {
				if (this.path.length !== t.length) return !1;
				for (let e = 0; e < t.length; e++) if (!this._matchSegment(t[e], this.path[e], e === this.path.length - 1)) return !1;
				return !0;
			}
			_matchWithDeepWildcard(t) {
				let e = this.path.length - 1, n = t.length - 1;
				for (; n >= 0 && e >= 0;) {
					const i = t[n];
					if ("deep-wildcard" === i.type) {
						if (n--, n < 0) return !0;
						const i = t[n];
						let s = !1;
						for (let t = e; t >= 0; t--) if (this._matchSegment(i, this.path[t], t === this.path.length - 1)) {
							e = t - 1, n--, s = !0;
							break;
						}
						if (!s) return !1;
					} else {
						if (!this._matchSegment(i, this.path[e], e === this.path.length - 1)) return !1;
						e--, n--;
					}
				}
				return n < 0;
			}
			_matchSegment(t, e, n) {
				if ("*" !== t.tag && t.tag !== e.tag) return !1;
				if (void 0 !== t.namespace && "*" !== t.namespace && t.namespace !== e.namespace) return !1;
				if (void 0 !== t.attrName) {
					if (!n) return !1;
					if (!e.values || !(t.attrName in e.values)) return !1;
					if (void 0 !== t.attrValue && String(e.values[t.attrName]) !== String(t.attrValue)) return !1;
				}
				if (void 0 !== t.position) {
					if (!n) return !1;
					const i = e.counter ?? 0;
					if ("first" === t.position && 0 !== i) return !1;
					if ("odd" === t.position && i % 2 != 1) return !1;
					if ("even" === t.position && i % 2 != 0) return !1;
					if ("nth" === t.position && i !== t.positionValue) return !1;
				}
				return !0;
			}
			matchesAny(t) {
				return t.matchesAny(this);
			}
			snapshot() {
				return {
					path: this.path.map((t) => ({ ...t })),
					siblingStacks: this.siblingStacks.map((t) => new Map(t))
				};
			}
			restore(t) {
				this._pathStringCache = null, this.path = t.path.map((t) => ({ ...t })), this.siblingStacks = t.siblingStacks.map((t) => new Map(t));
			}
			readOnly() {
				return this._view;
			}
		}
		class G {
			constructor(t, e = {}, n) {
				this.pattern = t, this.separator = e.separator || ".", this.segments = this._parse(t), this.data = n, this._hasDeepWildcard = this.segments.some((t) => "deep-wildcard" === t.type), this._hasAttributeCondition = this.segments.some((t) => void 0 !== t.attrName), this._hasPositionSelector = this.segments.some((t) => void 0 !== t.position);
			}
			_parse(t) {
				const e = [];
				let n = 0, i = "";
				for (; n < t.length;) t[n] === this.separator ? n + 1 < t.length && t[n + 1] === this.separator ? (i.trim() && (e.push(this._parseSegment(i.trim())), i = ""), e.push({ type: "deep-wildcard" }), n += 2) : (i.trim() && e.push(this._parseSegment(i.trim())), i = "", n++) : (i += t[n], n++);
				return i.trim() && e.push(this._parseSegment(i.trim())), e;
			}
			_parseSegment(t) {
				const e = { type: "tag" };
				let n = null, i = t;
				const s = t.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
				if (s && (i = s[1] + s[3], s[2])) {
					const t = s[2].slice(1, -1);
					t && (n = t);
				}
				let r, o, a = i;
				if (i.includes("::")) {
					const e = i.indexOf("::");
					if (r = i.substring(0, e).trim(), a = i.substring(e + 2).trim(), !r) throw new Error(`Invalid namespace in pattern: ${t}`);
				}
				let h = null;
				if (a.includes(":")) {
					const t = a.lastIndexOf(":"), e = a.substring(0, t).trim(), n = a.substring(t + 1).trim();
					[
						"first",
						"last",
						"odd",
						"even"
					].includes(n) || /^nth\(\d+\)$/.test(n) ? (o = e, h = n) : o = a;
				} else o = a;
				if (!o) throw new Error(`Invalid segment pattern: ${t}`);
				if (e.tag = o, r && (e.namespace = r), n) if (n.includes("=")) {
					const t = n.indexOf("=");
					e.attrName = n.substring(0, t).trim(), e.attrValue = n.substring(t + 1).trim();
				} else e.attrName = n.trim();
				if (h) {
					const t = h.match(/^nth\((\d+)\)$/);
					t ? (e.position = "nth", e.positionValue = parseInt(t[1], 10)) : e.position = h;
				}
				return e;
			}
			get length() {
				return this.segments.length;
			}
			hasDeepWildcard() {
				return this._hasDeepWildcard;
			}
			hasAttributeCondition() {
				return this._hasAttributeCondition;
			}
			hasPositionSelector() {
				return this._hasPositionSelector;
			}
			toString() {
				return this.pattern;
			}
		}
		class B {
			constructor() {
				this._byDepthAndTag = /* @__PURE__ */ new Map(), this._wildcardByDepth = /* @__PURE__ */ new Map(), this._deepWildcards = [], this._patterns = /* @__PURE__ */ new Set(), this._sealed = !1;
			}
			add(t) {
				if (this._sealed) throw new TypeError("ExpressionSet is sealed. Create a new ExpressionSet to add more expressions.");
				if (this._patterns.has(t.pattern)) return this;
				if (this._patterns.add(t.pattern), t.hasDeepWildcard()) return this._deepWildcards.push(t), this;
				const e = t.length, i = t.segments[t.segments.length - 1]?.tag;
				if (i && "*" !== i) {
					const n = `${e}:${i}`;
					this._byDepthAndTag.has(n) || this._byDepthAndTag.set(n, []), this._byDepthAndTag.get(n).push(t);
				} else this._wildcardByDepth.has(e) || this._wildcardByDepth.set(e, []), this._wildcardByDepth.get(e).push(t);
				return this;
			}
			addAll(t) {
				for (const e of t) this.add(e);
				return this;
			}
			has(t) {
				return this._patterns.has(t.pattern);
			}
			get size() {
				return this._patterns.size;
			}
			seal() {
				return this._sealed = !0, this;
			}
			get isSealed() {
				return this._sealed;
			}
			matchesAny(t) {
				return null !== this.findMatch(t);
			}
			findMatch(t) {
				const e = t.getDepth(), n = `${e}:${t.getCurrentTag()}`, i = this._byDepthAndTag.get(n);
				if (i) {
					for (let e = 0; e < i.length; e++) if (t.matches(i[e])) return i[e];
				}
				const s = this._wildcardByDepth.get(e);
				if (s) {
					for (let e = 0; e < s.length; e++) if (t.matches(s[e])) return s[e];
				}
				for (let e = 0; e < this._deepWildcards.length; e++) if (t.matches(this._deepWildcards[e])) return this._deepWildcards[e];
				return null;
			}
		}
		const U = {
			cent: "¢",
			pound: "£",
			curren: "¤",
			yen: "¥",
			euro: "€",
			dollar: "$",
			euro: "€",
			fnof: "ƒ",
			inr: "₹",
			af: "؋",
			birr: "ብር",
			peso: "₱",
			rub: "₽",
			won: "₩",
			yuan: "¥",
			cedil: "¸"
		}, W = {
			amp: "&",
			apos: "'",
			gt: ">",
			lt: "<",
			quot: "\""
		}, X = {
			nbsp: "\xA0",
			copy: "©",
			reg: "®",
			trade: "™",
			mdash: "—",
			ndash: "–",
			hellip: "…",
			laquo: "«",
			raquo: "»",
			lsquo: "‘",
			rsquo: "’",
			ldquo: "“",
			rdquo: "”",
			bull: "•",
			para: "¶",
			sect: "§",
			deg: "°",
			frac12: "½",
			frac14: "¼",
			frac34: "¾"
		}, Y = /* @__PURE__ */ new Set("!?\\\\/[]$%{}^&*()<>|+");
		function z(t) {
			if ("#" === t[0]) throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${t}"`);
			for (const e of t) if (Y.has(e)) throw new Error(`[EntityReplacer] Invalid character '${e}' in entity name: "${t}"`);
			return t;
		}
		function q(...t) {
			const e = Object.create(null);
			for (const n of t) if (n) for (const t of Object.keys(n)) {
				const i = n[t];
				if ("string" == typeof i) e[t] = i;
				else if (i && "object" == typeof i && void 0 !== i.val) {
					const n = i.val;
					"string" == typeof n && (e[t] = n);
				}
			}
			return e;
		}
		const Z = "external", J = "base", K = "all", Q = Object.freeze({
			allow: 0,
			leave: 1,
			remove: 2,
			throw: 3
		}), H = new Set([
			9,
			10,
			13
		]);
		class tt {
			constructor(t = {}) {
				var e;
				this._limit = t.limit || {}, this._maxTotalExpansions = this._limit.maxTotalExpansions || 0, this._maxExpandedLength = this._limit.maxExpandedLength || 0, this._postCheck = "function" == typeof t.postCheck ? t.postCheck : (t) => t, this._limitTiers = (e = this._limit.applyLimitsTo ?? Z) && e !== Z ? e === K ? new Set([K]) : e === J ? new Set([J]) : Array.isArray(e) ? new Set(e) : new Set([Z]) : new Set([Z]), this._numericAllowed = t.numericAllowed ?? !0, this._baseMap = q(W, t.namedEntities || null), this._externalMap = Object.create(null), this._inputMap = Object.create(null), this._totalExpansions = 0, this._expandedLength = 0, this._removeSet = new Set(t.remove && Array.isArray(t.remove) ? t.remove : []), this._leaveSet = new Set(t.leave && Array.isArray(t.leave) ? t.leave : []);
				const n = function(t) {
					if (!t) return {
						xmlVersion: 1,
						onLevel: Q.allow,
						nullLevel: Q.remove
					};
					const e = 1.1 === t.xmlVersion ? 1.1 : 1, n = Q[t.onNCR] ?? Q.allow, i = Q[t.nullNCR] ?? Q.remove;
					return {
						xmlVersion: e,
						onLevel: n,
						nullLevel: Math.max(i, Q.remove)
					};
				}(t.ncr);
				this._ncrXmlVersion = n.xmlVersion, this._ncrOnLevel = n.onLevel, this._ncrNullLevel = n.nullLevel;
			}
			setExternalEntities(t) {
				if (t) for (const e of Object.keys(t)) z(e);
				this._externalMap = q(t);
			}
			addExternalEntity(t, e) {
				z(t), "string" == typeof e && -1 === e.indexOf("&") && (this._externalMap[t] = e);
			}
			addInputEntities(t) {
				this._totalExpansions = 0, this._expandedLength = 0, this._inputMap = q(t);
			}
			reset() {
				return this._inputMap = Object.create(null), this._totalExpansions = 0, this._expandedLength = 0, this;
			}
			setXmlVersion(t) {
				this._ncrXmlVersion = 1.1 === t ? 1.1 : 1;
			}
			decode(t) {
				if ("string" != typeof t || 0 === t.length) return t;
				const e = t, n = [], i = t.length;
				let s = 0, r = 0;
				const o = this._maxTotalExpansions > 0, a = this._maxExpandedLength > 0, h = o || a;
				for (; r < i;) {
					if (38 !== t.charCodeAt(r)) {
						r++;
						continue;
					}
					let e = r + 1;
					for (; e < i && 59 !== t.charCodeAt(e) && e - r <= 32;) e++;
					if (e >= i || 59 !== t.charCodeAt(e)) {
						r++;
						continue;
					}
					const l = t.slice(r + 1, e);
					if (0 === l.length) {
						r++;
						continue;
					}
					let u, p;
					if (this._removeSet.has(l)) u = "", void 0 === p && (p = Z);
					else {
						if (this._leaveSet.has(l)) {
							r++;
							continue;
						}
						if (35 === l.charCodeAt(0)) {
							const t = this._resolveNCR(l);
							if (void 0 === t) {
								r++;
								continue;
							}
							u = t, p = J;
						} else {
							const t = this._resolveName(l);
							u = t?.value, p = t?.tier;
						}
					}
					if (void 0 !== u) {
						if (r > s && n.push(t.slice(s, r)), n.push(u), s = e + 1, r = s, h && this._tierCounts(p)) {
							if (o && (this._totalExpansions++, this._totalExpansions > this._maxTotalExpansions)) throw new Error(`[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`);
							if (a) {
								const t = u.length - (l.length + 2);
								if (t > 0 && (this._expandedLength += t, this._expandedLength > this._maxExpandedLength)) throw new Error(`[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`);
							}
						}
					} else r++;
				}
				s < i && n.push(t.slice(s));
				const l = 0 === n.length ? t : n.join("");
				return this._postCheck(l, e);
			}
			_tierCounts(t) {
				return !!this._limitTiers.has(K) || this._limitTiers.has(t);
			}
			_resolveName(t) {
				return t in this._inputMap ? {
					value: this._inputMap[t],
					tier: Z
				} : t in this._externalMap ? {
					value: this._externalMap[t],
					tier: Z
				} : t in this._baseMap ? {
					value: this._baseMap[t],
					tier: J
				} : void 0;
			}
			_classifyNCR(t) {
				return 0 === t ? this._ncrNullLevel : t >= 55296 && t <= 57343 || 1 === this._ncrXmlVersion && t >= 1 && t <= 31 && !H.has(t) ? Q.remove : -1;
			}
			_applyNCRAction(t, e, n) {
				switch (t) {
					case Q.allow: return String.fromCodePoint(n);
					case Q.remove: return "";
					case Q.leave: return;
					case Q.throw: throw new Error(`[EntityDecoder] Prohibited numeric character reference &${e}; (U+${n.toString(16).toUpperCase().padStart(4, "0")})`);
					default: return String.fromCodePoint(n);
				}
			}
			_resolveNCR(t) {
				const e = t.charCodeAt(1);
				let n;
				if (n = 120 === e || 88 === e ? parseInt(t.slice(2), 16) : parseInt(t.slice(1), 10), Number.isNaN(n) || n < 0 || n > 1114111) return;
				const i = this._classifyNCR(n);
				if (!this._numericAllowed && i < Q.remove) return;
				const s = -1 === i ? this._ncrOnLevel : Math.max(this._ncrOnLevel, i);
				return this._applyNCRAction(s, t, n);
			}
		}
		function et(t, e) {
			if (!t) return {};
			const n = e.attributesGroupName ? t[e.attributesGroupName] : t;
			if (!n) return {};
			const i = {};
			for (const t in n) t.startsWith(e.attributeNamePrefix) ? i[t.substring(e.attributeNamePrefix.length)] = n[t] : i[t] = n[t];
			return i;
		}
		function nt(t) {
			if (!t || "string" != typeof t) return;
			const e = t.indexOf(":");
			if (-1 !== e && e > 0) {
				const n = t.substring(0, e);
				if ("xmlns" !== n) return n;
			}
		}
		class it {
			constructor(t, e) {
				var n;
				this.options = t, this.currentNode = null, this.tagsNodeStack = [], this.parseXml = ht, this.parseTextData = st, this.resolveNameSpace = rt, this.buildAttributesMap = at, this.isItStopNode = ct, this.replaceEntitiesValue = ut, this.readStopNodeData = mt, this.saveTextToParentTag = pt, this.addChild = lt, this.ignoreAttributesFn = "function" == typeof (n = this.options.ignoreAttributes) ? n : Array.isArray(n) ? (t) => {
					for (const e of n) {
						if ("string" == typeof e && t === e) return !0;
						if (e instanceof RegExp && e.test(t)) return !0;
					}
				} : () => !1, this.entityExpansionCount = 0, this.currentExpandedLength = 0;
				let i = { ...W };
				this.options.entityDecoder ? this.entityDecoder = this.options.entityDecoder : ("object" == typeof this.options.htmlEntities ? i = this.options.htmlEntities : !0 === this.options.htmlEntities && (i = {
					...X,
					...U
				}), this.entityDecoder = new tt({
					namedEntities: {
						...i,
						...e
					},
					numericAllowed: this.options.htmlEntities,
					limit: {
						maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
						maxExpandedLength: this.options.processEntities.maxExpandedLength,
						applyLimitsTo: this.options.processEntities.appliesTo
					}
				})), this.matcher = new R(), this.readonlyMatcher = this.matcher.readOnly(), this.isCurrentNodeStopNode = !1, this.stopNodeExpressionsSet = new B();
				const s = this.options.stopNodes;
				if (s && s.length > 0) {
					for (let t = 0; t < s.length; t++) {
						const e = s[t];
						"string" == typeof e ? this.stopNodeExpressionsSet.add(new G(e)) : e instanceof G && this.stopNodeExpressionsSet.add(e);
					}
					this.stopNodeExpressionsSet.seal();
				}
			}
		}
		function st(t, e, n, i, s, r, o) {
			const a = this.options;
			if (void 0 !== t && (a.trimValues && !i && (t = t.trim()), t.length > 0)) {
				o || (t = this.replaceEntitiesValue(t, e, n));
				const i = a.jPath ? n.toString() : n, h = a.tagValueProcessor(e, t, i, s, r);
				return null == h ? t : typeof h != typeof t || h !== t ? h : a.trimValues || t.trim() === t ? xt(t, a.parseTagValue, a.numberParseOptions) : t;
			}
		}
		function rt(t) {
			if (this.options.removeNSPrefix) {
				const e = t.split(":"), n = "/" === t.charAt(0) ? "/" : "";
				if ("xmlns" === e[0]) return "";
				2 === e.length && (t = n + e[1]);
			}
			return t;
		}
		const ot = /* @__PURE__ */ new RegExp("([^\\s=]+)\\s*(=\\s*(['\"])([\\s\\S]*?)\\3)?", "gm");
		function at(t, e, n, i = !1) {
			const r = this.options;
			if (!0 === i || !0 !== r.ignoreAttributes && "string" == typeof t) {
				const i = s(t, ot), o = i.length, a = {}, h = new Array(o);
				let l = !1;
				const u = {};
				for (let t = 0; t < o; t++) {
					const e = this.resolveNameSpace(i[t][1]), s = i[t][4];
					if (e.length && void 0 !== s) {
						let i = s;
						r.trimValues && (i = i.trim()), i = this.replaceEntitiesValue(i, n, this.readonlyMatcher), h[t] = i, u[e] = i, l = !0;
					}
				}
				l && "object" == typeof e && e.updateCurrent && e.updateCurrent(u);
				const p = r.jPath ? e.toString() : this.readonlyMatcher;
				let c = !1;
				for (let t = 0; t < o; t++) {
					const e = this.resolveNameSpace(i[t][1]);
					if (this.ignoreAttributesFn(e, p)) continue;
					let n = r.attributeNamePrefix + e;
					if (e.length) if (r.transformAttributeName && (n = r.transformAttributeName(n)), n = bt(n, r), void 0 !== i[t][4]) {
						const i = h[t], s = r.attributeValueProcessor(e, i, p);
						a[n] = null == s ? i : typeof s != typeof i || s !== i ? s : xt(i, r.parseAttributeValue, r.numberParseOptions), c = !0;
					} else r.allowBooleanAttributes && (a[n] = !0, c = !0);
				}
				if (!c) return;
				if (r.attributesGroupName && !r.preserveOrder) {
					const t = {};
					return t[r.attributesGroupName] = a, t;
				}
				return a;
			}
		}
		const ht = function(t) {
			t = t.replace(/\r\n?/g, "\n");
			const e = new O("!xml");
			let n = e, i = "";
			this.matcher.reset(), this.entityDecoder.reset(), this.entityExpansionCount = 0, this.currentExpandedLength = 0;
			const s = this.options, r = new $(s.processEntities), o = t.length;
			for (let a = 0; a < o; a++) if ("<" === t[a]) {
				const h = t.charCodeAt(a + 1);
				if (47 === h) {
					const e = dt(t, ">", a, "Closing Tag is not closed.");
					let r = t.substring(a + 2, e).trim();
					if (s.removeNSPrefix) {
						const t = r.indexOf(":");
						-1 !== t && (r = r.substr(t + 1));
					}
					r = Nt(s.transformTagName, r, "", s).tagName, n && (i = this.saveTextToParentTag(i, n, this.readonlyMatcher));
					const o = this.matcher.getCurrentTag();
					if (r && s.unpairedTagsSet.has(r)) throw new Error(`Unpaired tag can not be used as closing tag: </${r}>`);
					o && s.unpairedTagsSet.has(o) && (this.matcher.pop(), this.tagsNodeStack.pop()), this.matcher.pop(), this.isCurrentNodeStopNode = !1, n = this.tagsNodeStack.pop(), i = "", a = e;
				} else if (63 === h) {
					let e = gt(t, a, !1, "?>");
					if (!e) throw new Error("Pi Tag is not closed.");
					i = this.saveTextToParentTag(i, n, this.readonlyMatcher);
					const r = this.buildAttributesMap(e.tagExp, this.matcher, e.tagName, !0);
					if (r) {
						const t = r[this.options.attributeNamePrefix + "version"];
						this.entityDecoder.setXmlVersion(Number(t) || 1);
					}
					if (s.ignoreDeclaration && "?xml" === e.tagName || s.ignorePiTags);
					else {
						const t = new O(e.tagName);
						t.add(s.textNodeName, ""), e.tagName !== e.tagExp && e.attrExpPresent && !0 !== s.ignoreAttributes && (t[":@"] = r), this.addChild(n, t, this.readonlyMatcher, a);
					}
					a = e.closeIndex + 1;
				} else if (33 === h && 45 === t.charCodeAt(a + 2) && 45 === t.charCodeAt(a + 3)) {
					const e = dt(t, "-->", a + 4, "Comment is not closed.");
					if (s.commentPropName) {
						const r = t.substring(a + 4, e - 2);
						i = this.saveTextToParentTag(i, n, this.readonlyMatcher), n.add(s.commentPropName, [{ [s.textNodeName]: r }]);
					}
					a = e;
				} else if (33 === h && 68 === t.charCodeAt(a + 2)) {
					const e = r.readDocType(t, a);
					this.entityDecoder.addInputEntities(e.entities), a = e.i;
				} else if (33 === h && 91 === t.charCodeAt(a + 2)) {
					const e = dt(t, "]]>", a, "CDATA is not closed.") - 2, r = t.substring(a + 9, e);
					i = this.saveTextToParentTag(i, n, this.readonlyMatcher);
					let o = this.parseTextData(r, n.tagname, this.readonlyMatcher, !0, !1, !0, !0);
					o ??= "", s.cdataPropName ? n.add(s.cdataPropName, [{ [s.textNodeName]: r }]) : n.add(s.textNodeName, o), a = e + 2;
				} else {
					let r = gt(t, a, s.removeNSPrefix);
					if (!r) {
						const e = t.substring(Math.max(0, a - 50), Math.min(o, a + 50));
						throw new Error(`readTagExp returned undefined at position ${a}. Context: "${e}"`);
					}
					let h = r.tagName;
					const l = r.rawTagName;
					let u = r.tagExp, p = r.attrExpPresent, c = r.closeIndex;
					if ({tagName: h, tagExp: u} = Nt(s.transformTagName, h, u, s), s.strictReservedNames && (h === s.commentPropName || h === s.cdataPropName || h === s.textNodeName || h === s.attributesGroupName)) throw new Error(`Invalid tag name: ${h}`);
					n && i && "!xml" !== n.tagname && (i = this.saveTextToParentTag(i, n, this.readonlyMatcher, !1));
					const d = n;
					d && s.unpairedTagsSet.has(d.tagname) && (n = this.tagsNodeStack.pop(), this.matcher.pop());
					let f = !1;
					u.length > 0 && u.lastIndexOf("/") === u.length - 1 && (f = !0, "/" === h[h.length - 1] ? (h = h.substr(0, h.length - 1), u = h) : u = u.substr(0, u.length - 1), p = h !== u);
					let g, m = null;
					g = nt(l), h !== e.tagname && this.matcher.push(h, {}, g), h !== u && p && (m = this.buildAttributesMap(u, this.matcher, h), m && et(m, s)), h !== e.tagname && (this.isCurrentNodeStopNode = this.isItStopNode());
					const N = a;
					if (this.isCurrentNodeStopNode) {
						let e = "";
						if (f) a = r.closeIndex;
						else if (s.unpairedTagsSet.has(h)) a = r.closeIndex;
						else {
							const n = this.readStopNodeData(t, l, c + 1);
							if (!n) throw new Error(`Unexpected end of ${l}`);
							a = n.i, e = n.tagContent;
						}
						const i = new O(h);
						m && (i[":@"] = m), i.add(s.textNodeName, e), this.matcher.pop(), this.isCurrentNodeStopNode = !1, this.addChild(n, i, this.readonlyMatcher, N);
					} else {
						if (f) {
							({tagName: h, tagExp: u} = Nt(s.transformTagName, h, u, s));
							const t = new O(h);
							m && (t[":@"] = m), this.addChild(n, t, this.readonlyMatcher, N), this.matcher.pop(), this.isCurrentNodeStopNode = !1;
						} else {
							if (s.unpairedTagsSet.has(h)) {
								const t = new O(h);
								m && (t[":@"] = m), this.addChild(n, t, this.readonlyMatcher, N), this.matcher.pop(), this.isCurrentNodeStopNode = !1, a = r.closeIndex;
								continue;
							}
							{
								const t = new O(h);
								if (this.tagsNodeStack.length > s.maxNestedTags) throw new Error("Maximum nested tags exceeded");
								this.tagsNodeStack.push(n), m && (t[":@"] = m), this.addChild(n, t, this.readonlyMatcher, N), n = t;
							}
						}
						i = "", a = c;
					}
				}
			} else i += t[a];
			return e.child;
		};
		function lt(t, e, n, i) {
			this.options.captureMetaData || (i = void 0);
			const s = this.options.jPath ? n.toString() : n, r = this.options.updateTag(e.tagname, s, e[":@"]);
			!1 === r || ("string" == typeof r ? (e.tagname = r, t.addChild(e, i)) : t.addChild(e, i));
		}
		function ut(t, e, n) {
			const i = this.options.processEntities;
			if (!i || !i.enabled) return t;
			if (i.allowedTags) {
				const s = this.options.jPath ? n.toString() : n;
				if (!(Array.isArray(i.allowedTags) ? i.allowedTags.includes(e) : i.allowedTags(e, s))) return t;
			}
			if (i.tagFilter) {
				const s = this.options.jPath ? n.toString() : n;
				if (!i.tagFilter(e, s)) return t;
			}
			return this.entityDecoder.decode(t);
		}
		function pt(t, e, n, i) {
			return t && (void 0 === i && (i = 0 === e.child.length), void 0 !== (t = this.parseTextData(t, e.tagname, n, !1, !!e[":@"] && 0 !== Object.keys(e[":@"]).length, i)) && "" !== t && e.add(this.options.textNodeName, t), t = ""), t;
		}
		function ct() {
			return 0 !== this.stopNodeExpressionsSet.size && this.matcher.matchesAny(this.stopNodeExpressionsSet);
		}
		function dt(t, e, n, i) {
			const s = t.indexOf(e, n);
			if (-1 === s) throw new Error(i);
			return s + e.length - 1;
		}
		function ft(t, e, n, i) {
			const s = t.indexOf(e, n);
			if (-1 === s) throw new Error(i);
			return s;
		}
		function gt(t, e, n, i = ">") {
			const s = function(t, e, n = ">") {
				let i = 0;
				const s = t.length, r = n.charCodeAt(0), o = n.length > 1 ? n.charCodeAt(1) : -1;
				let a = "", h = e;
				for (let n = e; n < s; n++) {
					const e = t.charCodeAt(n);
					if (i) e === i && (i = 0);
					else if (34 === e || 39 === e) i = e;
					else if (e === r) {
						if (-1 === o) return a += t.substring(h, n), {
							data: a,
							index: n
						};
						if (t.charCodeAt(n + 1) === o) return a += t.substring(h, n), {
							data: a,
							index: n
						};
					} else 9 !== e || i || (a += t.substring(h, n) + " ", h = n + 1);
				}
			}(t, e + 1, i);
			if (!s) return;
			let r = s.data;
			const o = s.index, a = r.search(/\s/);
			let h = r, l = !0;
			-1 !== a && (h = r.substring(0, a), r = r.substring(a + 1).trimStart());
			const u = h;
			if (n) {
				const t = h.indexOf(":");
				-1 !== t && (h = h.substr(t + 1), l = h !== s.data.substr(t + 1));
			}
			return {
				tagName: h,
				tagExp: r,
				closeIndex: o,
				attrExpPresent: l,
				rawTagName: u
			};
		}
		function mt(t, e, n) {
			const i = n;
			let s = 1;
			const r = t.length;
			for (; n < r; n++) if ("<" === t[n]) {
				const r = t.charCodeAt(n + 1);
				if (47 === r) {
					const r = ft(t, ">", n, `${e} is not closed`);
					if (t.substring(n + 2, r).trim() === e && (s--, 0 === s)) return {
						tagContent: t.substring(i, n),
						i: r
					};
					n = r;
				} else if (63 === r) n = dt(t, "?>", n + 1, "StopNode is not closed.");
				else if (33 === r && 45 === t.charCodeAt(n + 2) && 45 === t.charCodeAt(n + 3)) n = dt(t, "-->", n + 3, "StopNode is not closed.");
				else if (33 === r && 91 === t.charCodeAt(n + 2)) n = dt(t, "]]>", n, "StopNode is not closed.") - 2;
				else {
					const i = gt(t, n, ">");
					i && ((i && i.tagName) === e && "/" !== i.tagExp[i.tagExp.length - 1] && s++, n = i.closeIndex);
				}
			}
		}
		function xt(t, e, n) {
			if (e && "string" == typeof t) {
				const e = t.trim();
				return "true" === e || "false" !== e && function(t, e = {}) {
					if (e = Object.assign({}, L, e), !t || "string" != typeof t) return t;
					let n = t.trim();
					if (0 === n.length) return t;
					if (void 0 !== e.skipLike && e.skipLike.test(n)) return t;
					if ("0" === n) return 0;
					if (e.hex && j.test(n)) return function(t) {
						if (parseInt) return parseInt(t, 16);
						if (Number.parseInt) return Number.parseInt(t, 16);
						if (window && window.parseInt) return window.parseInt(t, 16);
						throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
					}(n);
					if (isFinite(n)) {
						if (n.includes("e") || n.includes("E")) return function(t, e, n) {
							if (!n.eNotation) return t;
							const i = e.match(k);
							if (i) {
								let s = i[1] || "";
								const r = -1 === i[3].indexOf("e") ? "E" : "e", o = i[2], a = s ? t[o.length + 1] === r : t[o.length] === r;
								return o.length > 1 && a ? t : (1 !== o.length || !i[3].startsWith(`.${r}`) && i[3][0] !== r) && o.length > 0 ? n.leadingZeros && !a ? (e = (i[1] || "") + i[3], Number(e)) : t : Number(e);
							}
							return t;
						}(t, n, e);
						{
							const s = V.exec(n);
							if (s) {
								const r = s[1] || "", o = s[2];
								let a = (i = s[3]) && -1 !== i.indexOf(".") ? ("." === (i = i.replace(/0+$/, "")) ? i = "0" : "." === i[0] ? i = "0" + i : "." === i[i.length - 1] && (i = i.substring(0, i.length - 1)), i) : i;
								const h = r ? "." === t[o.length + 1] : "." === t[o.length];
								if (!e.leadingZeros && (o.length > 1 || 1 === o.length && !h)) return t;
								{
									const i = Number(n), s = String(i);
									if (0 === i) return i;
									if (-1 !== s.search(/[eE]/)) return e.eNotation ? i : t;
									if (-1 !== n.indexOf(".")) return "0" === s || s === a || s === `${r}${a}` ? i : t;
									let h = o ? a : n;
									return o ? h === s || r + h === s ? i : t : h === s || h === r + s ? i : t;
								}
							}
							return t;
						}
					}
					var i;
					return function(t, e, n) {
						const i = e === Infinity;
						switch (n.infinity.toLowerCase()) {
							case "null": return null;
							case "infinity": return e;
							case "string": return i ? "Infinity" : "-Infinity";
							default: return t;
						}
					}(t, Number(n), e);
				}(t, n);
			}
			return void 0 !== t ? t : "";
		}
		function Nt(t, e, n, i) {
			if (t) {
				const i = t(e);
				n === e && (n = i), e = i;
			}
			return {
				tagName: e = bt(e, i),
				tagExp: n
			};
		}
		function bt(t, e) {
			if (a.includes(t)) throw new Error(`[SECURITY] Invalid name: "${t}" is a reserved JavaScript keyword that could cause prototype pollution`);
			return o.includes(t) ? e.onDangerousProperty(t) : t;
		}
		const yt = O.getMetaDataSymbol();
		function Et(t, e) {
			if (!t || "object" != typeof t) return {};
			if (!e) return t;
			const n = {};
			for (const i in t) i.startsWith(e) ? n[i.substring(e.length)] = t[i] : n[i] = t[i];
			return n;
		}
		function wt(t, e, n, i) {
			return vt(t, e, n, i);
		}
		function vt(t, e, n, i) {
			let s;
			const r = {};
			for (let o = 0; o < t.length; o++) {
				const a = t[o], h = St(a);
				if (void 0 !== h && h !== e.textNodeName) {
					const t = Et(a[":@"] || {}, e.attributeNamePrefix);
					n.push(h, t);
				}
				if (h === e.textNodeName) void 0 === s ? s = a[h] : s += "" + a[h];
				else {
					if (void 0 === h) continue;
					if (a[h]) {
						let t = vt(a[h], e, n, i);
						const s = At(t, e);
						if (a[":@"] ? _t(t, a[":@"], i, e) : 1 !== Object.keys(t).length || void 0 === t[e.textNodeName] || e.alwaysCreateTextNode ? 0 === Object.keys(t).length && (e.alwaysCreateTextNode ? t[e.textNodeName] = "" : t = "") : t = t[e.textNodeName], void 0 !== a[yt] && "object" == typeof t && null !== t && (t[yt] = a[yt]), void 0 !== r[h] && Object.prototype.hasOwnProperty.call(r, h)) Array.isArray(r[h]) || (r[h] = [r[h]]), r[h].push(t);
						else {
							const n = e.jPath ? i.toString() : i;
							e.isArray(h, n, s) ? r[h] = [t] : r[h] = t;
						}
						void 0 !== h && h !== e.textNodeName && n.pop();
					}
				}
			}
			return "string" == typeof s ? s.length > 0 && (r[e.textNodeName] = s) : void 0 !== s && (r[e.textNodeName] = s), r;
		}
		function St(t) {
			const e = Object.keys(t);
			for (let t = 0; t < e.length; t++) {
				const n = e[t];
				if (":@" !== n) return n;
			}
		}
		function _t(t, e, n, i) {
			if (e) {
				const s = Object.keys(e), r = s.length;
				for (let o = 0; o < r; o++) {
					const r = s[o], a = r.startsWith(i.attributeNamePrefix) ? r.substring(i.attributeNamePrefix.length) : r, h = i.jPath ? n.toString() + "." + a : n;
					i.isArray(r, h, !0, !0) ? t[r] = [e[r]] : t[r] = e[r];
				}
			}
		}
		function At(t, e) {
			const { textNodeName: n } = e, i = Object.keys(t).length;
			return 0 === i || !(1 !== i || !t[n] && "boolean" != typeof t[n] && 0 !== t[n]);
		}
		class Tt {
			constructor(t) {
				this.externalEntities = {}, this.options = C(t);
			}
			parse(t, e) {
				if ("string" != typeof t && t.toString) t = t.toString();
				else if ("string" != typeof t) throw new Error("XML data is accepted in String or Bytes[] form.");
				if (e) {
					!0 === e && (e = {});
					const n = l(t, e);
					if (!0 !== n) throw Error(`${n.err.msg}:${n.err.line}:${n.err.col}`);
				}
				const n = new it(this.options, this.externalEntities), i = n.parseXml(t);
				return this.options.preserveOrder || void 0 === i ? i : wt(i, this.options, n.matcher, n.readonlyMatcher);
			}
			addEntity(t, e) {
				if (-1 !== e.indexOf("&")) throw new Error("Entity value can't have '&'");
				if (-1 !== t.indexOf("&") || -1 !== t.indexOf(";")) throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
				if ("&" === e) throw new Error("An entity with value '&' is not permitted");
				this.externalEntities[t] = e;
			}
			static getMetaDataSymbol() {
				return O.getMetaDataSymbol();
			}
		}
		function Ct(t, e) {
			let n = "";
			e.format && e.indentBy.length > 0 && (n = "\n");
			const i = [];
			if (e.stopNodes && Array.isArray(e.stopNodes)) for (let t = 0; t < e.stopNodes.length; t++) {
				const n = e.stopNodes[t];
				"string" == typeof n ? i.push(new G(n)) : n instanceof G && i.push(n);
			}
			return Pt(t, e, n, new R(), i);
		}
		function Pt(t, e, n, i, s) {
			let r = "", o = !1;
			if (e.maxNestedTags && i.getDepth() > e.maxNestedTags) throw new Error("Maximum nested tags exceeded");
			if (!Array.isArray(t)) {
				if (null != t) {
					let n = t.toString();
					return n = Vt(n, e), n;
				}
				return "";
			}
			for (let a = 0; a < t.length; a++) {
				const h = t[a], l = Dt(h);
				if (void 0 === l) continue;
				const u = Ot(h[":@"], e);
				i.push(l, u);
				const p = jt(i, s);
				if (l === e.textNodeName) {
					let t = h[l];
					p || (t = e.tagValueProcessor(l, t), t = Vt(t, e)), o && (r += n), r += t, o = !1, i.pop();
					continue;
				}
				if (l === e.cdataPropName) {
					o && (r += n);
					const t = h[l][0][e.textNodeName];
					r += `<![CDATA[${String(t).replace(/\]\]>/g, "]]]]><![CDATA[>")}]]>`, o = !1, i.pop();
					continue;
				}
				if (l === e.commentPropName) {
					const t = h[l][0][e.textNodeName];
					r += n + `\x3c!--${String(t).replace(/--/g, "- -").replace(/-$/, "- ")}--\x3e`, o = !0, i.pop();
					continue;
				}
				if ("?" === l[0]) {
					const t = Mt(h[":@"], e, p), s = "?xml" === l ? "" : n;
					let a = h[l][0][e.textNodeName];
					a = 0 !== a.length ? " " + a : "", r += s + `<${l}${a}${t}?>`, o = !0, i.pop();
					continue;
				}
				let c = n;
				"" !== c && (c += e.indentBy);
				const d = n + `<${l}${Mt(h[":@"], e, p)}`;
				let f;
				f = p ? $t(h[l], e) : Pt(h[l], e, c, i, s), -1 !== e.unpairedTags.indexOf(l) ? e.suppressUnpairedNode ? r += d + ">" : r += d + "/>" : f && 0 !== f.length || !e.suppressEmptyNode ? f && f.endsWith(">") ? r += d + `>${f}${n}</${l}>` : (r += d + ">", f && "" !== n && (f.includes("/>") || f.includes("</")) ? r += n + e.indentBy + f + n : r += f, r += `</${l}>`) : r += d + "/>", o = !0, i.pop();
			}
			return r;
		}
		function Ot(t, e) {
			if (!t || e.ignoreAttributes) return null;
			const n = {};
			let i = !1;
			for (let s in t) Object.prototype.hasOwnProperty.call(t, s) && (n[s.startsWith(e.attributeNamePrefix) ? s.substr(e.attributeNamePrefix.length) : s] = t[s], i = !0);
			return i ? n : null;
		}
		function $t(t, e) {
			if (!Array.isArray(t)) return null != t ? t.toString() : "";
			let n = "";
			for (let i = 0; i < t.length; i++) {
				const s = t[i], r = Dt(s);
				if (r === e.textNodeName) n += s[r];
				else if (r === e.cdataPropName) n += s[r][0][e.textNodeName];
				else if (r === e.commentPropName) n += s[r][0][e.textNodeName];
				else {
					if (r && "?" === r[0]) continue;
					if (r) {
						const t = It(s[":@"], e), i = $t(s[r], e);
						i && 0 !== i.length ? n += `<${r}${t}>${i}</${r}>` : n += `<${r}${t}/>`;
					}
				}
			}
			return n;
		}
		function It(t, e) {
			let n = "";
			if (t && !e.ignoreAttributes) for (let i in t) {
				if (!Object.prototype.hasOwnProperty.call(t, i)) continue;
				let s = t[i];
				!0 === s && e.suppressBooleanAttributes ? n += ` ${i.substr(e.attributeNamePrefix.length)}` : n += ` ${i.substr(e.attributeNamePrefix.length)}="${s}"`;
			}
			return n;
		}
		function Dt(t) {
			const e = Object.keys(t);
			for (let n = 0; n < e.length; n++) {
				const i = e[n];
				if (Object.prototype.hasOwnProperty.call(t, i) && ":@" !== i) return i;
			}
		}
		function Mt(t, e, n) {
			let i = "";
			if (t && !e.ignoreAttributes) for (let s in t) {
				if (!Object.prototype.hasOwnProperty.call(t, s)) continue;
				let r;
				n ? r = t[s] : (r = e.attributeValueProcessor(s, t[s]), r = Vt(r, e)), !0 === r && e.suppressBooleanAttributes ? i += ` ${s.substr(e.attributeNamePrefix.length)}` : i += ` ${s.substr(e.attributeNamePrefix.length)}="${r}"`;
			}
			return i;
		}
		function jt(t, e) {
			if (!e || 0 === e.length) return !1;
			for (let n = 0; n < e.length; n++) if (t.matches(e[n])) return !0;
			return !1;
		}
		function Vt(t, e) {
			if (t && t.length > 0 && e.processEntities) for (let n = 0; n < e.entities.length; n++) {
				const i = e.entities[n];
				t = t.replace(i.regex, i.val);
			}
			return t;
		}
		const Lt = {
			attributeNamePrefix: "@_",
			attributesGroupName: !1,
			textNodeName: "#text",
			ignoreAttributes: !0,
			cdataPropName: !1,
			format: !1,
			indentBy: "  ",
			suppressEmptyNode: !1,
			suppressUnpairedNode: !0,
			suppressBooleanAttributes: !0,
			tagValueProcessor: function(t, e) {
				return e;
			},
			attributeValueProcessor: function(t, e) {
				return e;
			},
			preserveOrder: !1,
			commentPropName: !1,
			unpairedTags: [],
			entities: [
				{
					regex: /* @__PURE__ */ new RegExp("&", "g"),
					val: "&amp;"
				},
				{
					regex: /* @__PURE__ */ new RegExp(">", "g"),
					val: "&gt;"
				},
				{
					regex: /* @__PURE__ */ new RegExp("<", "g"),
					val: "&lt;"
				},
				{
					regex: /* @__PURE__ */ new RegExp("'", "g"),
					val: "&apos;"
				},
				{
					regex: /* @__PURE__ */ new RegExp("\"", "g"),
					val: "&quot;"
				}
			],
			processEntities: !0,
			stopNodes: [],
			oneListGroup: !1,
			maxNestedTags: 100,
			jPath: !0
		};
		function kt(t) {
			if (this.options = Object.assign({}, Lt, t), this.options.stopNodes && Array.isArray(this.options.stopNodes) && (this.options.stopNodes = this.options.stopNodes.map((t) => "string" == typeof t && t.startsWith("*.") ? ".." + t.substring(2) : t)), this.stopNodeExpressions = [], this.options.stopNodes && Array.isArray(this.options.stopNodes)) for (let t = 0; t < this.options.stopNodes.length; t++) {
				const e = this.options.stopNodes[t];
				"string" == typeof e ? this.stopNodeExpressions.push(new G(e)) : e instanceof G && this.stopNodeExpressions.push(e);
			}
			var e;
			!0 === this.options.ignoreAttributes || this.options.attributesGroupName ? this.isAttribute = function() {
				return !1;
			} : (this.ignoreAttributesFn = "function" == typeof (e = this.options.ignoreAttributes) ? e : Array.isArray(e) ? (t) => {
				for (const n of e) {
					if ("string" == typeof n && t === n) return !0;
					if (n instanceof RegExp && n.test(t)) return !0;
				}
			} : () => !1, this.attrPrefixLen = this.options.attributeNamePrefix.length, this.isAttribute = Gt), this.processTextOrObjNode = Ft, this.options.format ? (this.indentate = Rt, this.tagEndChar = ">\n", this.newLine = "\n") : (this.indentate = function() {
				return "";
			}, this.tagEndChar = ">", this.newLine = "");
		}
		function Ft(t, e, n, i) {
			const s = this.extractAttributes(t);
			if (i.push(e, s), this.checkStopNode(i)) {
				const s = this.buildRawContent(t), r = this.buildAttributesForStopNode(t);
				return i.pop(), this.buildObjectNode(s, e, r, n);
			}
			const r = this.j2x(t, n + 1, i);
			return i.pop(), void 0 !== t[this.options.textNodeName] && 1 === Object.keys(t).length ? this.buildTextValNode(t[this.options.textNodeName], e, r.attrStr, n, i) : this.buildObjectNode(r.val, e, r.attrStr, n);
		}
		function Rt(t) {
			return this.options.indentBy.repeat(t);
		}
		function Gt(t) {
			return !(!t.startsWith(this.options.attributeNamePrefix) || t === this.options.textNodeName) && t.substr(this.attrPrefixLen);
		}
		kt.prototype.build = function(t) {
			if (this.options.preserveOrder) return Ct(t, this.options);
			{
				Array.isArray(t) && this.options.arrayNodeName && this.options.arrayNodeName.length > 1 && (t = { [this.options.arrayNodeName]: t });
				const e = new R();
				return this.j2x(t, 0, e).val;
			}
		}, kt.prototype.j2x = function(t, e, n) {
			let i = "", s = "";
			if (this.options.maxNestedTags && n.getDepth() >= this.options.maxNestedTags) throw new Error("Maximum nested tags exceeded");
			const r = this.options.jPath ? n.toString() : n, o = this.checkStopNode(n);
			for (let a in t) if (Object.prototype.hasOwnProperty.call(t, a)) if (void 0 === t[a]) this.isAttribute(a) && (s += "");
			else if (null === t[a]) this.isAttribute(a) || a === this.options.cdataPropName ? s += "" : "?" === a[0] ? s += this.indentate(e) + "<" + a + "?" + this.tagEndChar : s += this.indentate(e) + "<" + a + "/" + this.tagEndChar;
			else if (t[a] instanceof Date) s += this.buildTextValNode(t[a], a, "", e, n);
			else if ("object" != typeof t[a]) {
				const h = this.isAttribute(a);
				if (h && !this.ignoreAttributesFn(h, r)) i += this.buildAttrPairStr(h, "" + t[a], o);
				else if (!h) if (a === this.options.textNodeName) {
					let e = this.options.tagValueProcessor(a, "" + t[a]);
					s += this.replaceEntitiesValue(e);
				} else {
					n.push(a);
					const i = this.checkStopNode(n);
					if (n.pop(), i) {
						const n = "" + t[a];
						s += "" === n ? this.indentate(e) + "<" + a + this.closeTag(a) + this.tagEndChar : this.indentate(e) + "<" + a + ">" + n + "</" + a + this.tagEndChar;
					} else s += this.buildTextValNode(t[a], a, "", e, n);
				}
			} else if (Array.isArray(t[a])) {
				const i = t[a].length;
				let r = "", o = "";
				for (let h = 0; h < i; h++) {
					const i = t[a][h];
					if (void 0 === i);
					else if (null === i) "?" === a[0] ? s += this.indentate(e) + "<" + a + "?" + this.tagEndChar : s += this.indentate(e) + "<" + a + "/" + this.tagEndChar;
					else if ("object" == typeof i) if (this.options.oneListGroup) {
						n.push(a);
						const t = this.j2x(i, e + 1, n);
						n.pop(), r += t.val, this.options.attributesGroupName && i.hasOwnProperty(this.options.attributesGroupName) && (o += t.attrStr);
					} else r += this.processTextOrObjNode(i, a, e, n);
					else if (this.options.oneListGroup) {
						let t = this.options.tagValueProcessor(a, i);
						t = this.replaceEntitiesValue(t), r += t;
					} else {
						n.push(a);
						const t = this.checkStopNode(n);
						if (n.pop(), t) {
							const t = "" + i;
							r += "" === t ? this.indentate(e) + "<" + a + this.closeTag(a) + this.tagEndChar : this.indentate(e) + "<" + a + ">" + t + "</" + a + this.tagEndChar;
						} else r += this.buildTextValNode(i, a, "", e, n);
					}
				}
				this.options.oneListGroup && (r = this.buildObjectNode(r, a, o, e)), s += r;
			} else if (this.options.attributesGroupName && a === this.options.attributesGroupName) {
				const e = Object.keys(t[a]), n = e.length;
				for (let s = 0; s < n; s++) i += this.buildAttrPairStr(e[s], "" + t[a][e[s]], o);
			} else s += this.processTextOrObjNode(t[a], a, e, n);
			return {
				attrStr: i,
				val: s
			};
		}, kt.prototype.buildAttrPairStr = function(t, e, n) {
			return n || (e = this.options.attributeValueProcessor(t, "" + e), e = this.replaceEntitiesValue(e)), this.options.suppressBooleanAttributes && "true" === e ? " " + t : " " + t + "=\"" + e + "\"";
		}, kt.prototype.extractAttributes = function(t) {
			if (!t || "object" != typeof t) return null;
			const e = {};
			let n = !1;
			if (this.options.attributesGroupName && t[this.options.attributesGroupName]) {
				const i = t[this.options.attributesGroupName];
				for (let t in i) Object.prototype.hasOwnProperty.call(i, t) && (e[t.startsWith(this.options.attributeNamePrefix) ? t.substring(this.options.attributeNamePrefix.length) : t] = i[t], n = !0);
			} else for (let i in t) {
				if (!Object.prototype.hasOwnProperty.call(t, i)) continue;
				const s = this.isAttribute(i);
				s && (e[s] = t[i], n = !0);
			}
			return n ? e : null;
		}, kt.prototype.buildRawContent = function(t) {
			if ("string" == typeof t) return t;
			if ("object" != typeof t || null === t) return String(t);
			if (void 0 !== t[this.options.textNodeName]) return t[this.options.textNodeName];
			let e = "";
			for (let n in t) {
				if (!Object.prototype.hasOwnProperty.call(t, n)) continue;
				if (this.isAttribute(n)) continue;
				if (this.options.attributesGroupName && n === this.options.attributesGroupName) continue;
				const i = t[n];
				if (n === this.options.textNodeName) e += i;
				else if (Array.isArray(i)) {
					for (let t of i) if ("string" == typeof t || "number" == typeof t) e += `<${n}>${t}</${n}>`;
					else if ("object" == typeof t && null !== t) {
						const i = this.buildRawContent(t), s = this.buildAttributesForStopNode(t);
						e += "" === i ? `<${n}${s}/>` : `<${n}${s}>${i}</${n}>`;
					}
				} else if ("object" == typeof i && null !== i) {
					const t = this.buildRawContent(i), s = this.buildAttributesForStopNode(i);
					e += "" === t ? `<${n}${s}/>` : `<${n}${s}>${t}</${n}>`;
				} else e += `<${n}>${i}</${n}>`;
			}
			return e;
		}, kt.prototype.buildAttributesForStopNode = function(t) {
			if (!t || "object" != typeof t) return "";
			let e = "";
			if (this.options.attributesGroupName && t[this.options.attributesGroupName]) {
				const n = t[this.options.attributesGroupName];
				for (let t in n) {
					if (!Object.prototype.hasOwnProperty.call(n, t)) continue;
					const i = t.startsWith(this.options.attributeNamePrefix) ? t.substring(this.options.attributeNamePrefix.length) : t, s = n[t];
					!0 === s && this.options.suppressBooleanAttributes ? e += " " + i : e += " " + i + "=\"" + s + "\"";
				}
			} else for (let n in t) {
				if (!Object.prototype.hasOwnProperty.call(t, n)) continue;
				const i = this.isAttribute(n);
				if (i) {
					const s = t[n];
					!0 === s && this.options.suppressBooleanAttributes ? e += " " + i : e += " " + i + "=\"" + s + "\"";
				}
			}
			return e;
		}, kt.prototype.buildObjectNode = function(t, e, n, i) {
			if ("" === t) return "?" === e[0] ? this.indentate(i) + "<" + e + n + "?" + this.tagEndChar : this.indentate(i) + "<" + e + n + this.closeTag(e) + this.tagEndChar;
			{
				let s = "</" + e + this.tagEndChar, r = "";
				return "?" === e[0] && (r = "?", s = ""), !n && "" !== n || -1 !== t.indexOf("<") ? !1 !== this.options.commentPropName && e === this.options.commentPropName && 0 === r.length ? this.indentate(i) + `\x3c!--${t}--\x3e` + this.newLine : this.indentate(i) + "<" + e + n + r + this.tagEndChar + t + this.indentate(i) + s : this.indentate(i) + "<" + e + n + r + ">" + t + s;
			}
		}, kt.prototype.closeTag = function(t) {
			let e = "";
			return -1 !== this.options.unpairedTags.indexOf(t) ? this.options.suppressUnpairedNode || (e = "/") : e = this.options.suppressEmptyNode ? "/" : `></${t}`, e;
		}, kt.prototype.checkStopNode = function(t) {
			if (!this.stopNodeExpressions || 0 === this.stopNodeExpressions.length) return !1;
			for (let e = 0; e < this.stopNodeExpressions.length; e++) if (t.matches(this.stopNodeExpressions[e])) return !0;
			return !1;
		}, kt.prototype.buildTextValNode = function(t, e, n, i, s) {
			if (!1 !== this.options.cdataPropName && e === this.options.cdataPropName) {
				const e = String(t).replace(/\]\]>/g, "]]]]><![CDATA[>");
				return this.indentate(i) + `<![CDATA[${e}]]>` + this.newLine;
			}
			if (!1 !== this.options.commentPropName && e === this.options.commentPropName) {
				const e = String(t).replace(/--/g, "- -").replace(/-$/, "- ");
				return this.indentate(i) + `\x3c!--${e}--\x3e` + this.newLine;
			}
			if ("?" === e[0]) return this.indentate(i) + "<" + e + n + "?" + this.tagEndChar;
			{
				let s = this.options.tagValueProcessor(e, t);
				return s = this.replaceEntitiesValue(s), "" === s ? this.indentate(i) + "<" + e + n + this.closeTag(e) + this.tagEndChar : this.indentate(i) + "<" + e + n + ">" + s + "</" + e + this.tagEndChar;
			}
		}, kt.prototype.replaceEntitiesValue = function(t) {
			if (t && t.length > 0 && this.options.processEntities) for (let e = 0; e < this.options.entities.length; e++) {
				const n = this.options.entities[e];
				t = t.replace(n.regex, n.val);
			}
			return t;
		};
		const Bt = kt, Ut = { validate: l };
		module.exports = e;
	})();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+xml-builder@3.972.22/node_modules/@aws-sdk/xml-builder/dist-cjs/xml-external/nodable_entities.js
var require_nodable_entities = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EntityDecoderImpl = exports.CURRENCY = exports.COMMON_HTML = exports.XML = void 0;
	exports.XML = {
		amp: "&",
		apos: "'",
		gt: ">",
		lt: "<",
		quot: "\""
	};
	exports.COMMON_HTML = {
		nbsp: "\xA0",
		copy: "©",
		reg: "®",
		trade: "™",
		mdash: "—",
		ndash: "–",
		hellip: "…",
		laquo: "«",
		raquo: "»",
		lsquo: "‘",
		rsquo: "’",
		ldquo: "“",
		rdquo: "”",
		bull: "•",
		para: "¶",
		sect: "§",
		deg: "°",
		frac12: "½",
		frac14: "¼",
		frac34: "¾"
	};
	exports.CURRENCY = {
		cent: "¢",
		pound: "£",
		curren: "¤",
		yen: "¥",
		euro: "€",
		dollar: "$",
		fnof: "ƒ",
		inr: "₹",
		af: "؋",
		birr: "ብር",
		peso: "₱",
		rub: "₽",
		won: "₩",
		yuan: "¥",
		cedil: "¸"
	};
	const SPECIAL_CHARS = /* @__PURE__ */ new Set("!?\\/[]$%{}^&*()<>|+");
	function validateEntityName(name) {
		if (name[0] === "#") throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${name}"`);
		for (const ch of name) if (SPECIAL_CHARS.has(ch)) throw new Error(`[EntityReplacer] Invalid character '${ch}' in entity name: "${name}"`);
		return name;
	}
	function mergeEntityMaps(...maps) {
		const out = Object.create(null);
		for (const map of maps) {
			if (!map) continue;
			for (const key of Object.keys(map)) {
				const raw = map[key];
				if (typeof raw === "string") out[key] = raw;
				else if (raw && typeof raw === "object" && raw.val !== void 0) {
					const val = raw.val;
					if (typeof val === "string") out[key] = val;
				}
			}
		}
		return out;
	}
	const LIMIT_TIER_EXTERNAL = "external";
	const LIMIT_TIER_BASE = "base";
	const LIMIT_TIER_ALL = "all";
	function parseLimitTiers(raw) {
		if (!raw || raw === LIMIT_TIER_EXTERNAL) return new Set([LIMIT_TIER_EXTERNAL]);
		if (raw === LIMIT_TIER_ALL) return new Set([LIMIT_TIER_ALL]);
		if (raw === LIMIT_TIER_BASE) return new Set([LIMIT_TIER_BASE]);
		if (Array.isArray(raw)) return new Set(raw);
		return new Set([LIMIT_TIER_EXTERNAL]);
	}
	const NCR_LEVEL = Object.freeze({
		allow: 0,
		leave: 1,
		remove: 2,
		throw: 3
	});
	const XML10_ALLOWED_C0 = new Set([
		9,
		10,
		13
	]);
	function parseNCRConfig(ncr) {
		if (!ncr) return {
			xmlVersion: 1,
			onLevel: NCR_LEVEL.allow,
			nullLevel: NCR_LEVEL.remove
		};
		const xmlVersion = ncr.xmlVersion === 1.1 ? 1.1 : 1;
		const onLevel = NCR_LEVEL[ncr.onNCR ?? "allow"] ?? NCR_LEVEL.allow;
		const nullLevel = NCR_LEVEL[ncr.nullNCR ?? "remove"] ?? NCR_LEVEL.remove;
		return {
			xmlVersion,
			onLevel,
			nullLevel: Math.max(nullLevel, NCR_LEVEL.remove)
		};
	}
	exports.EntityDecoderImpl = class EntityDecoderImpl {
		_limit;
		_maxTotalExpansions;
		_maxExpandedLength;
		_postCheck;
		_limitTiers;
		_numericAllowed;
		_baseMap;
		_externalMap;
		_inputMap;
		_totalExpansions;
		_expandedLength;
		_removeSet;
		_leaveSet;
		_ncrXmlVersion;
		_ncrOnLevel;
		_ncrNullLevel;
		constructor(options = {}) {
			this._limit = options.limit || {};
			this._maxTotalExpansions = this._limit.maxTotalExpansions || 0;
			this._maxExpandedLength = this._limit.maxExpandedLength || 0;
			this._postCheck = typeof options.postCheck === "function" ? options.postCheck : (r) => r;
			this._limitTiers = parseLimitTiers(this._limit.applyLimitsTo ?? LIMIT_TIER_EXTERNAL);
			this._numericAllowed = options.numericAllowed ?? true;
			this._baseMap = mergeEntityMaps(exports.XML, options.namedEntities || null);
			this._externalMap = Object.create(null);
			this._inputMap = Object.create(null);
			this._totalExpansions = 0;
			this._expandedLength = 0;
			this._removeSet = new Set(options.remove && Array.isArray(options.remove) ? options.remove : []);
			this._leaveSet = new Set(options.leave && Array.isArray(options.leave) ? options.leave : []);
			const ncrCfg = parseNCRConfig(options.ncr);
			this._ncrXmlVersion = ncrCfg.xmlVersion;
			this._ncrOnLevel = ncrCfg.onLevel;
			this._ncrNullLevel = ncrCfg.nullLevel;
		}
		setExternalEntities(map) {
			if (map) for (const key of Object.keys(map)) validateEntityName(key);
			this._externalMap = mergeEntityMaps(map);
		}
		addExternalEntity(key, value) {
			validateEntityName(key);
			if (typeof value === "string" && value.indexOf("&") === -1) this._externalMap[key] = value;
		}
		addInputEntities(map) {
			this._totalExpansions = 0;
			this._expandedLength = 0;
			this._inputMap = mergeEntityMaps(map);
		}
		reset() {
			this._inputMap = Object.create(null);
			this._totalExpansions = 0;
			this._expandedLength = 0;
			return this;
		}
		setXmlVersion(version) {
			this._ncrXmlVersion = version === "1.1" || version === 1.1 ? 1.1 : 1;
		}
		decode(str) {
			if (typeof str !== "string" || str.length === 0) return str;
			const original = str;
			const chunks = [];
			const len = str.length;
			let last = 0;
			let i = 0;
			const limitExpansions = this._maxTotalExpansions > 0;
			const limitLength = this._maxExpandedLength > 0;
			const checkLimits = limitExpansions || limitLength;
			while (i < len) {
				if (str.charCodeAt(i) !== 38) {
					i++;
					continue;
				}
				let j = i + 1;
				while (j < len && str.charCodeAt(j) !== 59 && j - i <= 32) j++;
				if (j >= len || str.charCodeAt(j) !== 59) {
					i++;
					continue;
				}
				const token = str.slice(i + 1, j);
				if (token.length === 0) {
					i++;
					continue;
				}
				let replacement;
				let tier;
				if (this._removeSet.has(token)) {
					replacement = "";
					if (tier === void 0) tier = LIMIT_TIER_EXTERNAL;
				} else if (this._leaveSet.has(token)) {
					i++;
					continue;
				} else if (token.charCodeAt(0) === 35) {
					const ncrResult = this._resolveNCR(token);
					if (ncrResult === void 0) {
						i++;
						continue;
					}
					replacement = ncrResult;
					tier = LIMIT_TIER_BASE;
				} else {
					const resolved = this._resolveName(token);
					replacement = resolved?.value;
					tier = resolved?.tier;
				}
				if (replacement === void 0) {
					i++;
					continue;
				}
				if (i > last) chunks.push(str.slice(last, i));
				chunks.push(replacement);
				last = j + 1;
				i = last;
				if (checkLimits && this._tierCounts(tier)) {
					if (limitExpansions) {
						this._totalExpansions++;
						if (this._totalExpansions > this._maxTotalExpansions) throw new Error(`[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`);
					}
					if (limitLength) {
						const delta = replacement.length - (token.length + 2);
						if (delta > 0) {
							this._expandedLength += delta;
							if (this._expandedLength > this._maxExpandedLength) throw new Error(`[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`);
						}
					}
				}
			}
			if (last < len) chunks.push(str.slice(last));
			const result = chunks.length === 0 ? str : chunks.join("");
			return this._postCheck(result, original);
		}
		_tierCounts(tier) {
			if (this._limitTiers.has(LIMIT_TIER_ALL)) return true;
			return this._limitTiers.has(tier);
		}
		_resolveName(name) {
			if (name in this._inputMap) return {
				value: this._inputMap[name],
				tier: LIMIT_TIER_EXTERNAL
			};
			if (name in this._externalMap) return {
				value: this._externalMap[name],
				tier: LIMIT_TIER_EXTERNAL
			};
			if (name in this._baseMap) return {
				value: this._baseMap[name],
				tier: LIMIT_TIER_BASE
			};
		}
		_classifyNCR(cp) {
			if (cp === 0) return this._ncrNullLevel;
			if (cp >= 55296 && cp <= 57343) return NCR_LEVEL.remove;
			if (this._ncrXmlVersion === 1) {
				if (cp >= 1 && cp <= 31 && !XML10_ALLOWED_C0.has(cp)) return NCR_LEVEL.remove;
			}
			return -1;
		}
		_applyNCRAction(action, token, cp) {
			switch (action) {
				case NCR_LEVEL.allow: return String.fromCodePoint(cp);
				case NCR_LEVEL.remove: return "";
				case NCR_LEVEL.leave: return;
				case NCR_LEVEL.throw: throw new Error(`[EntityDecoder] Prohibited numeric character reference &${token}; (U+${cp.toString(16).toUpperCase().padStart(4, "0")})`);
				default: return String.fromCodePoint(cp);
			}
		}
		_resolveNCR(token) {
			const second = token.charCodeAt(1);
			let cp;
			if (second === 120 || second === 88) cp = parseInt(token.slice(2), 16);
			else cp = parseInt(token.slice(1), 10);
			if (Number.isNaN(cp) || cp < 0 || cp > 1114111) return;
			const minimum = this._classifyNCR(cp);
			if (!this._numericAllowed && minimum < NCR_LEVEL.remove) return;
			const effective = minimum === -1 ? this._ncrOnLevel : Math.max(this._ncrOnLevel, minimum);
			return this._applyNCRAction(effective, token, cp);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+xml-builder@3.972.22/node_modules/@aws-sdk/xml-builder/dist-cjs/xml-parser.js
var require_xml_parser = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.parseXML = parseXML;
	const fast_xml_parser_1 = require_fxp();
	const nodable_entities_1 = require_nodable_entities();
	const entityDecoder = new nodable_entities_1.EntityDecoderImpl({
		namedEntities: {
			...nodable_entities_1.XML,
			...nodable_entities_1.COMMON_HTML,
			...nodable_entities_1.CURRENCY
		},
		numericAllowed: true,
		limit: { maxTotalExpansions: Infinity },
		ncr: { xmlVersion: 1.1 }
	});
	const parser = new fast_xml_parser_1.XMLParser({
		attributeNamePrefix: "",
		processEntities: {
			enabled: true,
			maxTotalExpansions: Infinity
		},
		htmlEntities: true,
		entityDecoder: {
			setExternalEntities: (entities) => {
				entityDecoder.setExternalEntities(entities);
			},
			addInputEntities: (entities) => {
				entityDecoder.addInputEntities(entities);
			},
			reset: () => {
				entityDecoder.reset();
			},
			decode: (text) => {
				return entityDecoder.decode(text);
			},
			setXmlVersion: (version) => void 0
		},
		ignoreAttributes: false,
		ignoreDeclaration: true,
		parseTagValue: false,
		trimValues: false,
		tagValueProcessor: (_, val) => val.trim() === "" && val.includes("\n") ? "" : void 0,
		maxNestedTags: Infinity
	});
	function parseXML(xmlString) {
		return parser.parse(xmlString, true);
	}
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+xml-builder@3.972.22/node_modules/@aws-sdk/xml-builder/dist-cjs/index.js
var require_dist_cjs$1 = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var xmlParser = require_xml_parser();
	const ATTR_ESCAPE_RE = /[&<>"]/g;
	const ATTR_ESCAPE_MAP = {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"\"": "&quot;"
	};
	function escapeAttribute(value) {
		return value.replace(ATTR_ESCAPE_RE, (ch) => ATTR_ESCAPE_MAP[ch]);
	}
	const ELEMENT_ESCAPE_RE = /[&"'<>\r\n\u0085\u2028]/g;
	const ELEMENT_ESCAPE_MAP = {
		"&": "&amp;",
		"\"": "&quot;",
		"'": "&apos;",
		"<": "&lt;",
		">": "&gt;",
		"\r": "&#x0D;",
		"\n": "&#x0A;",
		"": "&#x85;",
		"\u2028": "&#x2028;"
	};
	function escapeElement(value) {
		return value.replace(ELEMENT_ESCAPE_RE, (ch) => ELEMENT_ESCAPE_MAP[ch]);
	}
	var XmlText = class {
		value;
		constructor(value) {
			this.value = value;
		}
		toString() {
			return escapeElement("" + this.value);
		}
	};
	var XmlNode = class XmlNode {
		name;
		children;
		attributes = {};
		static of(name, childText, withName) {
			const node = new XmlNode(name);
			if (childText !== void 0) node.addChildNode(new XmlText(childText));
			if (withName !== void 0) node.withName(withName);
			return node;
		}
		constructor(name, children = []) {
			this.name = name;
			this.children = children;
		}
		withName(name) {
			this.name = name;
			return this;
		}
		addAttribute(name, value) {
			this.attributes[name] = value;
			return this;
		}
		addChildNode(child) {
			this.children.push(child);
			return this;
		}
		removeAttribute(name) {
			delete this.attributes[name];
			return this;
		}
		n(name) {
			this.name = name;
			return this;
		}
		c(child) {
			this.children.push(child);
			return this;
		}
		a(name, value) {
			if (value != null) this.attributes[name] = value;
			return this;
		}
		cc(input, field, withName = field) {
			if (input[field] != null) {
				const node = XmlNode.of(field, input[field]).withName(withName);
				this.c(node);
			}
		}
		l(input, listName, memberName, valueProvider) {
			if (input[listName] != null) valueProvider().map((node) => {
				node.withName(memberName);
				this.c(node);
			});
		}
		lc(input, listName, memberName, valueProvider) {
			if (input[listName] != null) {
				const nodes = valueProvider();
				const containerNode = new XmlNode(memberName);
				nodes.map((node) => {
					containerNode.c(node);
				});
				this.c(containerNode);
			}
		}
		toString() {
			const hasChildren = Boolean(this.children.length);
			let xmlText = `<${this.name}`;
			const attributes = this.attributes;
			for (const attributeName of Object.keys(attributes)) {
				const attribute = attributes[attributeName];
				if (attribute != null) xmlText += ` ${attributeName}="${escapeAttribute("" + attribute)}"`;
			}
			return xmlText += !hasChildren ? "/>" : `>${this.children.map((c) => c.toString()).join("")}</${this.name}>`;
		}
	};
	exports.parseXML = xmlParser.parseXML;
	exports.XmlNode = XmlNode;
	exports.XmlText = XmlText;
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/xml/XmlShapeDeserializer.js
var import_dist_cjs$7, import_dist_cjs$8, import_dist_cjs$9, XmlShapeDeserializer;
var init_XmlShapeDeserializer = require_chunk.__esmMin((() => {
	import_dist_cjs$7 = require_dist_cjs$1();
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	import_dist_cjs$8 = require_dist_cjs$38.require_dist_cjs();
	import_dist_cjs$9 = require_dist_cjs$39.require_dist_cjs();
	init_ConfigurableSerdeContext();
	init_UnionSerde();
	XmlShapeDeserializer = class extends SerdeContextConfig {
		settings;
		stringDeserializer;
		constructor(settings) {
			super();
			this.settings = settings;
			this.stringDeserializer = new require_dist_cjs$38.FromStringShapeDeserializer(settings);
		}
		setSerdeContext(serdeContext) {
			this.serdeContext = serdeContext;
			this.stringDeserializer.setSerdeContext(serdeContext);
		}
		read(schema, bytes, key) {
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			const memberSchemas = ns.getMemberSchemas();
			if (ns.isStructSchema() && ns.isMemberSchema() && !!Object.values(memberSchemas).find((memberNs) => {
				return !!memberNs.getMemberTraits().eventPayload;
			})) {
				const output = {};
				const memberName = Object.keys(memberSchemas)[0];
				if (memberSchemas[memberName].isBlobSchema()) output[memberName] = bytes;
				else output[memberName] = this.read(memberSchemas[memberName], bytes);
				return output;
			}
			const xmlString = (this.serdeContext?.utf8Encoder ?? import_dist_cjs$9.toUtf8)(bytes);
			const parsedObject = this.parseXml(xmlString);
			return this.readSchema(schema, key ? parsedObject[key] : parsedObject);
		}
		readSchema(_schema, value) {
			const ns = require_dist_cjs$38.NormalizedSchema.of(_schema);
			if (ns.isUnitSchema()) return;
			const traits = ns.getMergedTraits();
			if (ns.isListSchema() && !Array.isArray(value)) return this.readSchema(ns, [value]);
			if (value == null) return value;
			if (typeof value === "object") {
				const flat = !!traits.xmlFlattened;
				if (ns.isListSchema()) {
					const listValue = ns.getValueSchema();
					const buffer = [];
					const sourceKey = listValue.getMergedTraits().xmlName ?? "member";
					const source = flat ? value : (value[0] ?? value)[sourceKey];
					if (source == null) return buffer;
					const sourceArray = Array.isArray(source) ? source : [source];
					for (const v of sourceArray) buffer.push(this.readSchema(listValue, v));
					return buffer;
				}
				const buffer = {};
				if (ns.isMapSchema()) {
					const keyNs = ns.getKeySchema();
					const memberNs = ns.getValueSchema();
					let entries;
					if (flat) entries = Array.isArray(value) ? value : [value];
					else entries = Array.isArray(value.entry) ? value.entry : [value.entry];
					const keyProperty = keyNs.getMergedTraits().xmlName ?? "key";
					const valueProperty = memberNs.getMergedTraits().xmlName ?? "value";
					for (const entry of entries) {
						const key = entry[keyProperty];
						const value = entry[valueProperty];
						buffer[key] = this.readSchema(memberNs, value);
					}
					return buffer;
				}
				if (ns.isStructSchema()) {
					const union = ns.isUnionSchema();
					let unionSerde;
					if (union) unionSerde = new UnionSerde(value, buffer);
					for (const [memberName, memberSchema] of ns.structIterator()) {
						const memberTraits = memberSchema.getMergedTraits();
						const xmlObjectKey = !memberTraits.httpPayload ? memberSchema.getMemberTraits().xmlName ?? memberName : memberTraits.xmlName ?? memberSchema.getName();
						if (union) unionSerde.mark(xmlObjectKey);
						if (value[xmlObjectKey] != null) buffer[memberName] = this.readSchema(memberSchema, value[xmlObjectKey]);
					}
					if (union) unionSerde.writeUnknown();
					return buffer;
				}
				if (ns.isDocumentSchema()) return value;
				throw new Error(`@aws-sdk/core/protocols - xml deserializer unhandled schema type for ${ns.getName(true)}`);
			}
			if (ns.isListSchema()) return [];
			if (ns.isMapSchema() || ns.isStructSchema()) return {};
			return this.stringDeserializer.read(ns, value);
		}
		parseXml(xml) {
			if (xml.length) {
				let parsedObj;
				try {
					parsedObj = (0, import_dist_cjs$7.parseXML)(xml);
				} catch (e) {
					if (e && typeof e === "object") Object.defineProperty(e, "$responseBodyText", { value: xml });
					throw e;
				}
				const textNodeName = "#text";
				const key = Object.keys(parsedObj)[0];
				const parsedObjToReturn = parsedObj[key];
				if (parsedObjToReturn[textNodeName]) {
					parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
					delete parsedObjToReturn[textNodeName];
				}
				return (0, import_dist_cjs$8.getValueFromTextNode)(parsedObjToReturn);
			}
			return {};
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/query/QueryShapeSerializer.js
var import_dist_cjs$5, import_dist_cjs$6, QueryShapeSerializer;
var init_QueryShapeSerializer = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	require_dist_cjs$38.init_serde();
	import_dist_cjs$5 = require_dist_cjs$38.require_dist_cjs();
	import_dist_cjs$6 = require_dist_cjs$38.require_dist_cjs$6();
	init_ConfigurableSerdeContext();
	QueryShapeSerializer = class extends SerdeContextConfig {
		settings;
		buffer;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		write(schema, value, prefix = "") {
			if (this.buffer === void 0) this.buffer = "";
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			if (prefix && !prefix.endsWith(".")) prefix += ".";
			if (ns.isBlobSchema()) {
				if (typeof value === "string" || value instanceof Uint8Array) {
					this.writeKey(prefix);
					this.writeValue((this.serdeContext?.base64Encoder ?? import_dist_cjs$6.toBase64)(value));
				}
			} else if (ns.isBooleanSchema() || ns.isNumericSchema() || ns.isStringSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(String(value));
				} else if (ns.isIdempotencyToken()) {
					this.writeKey(prefix);
					this.writeValue((0, require_dist_cjs$38.import_dist_cjs.v4)());
				}
			} else if (ns.isBigIntegerSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(String(value));
				}
			} else if (ns.isBigDecimalSchema()) {
				if (value != null) {
					this.writeKey(prefix);
					this.writeValue(value instanceof require_dist_cjs$38.NumericValue ? value.string : String(value));
				}
			} else if (ns.isTimestampSchema()) {
				if (value instanceof Date) {
					this.writeKey(prefix);
					switch (require_dist_cjs$38.determineTimestampFormat(ns, this.settings)) {
						case 5:
							this.writeValue(value.toISOString().replace(".000Z", "Z"));
							break;
						case 6:
							this.writeValue((0, import_dist_cjs$5.dateToUtcString)(value));
							break;
						case 7:
							this.writeValue(String(value.getTime() / 1e3));
							break;
					}
				}
			} else if (ns.isDocumentSchema()) if (Array.isArray(value)) this.write(79, value, prefix);
			else if (value instanceof Date) this.write(4, value, prefix);
			else if (value instanceof Uint8Array) this.write(21, value, prefix);
			else if (value && typeof value === "object") this.write(143, value, prefix);
			else {
				this.writeKey(prefix);
				this.writeValue(String(value));
			}
			else if (ns.isListSchema()) {
				if (Array.isArray(value)) if (value.length === 0) {
					if (this.settings.serializeEmptyLists) {
						this.writeKey(prefix);
						this.writeValue("");
					}
				} else {
					const member = ns.getValueSchema();
					const flat = this.settings.flattenLists || ns.getMergedTraits().xmlFlattened;
					let i = 1;
					for (const item of value) {
						if (item == null) continue;
						const traits = member.getMergedTraits();
						const suffix = this.getKey("member", traits.xmlName, traits.ec2QueryName);
						const key = flat ? `${prefix}${i}` : `${prefix}${suffix}.${i}`;
						this.write(member, item, key);
						++i;
					}
				}
			} else if (ns.isMapSchema()) {
				if (value && typeof value === "object") {
					const keySchema = ns.getKeySchema();
					const memberSchema = ns.getValueSchema();
					const flat = ns.getMergedTraits().xmlFlattened;
					let i = 1;
					for (const k in value) {
						const v = value[k];
						if (v == null) continue;
						const keyTraits = keySchema.getMergedTraits();
						const keySuffix = this.getKey("key", keyTraits.xmlName, keyTraits.ec2QueryName);
						const key = flat ? `${prefix}${i}.${keySuffix}` : `${prefix}entry.${i}.${keySuffix}`;
						const valTraits = memberSchema.getMergedTraits();
						const valueSuffix = this.getKey("value", valTraits.xmlName, valTraits.ec2QueryName);
						const valueKey = flat ? `${prefix}${i}.${valueSuffix}` : `${prefix}entry.${i}.${valueSuffix}`;
						this.write(keySchema, k, key);
						this.write(memberSchema, v, valueKey);
						++i;
					}
				}
			} else if (ns.isStructSchema()) {
				if (value && typeof value === "object") {
					let didWriteMember = false;
					for (const [memberName, member] of ns.structIterator()) {
						if (value[memberName] == null && !member.isIdempotencyToken()) continue;
						const traits = member.getMergedTraits();
						const suffix = this.getKey(memberName, traits.xmlName, traits.ec2QueryName, "struct");
						const key = `${prefix}${suffix}`;
						this.write(member, value[memberName], key);
						didWriteMember = true;
					}
					if (!didWriteMember && ns.isUnionSchema()) {
						const { $unknown } = value;
						if (Array.isArray($unknown)) {
							const [k, v] = $unknown;
							const key = `${prefix}${k}`;
							this.write(15, v, key);
						}
					}
				}
			} else if (ns.isUnitSchema()) {} else throw new Error(`@aws-sdk/core/protocols - QuerySerializer unrecognized schema type ${ns.getName(true)}`);
		}
		flush() {
			if (this.buffer === void 0) throw new Error("@aws-sdk/core/protocols - QuerySerializer cannot flush with nothing written to buffer.");
			const str = this.buffer;
			delete this.buffer;
			return str;
		}
		getKey(memberName, xmlName, ec2QueryName, keySource) {
			const { ec2, capitalizeKeys } = this.settings;
			if (ec2 && ec2QueryName) return ec2QueryName;
			const key = xmlName ?? memberName;
			if (capitalizeKeys && keySource === "struct") return key[0].toUpperCase() + key.slice(1);
			return key;
		}
		writeKey(key) {
			if (key.endsWith(".")) key = key.slice(0, key.length - 1);
			this.buffer += `&${require_dist_cjs$38.extendedEncodeURIComponent(key)}=`;
		}
		writeValue(value) {
			this.buffer += require_dist_cjs$38.extendedEncodeURIComponent(value);
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/query/AwsQueryProtocol.js
var AwsQueryProtocol;
var init_AwsQueryProtocol = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	init_ProtocolLib();
	init_XmlShapeDeserializer();
	init_QueryShapeSerializer();
	AwsQueryProtocol = class extends require_dist_cjs$38.RpcProtocol {
		options;
		serializer;
		deserializer;
		mixin = new ProtocolLib();
		constructor(options) {
			super({
				defaultNamespace: options.defaultNamespace,
				errorTypeRegistries: options.errorTypeRegistries
			});
			this.options = options;
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 5
				},
				httpBindings: false,
				xmlNamespace: options.xmlNamespace,
				serviceNamespace: options.defaultNamespace,
				serializeEmptyLists: true
			};
			this.serializer = new QueryShapeSerializer(settings);
			this.deserializer = new XmlShapeDeserializer(settings);
		}
		getShapeId() {
			return "aws.protocols#awsQuery";
		}
		setSerdeContext(serdeContext) {
			this.serializer.setSerdeContext(serdeContext);
			this.deserializer.setSerdeContext(serdeContext);
		}
		getPayloadCodec() {
			throw new Error("AWSQuery protocol has no payload codec.");
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			if (!request.path.endsWith("/")) request.path += "/";
			request.headers["content-type"] = "application/x-www-form-urlencoded";
			if (require_dist_cjs$38.deref(operationSchema.input) === "unit" || !request.body) request.body = "";
			request.body = `Action=${operationSchema.name.split("#")[1] ?? operationSchema.name}&Version=${this.options.version}` + request.body;
			if (request.body.endsWith("&")) request.body = request.body.slice(-1);
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			const deserializer = this.deserializer;
			const ns = require_dist_cjs$38.NormalizedSchema.of(operationSchema.output);
			const dataObject = {};
			if (response.statusCode >= 300) {
				const bytes = await require_dist_cjs$38.collectBody(response.body, context);
				if (bytes.byteLength > 0) Object.assign(dataObject, await deserializer.read(15, bytes));
				await this.handleError(operationSchema, context, response, dataObject, this.deserializeMetadata(response));
			}
			for (const header in response.headers) {
				const value = response.headers[header];
				delete response.headers[header];
				response.headers[header.toLowerCase()] = value;
			}
			const shortName = operationSchema.name.split("#")[1] ?? operationSchema.name;
			const awsQueryResultKey = ns.isStructSchema() && this.useNestedResult() ? shortName + "Result" : void 0;
			const bytes = await require_dist_cjs$38.collectBody(response.body, context);
			if (bytes.byteLength > 0) Object.assign(dataObject, await deserializer.read(ns, bytes, awsQueryResultKey));
			dataObject.$metadata = this.deserializeMetadata(response);
			return dataObject;
		}
		useNestedResult() {
			return true;
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = this.loadQueryErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			const errorData = this.loadQueryError(dataObject) ?? {};
			const message = this.loadQueryErrorMessage(dataObject);
			errorData.message = message;
			errorData.Error = {
				Type: errorData.Type,
				Code: errorData.Code,
				Message: message
			};
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, errorData, metadata, this.mixin.findQueryCompatibleError);
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)(message);
			const output = {
				Type: errorData.Error.Type,
				Code: errorData.Error.Code,
				Error: errorData.Error
			};
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().xmlName ?? name;
				const value = errorData[target] ?? dataObject[target];
				output[name] = this.deserializer.readSchema(member, value);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		loadQueryErrorCode(output, data) {
			const code = (data.Errors?.[0]?.Error ?? data.Errors?.Error ?? data.Error)?.Code;
			if (code !== void 0) return code;
			if (output.statusCode == 404) return "NotFound";
		}
		loadQueryError(data) {
			return data.Errors?.[0]?.Error ?? data.Errors?.Error ?? data.Error;
		}
		loadQueryErrorMessage(data) {
			const errorData = this.loadQueryError(data);
			return errorData?.message ?? errorData?.Message ?? data.message ?? data.Message ?? "Unknown";
		}
		getDefaultContentType() {
			return "application/x-www-form-urlencoded";
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/query/AwsEc2QueryProtocol.js
var AwsEc2QueryProtocol;
var init_AwsEc2QueryProtocol = require_chunk.__esmMin((() => {
	init_AwsQueryProtocol();
	AwsEc2QueryProtocol = class extends AwsQueryProtocol {
		options;
		constructor(options) {
			super(options);
			this.options = options;
			Object.assign(this.serializer.settings, {
				capitalizeKeys: true,
				flattenLists: true,
				serializeEmptyLists: false,
				ec2: true
			});
		}
		getShapeId() {
			return "aws.protocols#ec2Query";
		}
		useNestedResult() {
			return false;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/query/QuerySerializerSettings.js
var init_QuerySerializerSettings = require_chunk.__esmMin((() => {}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/xml/parseXmlBody.js
var import_dist_cjs$3, import_dist_cjs$4, parseXmlBody, parseXmlErrorBody, loadRestXmlErrorCode;
var init_parseXmlBody = require_chunk.__esmMin((() => {
	import_dist_cjs$3 = require_dist_cjs$1();
	import_dist_cjs$4 = require_dist_cjs$38.require_dist_cjs();
	init_common();
	parseXmlBody = (streamBody, context) => collectBodyString(streamBody, context).then((encoded) => {
		if (encoded.length) {
			let parsedObj;
			try {
				parsedObj = (0, import_dist_cjs$3.parseXML)(encoded);
			} catch (e) {
				if (e && typeof e === "object") Object.defineProperty(e, "$responseBodyText", { value: encoded });
				throw e;
			}
			const textNodeName = "#text";
			const key = Object.keys(parsedObj)[0];
			const parsedObjToReturn = parsedObj[key];
			if (parsedObjToReturn[textNodeName]) {
				parsedObjToReturn[key] = parsedObjToReturn[textNodeName];
				delete parsedObjToReturn[textNodeName];
			}
			return (0, import_dist_cjs$4.getValueFromTextNode)(parsedObjToReturn);
		}
		return {};
	});
	parseXmlErrorBody = async (errorBody, context) => {
		const value = await parseXmlBody(errorBody, context);
		if (value.Error) value.Error.message = value.Error.message ?? value.Error.Message;
		return value;
	};
	loadRestXmlErrorCode = (output, data) => {
		if (data?.Error?.Code !== void 0) return data.Error.Code;
		if (data?.Code !== void 0) return data.Code;
		if (output.statusCode == 404) return "NotFound";
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/xml/XmlShapeSerializer.js
var import_dist_cjs, import_dist_cjs$1, import_dist_cjs$2, XmlShapeSerializer;
var init_XmlShapeSerializer = require_chunk.__esmMin((() => {
	import_dist_cjs = require_dist_cjs$1();
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	require_dist_cjs$38.init_serde();
	import_dist_cjs$1 = require_dist_cjs$38.require_dist_cjs();
	import_dist_cjs$2 = require_dist_cjs$38.require_dist_cjs$6();
	init_ConfigurableSerdeContext();
	XmlShapeSerializer = class extends SerdeContextConfig {
		settings;
		stringBuffer;
		byteBuffer;
		buffer;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		write(schema, value) {
			const ns = require_dist_cjs$38.NormalizedSchema.of(schema);
			if (ns.isStringSchema() && typeof value === "string") this.stringBuffer = value;
			else if (ns.isBlobSchema()) this.byteBuffer = "byteLength" in value ? value : (this.serdeContext?.base64Decoder ?? import_dist_cjs$2.fromBase64)(value);
			else {
				this.buffer = this.writeStruct(ns, value, void 0);
				const traits = ns.getMergedTraits();
				if (traits.httpPayload && !traits.xmlName) this.buffer.withName(ns.getName());
			}
		}
		flush() {
			if (this.byteBuffer !== void 0) {
				const bytes = this.byteBuffer;
				delete this.byteBuffer;
				return bytes;
			}
			if (this.stringBuffer !== void 0) {
				const str = this.stringBuffer;
				delete this.stringBuffer;
				return str;
			}
			const buffer = this.buffer;
			if (this.settings.xmlNamespace) {
				if (!buffer?.attributes?.["xmlns"]) buffer.addAttribute("xmlns", this.settings.xmlNamespace);
			}
			delete this.buffer;
			return buffer.toString();
		}
		writeStruct(ns, value, parentXmlns) {
			const traits = ns.getMergedTraits();
			const name = ns.isMemberSchema() && !traits.httpPayload ? ns.getMemberTraits().xmlName ?? ns.getMemberName() : traits.xmlName ?? ns.getName();
			if (!name || !ns.isStructSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write struct with empty name or non-struct, schema=${ns.getName(true)}.`);
			const structXmlNode = import_dist_cjs.XmlNode.of(name);
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(ns, parentXmlns);
			for (const [memberName, memberSchema] of ns.structIterator()) {
				const val = value[memberName];
				if (val != null || memberSchema.isIdempotencyToken()) {
					if (memberSchema.getMergedTraits().xmlAttribute) {
						structXmlNode.addAttribute(memberSchema.getMergedTraits().xmlName ?? memberName, this.writeSimple(memberSchema, val));
						continue;
					}
					if (memberSchema.isListSchema()) this.writeList(memberSchema, val, structXmlNode, xmlns);
					else if (memberSchema.isMapSchema()) this.writeMap(memberSchema, val, structXmlNode, xmlns);
					else if (memberSchema.isStructSchema()) structXmlNode.addChildNode(this.writeStruct(memberSchema, val, xmlns));
					else {
						const memberNode = import_dist_cjs.XmlNode.of(memberSchema.getMergedTraits().xmlName ?? memberSchema.getMemberName());
						this.writeSimpleInto(memberSchema, val, memberNode, xmlns);
						structXmlNode.addChildNode(memberNode);
					}
				}
			}
			const { $unknown } = value;
			if ($unknown && ns.isUnionSchema() && Array.isArray($unknown) && Object.keys(value).length === 1) {
				const [k, v] = $unknown;
				const node = import_dist_cjs.XmlNode.of(k);
				if (typeof v !== "string") if (value instanceof import_dist_cjs.XmlNode || value instanceof import_dist_cjs.XmlText) structXmlNode.addChildNode(value);
				else throw new Error("@aws-sdk - $unknown union member in XML requires value of type string, @aws-sdk/xml-builder::XmlNode or XmlText.");
				this.writeSimpleInto(0, v, node, xmlns);
				structXmlNode.addChildNode(node);
			}
			if (xmlns) structXmlNode.addAttribute(xmlnsAttr, xmlns);
			return structXmlNode;
		}
		writeList(listMember, array, container, parentXmlns) {
			if (!listMember.isMemberSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write non-member list: ${listMember.getName(true)}`);
			const listTraits = listMember.getMergedTraits();
			const listValueSchema = listMember.getValueSchema();
			const listValueTraits = listValueSchema.getMergedTraits();
			const sparse = !!listValueTraits.sparse;
			const flat = !!listTraits.xmlFlattened;
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(listMember, parentXmlns);
			const writeItem = (container, value) => {
				if (listValueSchema.isListSchema()) this.writeList(listValueSchema, Array.isArray(value) ? value : [value], container, xmlns);
				else if (listValueSchema.isMapSchema()) this.writeMap(listValueSchema, value, container, xmlns);
				else if (listValueSchema.isStructSchema()) {
					const struct = this.writeStruct(listValueSchema, value, xmlns);
					container.addChildNode(struct.withName(flat ? listTraits.xmlName ?? listMember.getMemberName() : listValueTraits.xmlName ?? "member"));
				} else {
					const listItemNode = import_dist_cjs.XmlNode.of(flat ? listTraits.xmlName ?? listMember.getMemberName() : listValueTraits.xmlName ?? "member");
					this.writeSimpleInto(listValueSchema, value, listItemNode, xmlns);
					container.addChildNode(listItemNode);
				}
			};
			if (flat) {
				for (const value of array) if (sparse || value != null) writeItem(container, value);
			} else {
				const listNode = import_dist_cjs.XmlNode.of(listTraits.xmlName ?? listMember.getMemberName());
				if (xmlns) listNode.addAttribute(xmlnsAttr, xmlns);
				for (const value of array) if (sparse || value != null) writeItem(listNode, value);
				container.addChildNode(listNode);
			}
		}
		writeMap(mapMember, map, container, parentXmlns, containerIsMap = false) {
			if (!mapMember.isMemberSchema()) throw new Error(`@aws-sdk/core/protocols - xml serializer, cannot write non-member map: ${mapMember.getName(true)}`);
			const mapTraits = mapMember.getMergedTraits();
			const mapKeySchema = mapMember.getKeySchema();
			const keyTag = mapKeySchema.getMergedTraits().xmlName ?? "key";
			const mapValueSchema = mapMember.getValueSchema();
			const mapValueTraits = mapValueSchema.getMergedTraits();
			const valueTag = mapValueTraits.xmlName ?? "value";
			const sparse = !!mapValueTraits.sparse;
			const flat = !!mapTraits.xmlFlattened;
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(mapMember, parentXmlns);
			const addKeyValue = (entry, key, val) => {
				const keyNode = import_dist_cjs.XmlNode.of(keyTag, key);
				const [keyXmlnsAttr, keyXmlns] = this.getXmlnsAttribute(mapKeySchema, xmlns);
				if (keyXmlns) keyNode.addAttribute(keyXmlnsAttr, keyXmlns);
				entry.addChildNode(keyNode);
				let valueNode = import_dist_cjs.XmlNode.of(valueTag);
				if (mapValueSchema.isListSchema()) this.writeList(mapValueSchema, val, valueNode, xmlns);
				else if (mapValueSchema.isMapSchema()) this.writeMap(mapValueSchema, val, valueNode, xmlns, true);
				else if (mapValueSchema.isStructSchema()) valueNode = this.writeStruct(mapValueSchema, val, xmlns);
				else this.writeSimpleInto(mapValueSchema, val, valueNode, xmlns);
				entry.addChildNode(valueNode);
			};
			if (flat) for (const key in map) {
				const val = map[key];
				if (sparse || val != null) {
					const entry = import_dist_cjs.XmlNode.of(mapTraits.xmlName ?? mapMember.getMemberName());
					addKeyValue(entry, key, val);
					container.addChildNode(entry);
				}
			}
			else {
				let mapNode;
				if (!containerIsMap) {
					mapNode = import_dist_cjs.XmlNode.of(mapTraits.xmlName ?? mapMember.getMemberName());
					if (xmlns) mapNode.addAttribute(xmlnsAttr, xmlns);
					container.addChildNode(mapNode);
				}
				for (const key in map) {
					const val = map[key];
					if (sparse || val != null) {
						const entry = import_dist_cjs.XmlNode.of("entry");
						addKeyValue(entry, key, val);
						(containerIsMap ? container : mapNode).addChildNode(entry);
					}
				}
			}
		}
		writeSimple(_schema, value) {
			if (null === value) throw new Error("@aws-sdk/core/protocols - (XML serializer) cannot write null value.");
			const ns = require_dist_cjs$38.NormalizedSchema.of(_schema);
			let nodeContents = null;
			if (value && typeof value === "object") if (ns.isBlobSchema()) nodeContents = (this.serdeContext?.base64Encoder ?? import_dist_cjs$2.toBase64)(value);
			else if (ns.isTimestampSchema() && value instanceof Date) switch (require_dist_cjs$38.determineTimestampFormat(ns, this.settings)) {
				case 5:
					nodeContents = value.toISOString().replace(".000Z", "Z");
					break;
				case 6:
					nodeContents = (0, import_dist_cjs$1.dateToUtcString)(value);
					break;
				case 7:
					nodeContents = String(value.getTime() / 1e3);
					break;
				default:
					console.warn("Missing timestamp format, using http date", value);
					nodeContents = (0, import_dist_cjs$1.dateToUtcString)(value);
					break;
			}
			else if (ns.isBigDecimalSchema() && value) {
				if (value instanceof require_dist_cjs$38.NumericValue) return value.string;
				return String(value);
			} else if (ns.isMapSchema() || ns.isListSchema()) throw new Error("@aws-sdk/core/protocols - xml serializer, cannot call _write() on List/Map schema, call writeList or writeMap() instead.");
			else throw new Error(`@aws-sdk/core/protocols - xml serializer, unhandled schema type for object value and schema: ${ns.getName(true)}`);
			if (ns.isBooleanSchema() || ns.isNumericSchema() || ns.isBigIntegerSchema() || ns.isBigDecimalSchema()) nodeContents = String(value);
			if (ns.isStringSchema()) if (value === void 0 && ns.isIdempotencyToken()) nodeContents = (0, require_dist_cjs$38.import_dist_cjs.v4)();
			else nodeContents = String(value);
			if (nodeContents === null) throw new Error(`Unhandled schema-value pair ${ns.getName(true)}=${value}`);
			return nodeContents;
		}
		writeSimpleInto(_schema, value, into, parentXmlns) {
			const nodeContents = this.writeSimple(_schema, value);
			const ns = require_dist_cjs$38.NormalizedSchema.of(_schema);
			const content = new import_dist_cjs.XmlText(nodeContents);
			const [xmlnsAttr, xmlns] = this.getXmlnsAttribute(ns, parentXmlns);
			if (xmlns) into.addAttribute(xmlnsAttr, xmlns);
			into.addChildNode(content);
		}
		getXmlnsAttribute(ns, parentXmlns) {
			const [prefix, xmlns] = ns.getMergedTraits().xmlNamespace ?? [];
			if (xmlns && xmlns !== parentXmlns) return [prefix ? `xmlns:${prefix}` : "xmlns", xmlns];
			return [void 0, void 0];
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/xml/XmlCodec.js
var XmlCodec;
var init_XmlCodec = require_chunk.__esmMin((() => {
	init_ConfigurableSerdeContext();
	init_XmlShapeDeserializer();
	init_XmlShapeSerializer();
	XmlCodec = class extends SerdeContextConfig {
		settings;
		constructor(settings) {
			super();
			this.settings = settings;
		}
		createSerializer() {
			const serializer = new XmlShapeSerializer(this.settings);
			serializer.setSerdeContext(this.serdeContext);
			return serializer;
		}
		createDeserializer() {
			const deserializer = new XmlShapeDeserializer(this.settings);
			deserializer.setSerdeContext(this.serdeContext);
			return deserializer;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/xml/AwsRestXmlProtocol.js
var AwsRestXmlProtocol;
var init_AwsRestXmlProtocol = require_chunk.__esmMin((() => {
	require_dist_cjs$38.init_protocols();
	require_dist_cjs$38.init_schema();
	init_ProtocolLib();
	init_parseXmlBody();
	init_XmlCodec();
	AwsRestXmlProtocol = class extends require_dist_cjs$38.HttpBindingProtocol {
		codec;
		serializer;
		deserializer;
		mixin = new ProtocolLib();
		constructor(options) {
			super(options);
			const settings = {
				timestampFormat: {
					useTrait: true,
					default: 5
				},
				httpBindings: true,
				xmlNamespace: options.xmlNamespace,
				serviceNamespace: options.defaultNamespace
			};
			this.codec = new XmlCodec(settings);
			this.serializer = new require_dist_cjs$38.HttpInterceptingShapeSerializer(this.codec.createSerializer(), settings);
			this.deserializer = new require_dist_cjs$38.HttpInterceptingShapeDeserializer(this.codec.createDeserializer(), settings);
		}
		getPayloadCodec() {
			return this.codec;
		}
		getShapeId() {
			return "aws.protocols#restXml";
		}
		async serializeRequest(operationSchema, input, context) {
			const request = await super.serializeRequest(operationSchema, input, context);
			const inputSchema = require_dist_cjs$38.NormalizedSchema.of(operationSchema.input);
			if (!request.headers["content-type"]) {
				const contentType = this.mixin.resolveRestContentType(this.getDefaultContentType(), inputSchema);
				if (contentType) request.headers["content-type"] = contentType;
			}
			if (typeof request.body === "string" && request.headers["content-type"] === this.getDefaultContentType() && !request.body.startsWith("<?xml ") && !this.hasUnstructuredPayloadBinding(inputSchema)) request.body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + request.body;
			return request;
		}
		async deserializeResponse(operationSchema, context, response) {
			return super.deserializeResponse(operationSchema, context, response);
		}
		async handleError(operationSchema, context, response, dataObject, metadata) {
			const errorIdentifier = loadRestXmlErrorCode(response, dataObject) ?? "Unknown";
			this.mixin.compose(this.compositeErrorRegistry, errorIdentifier, this.options.defaultNamespace);
			if (dataObject.Error && typeof dataObject.Error === "object") for (const key of Object.keys(dataObject.Error)) {
				dataObject[key] = dataObject.Error[key];
				if (key.toLowerCase() === "message") dataObject.message = dataObject.Error[key];
			}
			if (dataObject.RequestId && !metadata.requestId) metadata.requestId = dataObject.RequestId;
			const { errorSchema, errorMetadata } = await this.mixin.getErrorSchemaOrThrowBaseException(errorIdentifier, this.options.defaultNamespace, response, dataObject, metadata);
			const ns = require_dist_cjs$38.NormalizedSchema.of(errorSchema);
			const message = dataObject.Error?.message ?? dataObject.Error?.Message ?? dataObject.message ?? dataObject.Message ?? "UnknownError";
			const exception = new ((this.compositeErrorRegistry.getErrorCtor(errorSchema)) ?? Error)(message);
			await this.deserializeHttpMessage(errorSchema, context, response, dataObject);
			const output = {};
			const errorDeserializer = this.codec.createDeserializer();
			for (const [name, member] of ns.structIterator()) {
				const target = member.getMergedTraits().xmlName ?? name;
				const value = dataObject.Error?.[target] ?? dataObject[target];
				output[name] = errorDeserializer.readSchema(member, value);
			}
			throw this.mixin.decorateServiceException(Object.assign(exception, errorMetadata, {
				$fault: ns.getMergedTraits().error,
				message
			}, output), dataObject);
		}
		getDefaultContentType() {
			return "application/xml";
		}
		hasUnstructuredPayloadBinding(ns) {
			for (const [, member] of ns.structIterator()) if (member.getMergedTraits().httpPayload) return !(member.isStructSchema() || member.isMapSchema() || member.isListSchema());
			return false;
		}
	};
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+core@3.974.8/node_modules/@aws-sdk/core/dist-es/submodules/protocols/index.js
var protocols_exports = /* @__PURE__ */ require_chunk.__exportAll({
	AwsEc2QueryProtocol: () => AwsEc2QueryProtocol,
	AwsJson1_0Protocol: () => AwsJson1_0Protocol,
	AwsJson1_1Protocol: () => AwsJson1_1Protocol,
	AwsJsonRpcProtocol: () => AwsJsonRpcProtocol,
	AwsQueryProtocol: () => AwsQueryProtocol,
	AwsRestJsonProtocol: () => AwsRestJsonProtocol,
	AwsRestXmlProtocol: () => AwsRestXmlProtocol,
	AwsSmithyRpcV2CborProtocol: () => AwsSmithyRpcV2CborProtocol,
	JsonCodec: () => JsonCodec,
	JsonShapeDeserializer: () => JsonShapeDeserializer,
	JsonShapeSerializer: () => JsonShapeSerializer,
	QueryShapeSerializer: () => QueryShapeSerializer,
	XmlCodec: () => XmlCodec,
	XmlShapeDeserializer: () => XmlShapeDeserializer,
	XmlShapeSerializer: () => XmlShapeSerializer,
	_toBool: () => _toBool,
	_toNum: () => _toNum,
	_toStr: () => _toStr,
	awsExpectUnion: () => awsExpectUnion,
	loadRestJsonErrorCode: () => loadRestJsonErrorCode,
	loadRestXmlErrorCode: () => loadRestXmlErrorCode,
	parseJsonBody: () => parseJsonBody,
	parseJsonErrorBody: () => parseJsonErrorBody,
	parseXmlBody: () => parseXmlBody,
	parseXmlErrorBody: () => parseXmlErrorBody
});
var init_protocols = require_chunk.__esmMin((() => {
	init_AwsSmithyRpcV2CborProtocol();
	init_coercing_serializers();
	init_AwsJson1_0Protocol();
	init_AwsJson1_1Protocol();
	init_AwsJsonRpcProtocol();
	init_AwsRestJsonProtocol();
	init_JsonCodec();
	init_JsonShapeDeserializer();
	init_JsonShapeSerializer();
	init_awsExpectUnion();
	init_parseJsonBody();
	init_AwsEc2QueryProtocol();
	init_AwsQueryProtocol();
	init_QuerySerializerSettings();
	init_QueryShapeSerializer();
	init_AwsRestXmlProtocol();
	init_XmlCodec();
	init_XmlShapeDeserializer();
	init_XmlShapeSerializer();
	init_parseXmlBody();
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+region-config-resolver@3.972.13/node_modules/@aws-sdk/region-config-resolver/dist-cjs/regionConfig/stsRegionDefaultResolver.js
var require_stsRegionDefaultResolver = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.warning = void 0;
	exports.stsRegionDefaultResolver = stsRegionDefaultResolver;
	const config_resolver_1 = require_dist_cjs$11();
	const node_config_provider_1 = require_dist_cjs$43.require_dist_cjs();
	function stsRegionDefaultResolver(loaderConfig = {}) {
		return (0, node_config_provider_1.loadConfig)({
			...config_resolver_1.NODE_REGION_CONFIG_OPTIONS,
			async default() {
				if (!exports.warning.silence) console.warn("@aws-sdk - WARN - default STS region of us-east-1 used. See @aws-sdk/credential-providers README and set a region explicitly.");
				return "us-east-1";
			}
		}, {
			...config_resolver_1.NODE_REGION_CONFIG_FILE_OPTIONS,
			...loaderConfig
		});
	}
	exports.warning = { silence: false };
}));
//#endregion
//#region ../../node_modules/.bun/@aws-sdk+region-config-resolver@3.972.13/node_modules/@aws-sdk/region-config-resolver/dist-cjs/index.js
var require_dist_cjs = /* @__PURE__ */ require_chunk.__commonJSMin(((exports) => {
	var stsRegionDefaultResolver = require_stsRegionDefaultResolver();
	var configResolver = require_dist_cjs$11();
	const getAwsRegionExtensionConfiguration = (runtimeConfig) => {
		return {
			setRegion(region) {
				runtimeConfig.region = region;
			},
			region() {
				return runtimeConfig.region;
			}
		};
	};
	const resolveAwsRegionExtensionConfiguration = (awsRegionExtensionConfiguration) => {
		return { region: awsRegionExtensionConfiguration.region() };
	};
	exports.NODE_REGION_CONFIG_FILE_OPTIONS = configResolver.NODE_REGION_CONFIG_FILE_OPTIONS;
	exports.NODE_REGION_CONFIG_OPTIONS = configResolver.NODE_REGION_CONFIG_OPTIONS;
	exports.REGION_ENV_NAME = configResolver.REGION_ENV_NAME;
	exports.REGION_INI_NAME = configResolver.REGION_INI_NAME;
	exports.resolveRegionConfig = configResolver.resolveRegionConfig;
	exports.getAwsRegionExtensionConfiguration = getAwsRegionExtensionConfiguration;
	exports.resolveAwsRegionExtensionConfiguration = resolveAwsRegionExtensionConfiguration;
	Object.prototype.hasOwnProperty.call(stsRegionDefaultResolver, "__proto__") && !Object.prototype.hasOwnProperty.call(exports, "__proto__") && Object.defineProperty(exports, "__proto__", {
		enumerable: true,
		value: stsRegionDefaultResolver["__proto__"]
	});
	Object.keys(stsRegionDefaultResolver).forEach(function(k) {
		if (k !== "default" && !Object.prototype.hasOwnProperty.call(exports, k)) exports[k] = stsRegionDefaultResolver[k];
	});
}));
//#endregion
Object.defineProperty(exports, "AwsQueryProtocol", {
	enumerable: true,
	get: function() {
		return AwsQueryProtocol;
	}
});
Object.defineProperty(exports, "AwsRestJsonProtocol", {
	enumerable: true,
	get: function() {
		return AwsRestJsonProtocol;
	}
});
Object.defineProperty(exports, "AwsSdkSigV4ASigner", {
	enumerable: true,
	get: function() {
		return AwsSdkSigV4ASigner;
	}
});
Object.defineProperty(exports, "AwsSdkSigV4Signer", {
	enumerable: true,
	get: function() {
		return AwsSdkSigV4Signer;
	}
});
Object.defineProperty(exports, "DefaultIdentityProviderConfig", {
	enumerable: true,
	get: function() {
		return DefaultIdentityProviderConfig;
	}
});
Object.defineProperty(exports, "NODE_AUTH_SCHEME_PREFERENCE_OPTIONS", {
	enumerable: true,
	get: function() {
		return NODE_AUTH_SCHEME_PREFERENCE_OPTIONS;
	}
});
Object.defineProperty(exports, "NODE_SIGV4A_CONFIG_OPTIONS", {
	enumerable: true,
	get: function() {
		return NODE_SIGV4A_CONFIG_OPTIONS;
	}
});
Object.defineProperty(exports, "NoAuthSigner", {
	enumerable: true,
	get: function() {
		return NoAuthSigner;
	}
});
Object.defineProperty(exports, "dist_es_exports", {
	enumerable: true,
	get: function() {
		return dist_es_exports;
	}
});
Object.defineProperty(exports, "getHttpAuthSchemeEndpointRuleSetPlugin", {
	enumerable: true,
	get: function() {
		return getHttpAuthSchemeEndpointRuleSetPlugin;
	}
});
Object.defineProperty(exports, "getHttpSigningPlugin", {
	enumerable: true,
	get: function() {
		return getHttpSigningPlugin;
	}
});
Object.defineProperty(exports, "httpAuthSchemes_exports", {
	enumerable: true,
	get: function() {
		return httpAuthSchemes_exports;
	}
});
Object.defineProperty(exports, "init_dist_es", {
	enumerable: true,
	get: function() {
		return init_dist_es;
	}
});
Object.defineProperty(exports, "init_httpAuthSchemes", {
	enumerable: true,
	get: function() {
		return init_httpAuthSchemes;
	}
});
Object.defineProperty(exports, "init_protocols", {
	enumerable: true,
	get: function() {
		return init_protocols;
	}
});
Object.defineProperty(exports, "protocols_exports", {
	enumerable: true,
	get: function() {
		return protocols_exports;
	}
});
Object.defineProperty(exports, "require_dist_cjs", {
	enumerable: true,
	get: function() {
		return require_dist_cjs;
	}
});
Object.defineProperty(exports, "require_dist_cjs$1", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$2;
	}
});
Object.defineProperty(exports, "require_dist_cjs$10", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$12;
	}
});
Object.defineProperty(exports, "require_dist_cjs$11", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$13;
	}
});
Object.defineProperty(exports, "require_dist_cjs$12", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$14;
	}
});
Object.defineProperty(exports, "require_dist_cjs$13", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$15;
	}
});
Object.defineProperty(exports, "require_dist_cjs$14", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$16;
	}
});
Object.defineProperty(exports, "require_dist_cjs$15", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$17;
	}
});
Object.defineProperty(exports, "require_dist_cjs$16", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$18;
	}
});
Object.defineProperty(exports, "require_dist_cjs$2", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$3;
	}
});
Object.defineProperty(exports, "require_dist_cjs$3", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$4;
	}
});
Object.defineProperty(exports, "require_dist_cjs$4", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$5;
	}
});
Object.defineProperty(exports, "require_dist_cjs$5", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$6;
	}
});
Object.defineProperty(exports, "require_dist_cjs$6", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$7;
	}
});
Object.defineProperty(exports, "require_dist_cjs$7", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$8;
	}
});
Object.defineProperty(exports, "require_dist_cjs$8", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$10;
	}
});
Object.defineProperty(exports, "require_dist_cjs$9", {
	enumerable: true,
	get: function() {
		return require_dist_cjs$11;
	}
});
Object.defineProperty(exports, "resolveAwsSdkSigV4AConfig", {
	enumerable: true,
	get: function() {
		return resolveAwsSdkSigV4AConfig;
	}
});
Object.defineProperty(exports, "resolveAwsSdkSigV4Config", {
	enumerable: true,
	get: function() {
		return resolveAwsSdkSigV4Config;
	}
});
