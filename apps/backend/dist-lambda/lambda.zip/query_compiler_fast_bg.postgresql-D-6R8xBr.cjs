require("./chunk-9hOWP6kD.cjs");
//#region ../../node_modules/.bun/@prisma+client@7.6.0+00d614ed0949de27/node_modules/@prisma/client/runtime/query_compiler_fast_bg.postgresql.mjs
var h = () => {};
h.prototype = h;
let o;
function D(e) {
	o = e;
}
let p = null;
function a() {
	return (p === null || p.byteLength === 0) && (p = new Uint8Array(o.memory.buffer)), p;
}
let y = new TextDecoder("utf-8", {
	ignoreBOM: !0,
	fatal: !0
});
y.decode();
const E = 2146435072;
let A = 0;
function T(e, t) {
	return A += t, A >= E && (y = new TextDecoder("utf-8", {
		ignoreBOM: !0,
		fatal: !0
	}), y.decode(), A = t), y.decode(a().subarray(e, e + t));
}
function m(e, t) {
	return e = e >>> 0, T(e, t);
}
let f = 0;
const g = new TextEncoder();
"encodeInto" in g || (g.encodeInto = function(e, t) {
	const n = g.encode(e);
	return t.set(n), {
		read: e.length,
		written: n.length
	};
});
function l(e, t, n) {
	if (n === void 0) {
		const i = g.encode(e), d = t(i.length, 1) >>> 0;
		return a().subarray(d, d + i.length).set(i), f = i.length, d;
	}
	let _ = e.length, r = t(_, 1) >>> 0;
	const s = a();
	let c = 0;
	for (; c < _; c++) {
		const i = e.charCodeAt(c);
		if (i > 127) break;
		s[r + c] = i;
	}
	if (c !== _) {
		c !== 0 && (e = e.slice(c)), r = n(r, _, _ = c + e.length * 3, 1) >>> 0;
		const i = a().subarray(r + c, r + _), d = g.encodeInto(e, i);
		c += d.written, r = n(r, _, c, 1) >>> 0;
	}
	return f = c, r;
}
let b = null;
function u() {
	return (b === null || b.buffer.detached === !0 || b.buffer.detached === void 0 && b.buffer !== o.memory.buffer) && (b = new DataView(o.memory.buffer)), b;
}
function x(e) {
	return e == null;
}
function S(e) {
	const t = typeof e;
	if (t == "number" || t == "boolean" || e == null) return `${e}`;
	if (t == "string") return `"${e}"`;
	if (t == "symbol") {
		const r = e.description;
		return r == null ? "Symbol" : `Symbol(${r})`;
	}
	if (t == "function") {
		const r = e.name;
		return typeof r == "string" && r.length > 0 ? `Function(${r})` : "Function";
	}
	if (Array.isArray(e)) {
		const r = e.length;
		let s = "[";
		r > 0 && (s += S(e[0]));
		for (let c = 1; c < r; c++) s += ", " + S(e[c]);
		return s += "]", s;
	}
	const n = /\[object ([^\]]+)\]/.exec(toString.call(e));
	let _;
	if (n && n.length > 1) _ = n[1];
	else return toString.call(e);
	if (_ == "Object") try {
		return "Object(" + JSON.stringify(e) + ")";
	} catch {
		return "Object";
	}
	return e instanceof Error ? `${e.name}: ${e.message}
${e.stack}` : _;
}
function M(e, t) {
	return e = e >>> 0, a().subarray(e / 1, e / 1 + t);
}
function w(e) {
	const t = o.__wbindgen_externrefs.get(e);
	return o.__externref_table_dealloc(e), t;
}
const I = typeof FinalizationRegistry > "u" ? {
	register: () => {},
	unregister: () => {}
} : new FinalizationRegistry((e) => o.__wbg_querycompiler_free(e >>> 0, 1));
var F = class {
	__destroy_into_raw() {
		const t = this.__wbg_ptr;
		return this.__wbg_ptr = 0, I.unregister(this), t;
	}
	free() {
		const t = this.__destroy_into_raw();
		o.__wbg_querycompiler_free(t, 0);
	}
	compileBatch(t) {
		const n = l(t, o.__wbindgen_malloc, o.__wbindgen_realloc), _ = f, r = o.querycompiler_compileBatch(this.__wbg_ptr, n, _);
		if (r[2]) throw w(r[1]);
		return w(r[0]);
	}
	constructor(t) {
		const n = o.querycompiler_new(t);
		if (n[2]) throw w(n[1]);
		return this.__wbg_ptr = n[0] >>> 0, I.register(this, this.__wbg_ptr, this), this;
	}
	compile(t) {
		const n = l(t, o.__wbindgen_malloc, o.__wbindgen_realloc), _ = f, r = o.querycompiler_compile(this.__wbg_ptr, n, _);
		if (r[2]) throw w(r[1]);
		return w(r[0]);
	}
};
Symbol.dispose && (F.prototype[Symbol.dispose] = F.prototype.free);
function O(e, t) {
	return Error(m(e, t));
}
function B(e) {
	return Number(e);
}
function N(e, t) {
	const _ = l(String(t), o.__wbindgen_malloc, o.__wbindgen_realloc), r = f;
	u().setInt32(e + 4, r, !0), u().setInt32(e + 0, _, !0);
}
function U(e) {
	const t = e, n = typeof t == "boolean" ? t : void 0;
	return x(n) ? 16777215 : n ? 1 : 0;
}
function R(e, t) {
	const _ = l(S(t), o.__wbindgen_malloc, o.__wbindgen_realloc), r = f;
	u().setInt32(e + 4, r, !0), u().setInt32(e + 0, _, !0);
}
function $(e, t) {
	return e in t;
}
function q(e) {
	const t = e;
	return typeof t == "object" && t !== null;
}
function C(e) {
	return typeof e == "string";
}
function k(e) {
	return e === void 0;
}
function W(e, t) {
	return e == t;
}
function V(e, t) {
	const n = t, _ = typeof n == "number" ? n : void 0;
	u().setFloat64(e + 8, x(_) ? 0 : _, !0), u().setInt32(e + 0, !x(_), !0);
}
function z(e, t) {
	const n = t, _ = typeof n == "string" ? n : void 0;
	var r = x(_) ? 0 : l(_, o.__wbindgen_malloc, o.__wbindgen_realloc), s = f;
	u().setInt32(e + 4, s, !0), u().setInt32(e + 0, r, !0);
}
function L(e, t) {
	throw new Error(m(e, t));
}
function P(e) {
	return Object.entries(e);
}
function Q(e) {
	return e.getTime();
}
function Y(e, t) {
	return e[t >>> 0];
}
function G(e, t) {
	return e[t];
}
function J(e) {
	let t;
	try {
		t = e instanceof ArrayBuffer;
	} catch {
		t = !1;
	}
	return t;
}
function X(e) {
	let t;
	try {
		t = e instanceof Uint8Array;
	} catch {
		t = !1;
	}
	return t;
}
function H(e) {
	return Number.isSafeInteger(e);
}
function K(e) {
	return e.length;
}
function Z(e) {
	return e.length;
}
function v() {
	return /* @__PURE__ */ new Date();
}
function ee() {
	return /* @__PURE__ */ new Object();
}
function te(e) {
	return new Uint8Array(e);
}
function ne() {
	return /* @__PURE__ */ new Map();
}
function re() {
	return new Array();
}
function _e(e, t, n) {
	Uint8Array.prototype.set.call(M(e, t), n);
}
function oe(e, t, n) {
	e[t] = n;
}
function ce(e, t, n) {
	return e.set(t, n);
}
function ie(e, t, n) {
	e[t >>> 0] = n;
}
function se(e, t) {
	global.PRISMA_WASM_PANIC_REGISTRY.set_message(m(e, t));
}
function ue(e, t) {
	return m(e, t);
}
function fe(e) {
	return BigInt.asUintN(64, e);
}
function be(e) {
	return e;
}
function de(e) {
	return e;
}
function ae() {
	const e = o.__wbindgen_externrefs, t = e.grow(4);
	e.set(0, void 0), e.set(t + 0, void 0), e.set(t + 1, null), e.set(t + 2, !0), e.set(t + 3, !1);
}
//#endregion
exports.QueryCompiler = F;
exports.__wbg_Error_e83987f665cf5504 = O;
exports.__wbg_Number_bb48ca12f395cd08 = B;
exports.__wbg_String_8f0eb39a4a4c2f66 = N;
exports.__wbg___wbindgen_boolean_get_6d5a1ee65bab5f68 = U;
exports.__wbg___wbindgen_debug_string_df47ffb5e35e6763 = R;
exports.__wbg___wbindgen_in_bb933bd9e1b3bc0f = $;
exports.__wbg___wbindgen_is_object_c818261d21f283a4 = q;
exports.__wbg___wbindgen_is_string_fbb76cb2940daafd = C;
exports.__wbg___wbindgen_is_undefined_2d472862bd29a478 = k;
exports.__wbg___wbindgen_jsval_loose_eq_b664b38a2f582147 = W;
exports.__wbg___wbindgen_number_get_a20bf9b85341449d = V;
exports.__wbg___wbindgen_string_get_e4f06c90489ad01b = z;
exports.__wbg___wbindgen_throw_b855445ff6a94295 = L;
exports.__wbg_entries_e171b586f8f6bdbf = P;
exports.__wbg_getTime_14776bfb48a1bff9 = Q;
exports.__wbg_get_7bed016f185add81 = Y;
exports.__wbg_get_with_ref_key_1dc361bd10053bfe = G;
exports.__wbg_instanceof_ArrayBuffer_70beb1189ca63b38 = J;
exports.__wbg_instanceof_Uint8Array_20c8e73002f7af98 = X;
exports.__wbg_isSafeInteger_d216eda7911dde36 = H;
exports.__wbg_length_69bca3cb64fc8748 = K;
exports.__wbg_length_cdd215e10d9dd507 = Z;
exports.__wbg_new_0_f9740686d739025c = v;
exports.__wbg_new_1acc0b6eea89d040 = ee;
exports.__wbg_new_5a79be3ab53b8aa5 = te;
exports.__wbg_new_68651c719dcda04e = ne;
exports.__wbg_new_e17d9f43105b08be = re;
exports.__wbg_prototypesetcall_2a6620b6922694b2 = _e;
exports.__wbg_set_3f1d0b984ed272ed = oe;
exports.__wbg_set_907fb406c34a251d = ce;
exports.__wbg_set_c213c871859d6500 = ie;
exports.__wbg_set_message_82ae475bb413aa5c = se;
exports.__wbg_set_wasm = D;
exports.__wbindgen_cast_2241b6af4c4b2941 = ue;
exports.__wbindgen_cast_4625c577ab2ec9ee = fe;
exports.__wbindgen_cast_9ae0607507abb057 = be;
exports.__wbindgen_cast_d6cd19b81560fd6e = de;
exports.__wbindgen_init_externref_table = ae;
